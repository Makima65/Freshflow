<?php
session_start();

// 1. CHECK IF ALREADY LOGGED IN
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true && $_SESSION['role_name'] === 'admin') {
    header('Location: pages/dashboard.php');
    exit;
}

$message = '';
$message_class = '';

if (isset($_GET['error'])) {
    $message = "Invalid username or password.";
    $message_class = "bg-red-100 border-red-400 text-red-700"; 
} 
else if (isset($_GET['status'])) {
    if ($_GET['status'] === 'idle') {
        $message = "You have been logged out due to inactivity.";
        $message_class = "bg-yellow-100 border-yellow-400 text-yellow-700"; 
    } 
    else if ($_GET['status'] === 'loggedout') {
        $message = "You have been successfully logged out.";
        $message_class = "bg-green-100 border-green-400 text-green-700"; 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Perishable Insights</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        /* Exact Colors from your C# XAML */
        :root {
            --brand-green: #1E3A1D;
            --brand-cream: #F8F5EE;
            --text-dark: #2B2B2B;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--brand-cream); 
        }

        .login-card-container {
            animation: fade-in-up 0.6s ease-out forwards;
            opacity: 0;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        }
        @keyframes fade-in-up {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* --- NEW GLOW EFFECT --- */
        .custom-input {
            transition: all 0.3s ease;
            background-color: white;
            border: 1px solid #d1d5db; /* Gray-300 */
        }
        
        /* When you Hover over the box */
        .custom-input:hover {
            border-color: var(--brand-green);
            /* Soft Green Halo */
            box-shadow: 0 0 0 4px rgba(30, 58, 29, 0.1); 
        }

        /* When you Click/Type in the box */
        .custom-input:focus {
            border-color: var(--brand-green);
            outline: none;
            /* Stronger Green Halo */
            box-shadow: 0 0 0 4px rgba(30, 58, 29, 0.25); 
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-4xl mx-auto lg:h-[600px] flex flex-col lg:flex-row rounded-2xl overflow-hidden login-card-container bg-white">
        
        <div class="hidden lg:flex w-full lg:w-[45%] flex-col items-center justify-center p-12 text-white relative overflow-hidden" style="background-color: #1E3A1D;">
            <div class="absolute -top-20 -left-20 w-64 h-64 bg-white opacity-5 rounded-full"></div>
            <div class="absolute bottom-10 right-10 w-32 h-32 bg-white opacity-5 rounded-full"></div>
            
            <div class="z-10 text-center">
                <span class="material-symbols-outlined text-6xl mb-4 text-green-100">eco</span>
                <h1 class="text-3xl font-bold leading-tight mb-2">Perishable Insights</h1>
                <p class="text-lg text-gray-300 font-light">Forecasting System</p>
            </div>
        </div>

        <div class="w-full lg:w-[55%] flex items-center justify-center p-8 lg:p-12" style="background-color: #F8F5EE;">
            <div class="w-full max-w-md space-y-6">
                
                <div class="text-left mb-8">
                    <h2 class="text-3xl font-bold text-[#2B2B2B] mb-2">Welcome Back!</h2>
                    <p class="text-gray-500">Sign in to continue</p>
                </div>

                <?php if (!empty($message)): ?>
                    <div class="<?php echo $message_class; ?> px-4 py-3 rounded-lg border text-sm" role="alert">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>

                <form class="space-y-6" action="process_admin_login.php" method="POST">
                    
                    <div>
                        <label for="username" class="block text-sm font-semibold text-[#2B2B2B] mb-1">Email Address</label>
                        <div class="relative group">
                            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 transition-colors group-hover:text-[#1E3A1D]">person</span>
                            
                            <input id="username" name="username" type="text" required 
                                   class="custom-input w-full pl-10 pr-4 py-3 rounded-lg text-gray-800 placeholder-gray-400" 
                                   placeholder="Username or Email">
                        </div>
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-semibold text-[#2B2B2B] mb-1">Password</label>
                        <div class="relative group">
                            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 transition-colors group-hover:text-[#1E3A1D]">lock</span>
                            
                            <input id="password" name="password" type="password" required 
                                   class="custom-input w-full pl-10 pr-10 py-3 rounded-lg text-gray-800 placeholder-gray-400" 
                                   placeholder="Password">
                            
                            <button type="button" id="togglePassword" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#1E3A1D] transition-colors">
                                <span class="material-symbols-outlined text-xl" id="toggleIcon">visibility</span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="pt-4">
                        <button type="submit" 
                                class="w-full py-3 px-4 rounded-lg text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5 active:translate-y-0 hover:bg-[#2a4e29]"
                                style="background-color: #1E3A1D;">
                            Login
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');

        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function () {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                toggleIcon.textContent = type === 'password' ? 'visibility' : 'visibility_off';
            });
        }
    </script>
</body>
</html>