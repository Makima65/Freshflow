<?php
// C:\xampp\htdocs\RalphPHP\admin_components\logout.php

session_start();

// Include DB and Audit Helper to log the action before destroying session
include_once 'includes/db_connection.php';
include_once 'includes/audit_helper.php';

// --- LOG THE LOGOUT ---
if (isset($_SESSION['user_id']) && function_exists('log_audit_action')) {
    log_audit_action('Logout', 'Authentication', "User logged out.");
}

// Destroy the session
$_SESSION = array();
session_destroy();

// Redirect to login page
header("location: admin_login.php?status=loggedout");
exit;
?>