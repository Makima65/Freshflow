<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\forecast.php
session_start();
ini_set('display_errors', 0);
include_once '../includes/db_connection.php';

// Security Check
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../admin_login.php"); exit;
}

// --- ENGINE: LINEAR REGRESSION WITH SPOILAGE OPTIMIZATION ---
function calculateForecast($sales_history, $days_to_predict = 7) {
    $n = count($sales_history);
    if ($n < 2) return ['prediction' => 0, 'slope' => 0, 'confidence' => 0];

    $x = []; $y = [];
    $i = 1;
    foreach ($sales_history as $qty) { $x[] = $i; $y[] = $qty; $i++; }

    $sum_x = array_sum($x); $sum_y = array_sum($y);
    $sum_xx = 0; $sum_xy = 0; $sum_yy = 0;

    for ($k = 0; $k < $n; $k++) {
        $sum_xx += $x[$k] * $x[$k];
        $sum_xy += $x[$k] * $y[$k];
        $sum_yy += $y[$k] * $y[$k];
    }

    $denominator = ($n * $sum_xx) - ($sum_x * $sum_x);
    if ($denominator == 0) return ['prediction' => 0, 'slope' => 0, 'confidence' => 0];
    
    $m = (($n * $sum_xy) - ($sum_x * $sum_y)) / $denominator;
    $b = ($sum_y - ($m * $sum_x)) / $n;

    $y_mean = $sum_y / $n;
    $ss_tot = 0; $ss_res = 0;
    
    for ($k = 0; $k < $n; $k++) {
        $y_actual = $y[$k];
        $y_pred = ($m * $x[$k]) + $b;
        $ss_tot += pow($y_actual - $y_mean, 2);
        $ss_res += pow($y_actual - $y_pred, 2);
    }
    
    $r2 = ($ss_tot == 0) ? 1 : (1 - ($ss_res / $ss_tot));
    $confidence = max(0, min(100, $r2 * 100)); 

    $total_predicted = 0;
    for ($d = 1; $d <= $days_to_predict; $d++) {
        $pred = ($m * ($n + $d)) + $b;
        $total_predicted += max(0, $pred);
    }

    return [
        'prediction' => $total_predicted,
        'slope' => $m,
        'confidence' => $confidence
    ];
}

// --- DATA FETCHING ---
$analysis_days = 30; // Still fetch 30 days for the Trend Graph

$prod_query = $conn->query("SELECT product_id, name, product_brand, unit_type, image_url FROM products WHERE status = 'Active'");
$products = ($prod_query) ? $prod_query->fetch_all(MYSQLI_ASSOC) : [];

$forecasts = [];
$global_history = array_fill(0, $analysis_days, 0); 

foreach ($products as $prod) {
    $pid = $prod['product_id'];
    
    // 1. Fetch Sales History (30 Days for Chart)
    $hist_sql = "SELECT DATE(sale_date) as s_date, SUM(quantity) as qty FROM sales_items si JOIN sales s ON si.sale_id = s.sale_id WHERE si.product_id = $pid AND s.order_status = 'Completed' AND s.sale_date >= DATE_SUB(CURDATE(), INTERVAL $analysis_days DAY) GROUP BY DATE(s.sale_date)";
    $hist_res = $conn->query($hist_sql);
    
    $raw_data = [];
    if ($hist_res) { while($r = $hist_res->fetch_assoc()) { $raw_data[$r['s_date']] = floatval($r['qty']); } }
    
    $sales_timeline = [];
    for($i = $analysis_days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $val = $raw_data[$d] ?? 0;
        $sales_timeline[] = $val;
        $global_history[$i] += $val;
    }

    // 2. Fetch Spoilage History (UPDATED: Focus on Last 7 Days for Risk Calculation)
    // We still keep historical records, but the AI only punishes you for RECENT waste.
    $spoil_sql = "SELECT SUM(quantity) as wasted FROM spoilage WHERE product_id = $pid AND spoilage_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    $spoil_res = $conn->query($spoil_sql);
    $recent_wasted = ($spoil_res && $spoil_res->num_rows > 0) ? floatval($spoil_res->fetch_assoc()['wasted']) : 0;
    
    // Calculate Recent Sales (Last 7 Days)
    $recent_sold = array_sum(array_slice($sales_timeline, -7)); 
    
    // Calculate Spoilage Rate (Based on RECENT behavior)
    $spoilage_rate = 0;
    if (($recent_sold + $recent_wasted) > 0) {
        $spoilage_rate = $recent_wasted / ($recent_sold + $recent_wasted);
    }

    // Determine if we should show this product
    // Show if there is ANY activity in 30 days OR if there is stock
    $total_sold_30d = array_sum($sales_timeline);
    
    $stock_res = $conn->query("SELECT quantity FROM product_inventory WHERE product_id = $pid");
    $current_stock = ($stock_res && $stock_res->num_rows > 0) ? floatval($stock_res->fetch_assoc()['quantity']) : 0;

    if ($total_sold_30d > 0 || $recent_wasted > 0 || $current_stock > 0) {
        $result = calculateForecast($sales_timeline, 7);
        $predicted = $result['prediction'];
        
        // --- OPTIMIZATION LOGIC ---
        // If spoilage rate is high (> 10%), reduce the purchase advice
        $risk_penalty = 1.0;
        $optimization_msg = "";
        
        if ($spoilage_rate > 0.10) {
            $risk_penalty = 1.0 - $spoilage_rate; 
            $optimization_msg = "Recent Waste Detected (" . round($spoilage_rate * 100) . "%)";
        }
        
        $optimized_demand = ceil($predicted * $risk_penalty);
        $restock = max(0, $optimized_demand - $current_stock);
        
        $status = 'Optimal';
        if ($restock > 0) $status = ($current_stock <= 0) ? 'Critical' : 'Low Stock';
        if ($restock == 0 && $current_stock > $optimized_demand * 2) $status = 'Overstocked';

        $forecasts[] = [
            'id' => $pid,
            'name' => $prod['name'],
            'brand' => $prod['product_brand'],
            'unit' => $prod['unit_type'],
            'stock' => $current_stock,
            'history_sparkline' => implode(',', $sales_timeline), 
            'predicted' => $optimized_demand,
            'raw_prediction' => $predicted,
            'confidence' => $result['confidence'],
            'trend' => $result['slope'],
            'restock' => $restock,
            'status' => $status,
            'spoilage_rate' => $spoilage_rate, // Now reflects 7-day rate
            'opt_msg' => $optimization_msg
        ];
    }
}

usort($forecasts, function($a, $b) {
    $p = ['Critical' => 1, 'Low Stock' => 2, 'Optimal' => 3, 'Overstocked' => 4];
    return $p[$a['status']] <=> $p[$b['status']];
});

$chart_labels = [];
for($i = $analysis_days - 1; $i >= 0; $i--) $chart_labels[] = date('M d', strtotime("-$i days"));
$js_labels = json_encode($chart_labels);
$js_data = json_encode($global_history);
?>

<?php include '../includes/sidebar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Inventory Optimization</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F3F4F6; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .glass-panel { background: white; border: 1px solid #E5E7EB; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); border-radius: 0.75rem; }
        .trend-up { color: #16a34a; } .trend-down { color: #dc2626; } .trend-flat { color: #9ca3af; }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    
    <main class="ml-20 flex-1 flex flex-col h-screen overflow-hidden relative">
        <div class="bg-white border-b border-gray-200 p-6 flex-shrink-0 flex justify-between items-end">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-700 uppercase tracking-wide border border-purple-200">Beta Model v1.4</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700 uppercase tracking-wide border border-orange-200">Adaptive Learning Enabled</span>
                </div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Inventory Optimization</h1>
                <p class="text-sm text-gray-500">Demand forecasting with adaptive risk assessment (Recent 7-Day Weighting).</p>
            </div>
            <div class="flex gap-3">
                <button onclick="window.print()" class="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 shadow-sm transition">
                    <span class="material-icons text-sm">print</span> Export
                </button>
                <button onclick="window.location.reload()" class="flex items-center gap-2 px-4 py-2 bg-[#1E3A1D] text-white rounded-lg text-sm font-medium hover:bg-[#142613] shadow-md transition">
                    <span class="material-icons text-sm">autorenew</span> Retrain Model
                </button>
            </div>
        </div>

        <div class="flex-1 overflow-auto p-6 space-y-6 custom-scrollbar">
            
            <div class="glass-panel p-6">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h2 class="font-bold text-gray-800">Aggregate Demand Trend</h2>
                        <p class="text-xs text-gray-500">Total unit sales across all products (Last 30 Days)</p>
                    </div>
                    <div class="text-right">
                        <p class="text-xs font-bold text-gray-400 uppercase">Forecast Horizon</p>
                        <p class="text-lg font-bold text-[#1E3A1D]">Next 7 Days</p>
                    </div>
                </div>
                <div class="h-64 w-full">
                    <canvas id="globalChart"></canvas>
                </div>
            </div>

            <div class="glass-panel overflow-hidden">
                <div class="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <h3 class="font-bold text-gray-700 text-sm">Product-Level Predictions</h3>
                    <div class="flex gap-2 text-xs">
                         <span class="flex items-center gap-1 text-gray-500"><span class="w-2 h-2 rounded-full bg-green-500"></span> High Confidence</span>
                         <span class="flex items-center gap-1 text-gray-500"><span class="w-2 h-2 rounded-full bg-orange-500"></span> Recent Waste Penalty</span>
                    </div>
                </div>
                <table class="w-full text-left">
                    <thead class="bg-white text-gray-500 text-xs uppercase font-bold border-b border-gray-200">
                        <tr>
                            <th class="px-6 py-4">Product Analysis</th>
                            <th class="px-6 py-4 text-center">Trend (30d)</th>
                            <th class="px-6 py-4 text-center">Optimized Forecast (7d)</th>
                            <th class="px-6 py-4 text-center">Spoilage Risk (7d)</th>
                            <th class="px-6 py-4 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 text-sm">
                        <?php foreach($forecasts as $f): 
                            $trendIcon = $f['trend'] > 0.1 ? 'north_east' : ($f['trend'] < -0.1 ? 'south_east' : 'remove');
                            $trendClass = $f['trend'] > 0.1 ? 'trend-up' : ($f['trend'] < -0.1 ? 'trend-down' : 'trend-flat');
                            
                            // Visuals for Spoilage
                            $hasSpoilageRisk = $f['spoilage_rate'] > 0.10;
                        ?>
                        <tr class="hover:bg-gray-50 transition group">
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded bg-gray-100 flex items-center justify-center text-gray-400 font-bold text-xs border border-gray-200">
                                        <?= strtoupper(substr($f['name'], 0, 2)) ?>
                                    </div>
                                    <div>
                                        <div class="font-bold text-gray-900"><?= htmlspecialchars($f['name']) ?></div>
                                        <div class="text-xs text-gray-500 flex items-center gap-1">
                                            <?= htmlspecialchars($f['brand']) ?> &bull; Stock: <span class="font-mono font-bold text-gray-700"><?= number_format($f['stock']) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <div class="w-24 h-8 mx-auto relative">
                                    <canvas class="sparkline" data-history="[<?= $f['history_sparkline'] ?>]" data-color="<?= $f['trend'] >= 0 ? '#16a34a' : '#dc2626' ?>"></canvas>
                                </div>
                                <div class="text-[10px] font-bold <?= $trendClass ?> flex justify-center items-center mt-1">
                                    <?= $f['trend'] > 0 ? '+' : '' ?><?= number_format($f['trend'], 2) ?> vel.
                                </div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <div class="inline-block px-4 py-2 bg-blue-50 rounded-lg border border-blue-100 relative">
                                    <span class="block text-xs text-blue-500 font-bold uppercase tracking-wide">Target</span>
                                    <span class="block text-xl font-bold text-blue-700"><?= ceil($f['predicted']) ?> <span class="text-xs text-blue-400 font-normal"><?= $f['unit'] ?></span></span>
                                    
                                    <?php if($hasSpoilageRisk): ?>
                                        <div class="absolute -top-2 -right-2 bg-orange-100 text-orange-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-orange-200 shadow-sm" title="Reduced from <?= ceil($f['raw_prediction']) ?> due to recent waste">
                                            -<?= round($f['spoilage_rate']*100) ?>%
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <?php if($hasSpoilageRisk): ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-700 border border-red-100">
                                        <span class="material-icons text-[12px]">delete_outline</span>
                                        High (<?= round($f['spoilage_rate']*100) ?>%)
                                    </span>
                                    <p class="text-[10px] text-gray-400 mt-1">Recent waste detected.</p>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-100">
                                        Stable
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-center align-middle">
                                <?php if($f['status'] === 'Critical'): ?>
                                    <div class="flex items-center justify-center gap-2 text-red-700 bg-red-50 border border-red-200 p-2 rounded-lg">
                                        <span class="material-icons text-sm animate-pulse">warning</span>
                                        <div class="text-left">
                                            <div class="text-xs font-bold uppercase">Critical</div>
                                            <div class="text-xs">Buy <span class="font-bold">+<?= ceil($f['restock']) ?></span></div>
                                        </div>
                                    </div>
                                <?php elseif($f['status'] === 'Low Stock'): ?>
                                    <div class="flex items-center justify-center gap-2 text-orange-700 bg-orange-50 border border-orange-200 p-2 rounded-lg">
                                        <span class="material-icons text-sm">add_shopping_cart</span>
                                        <div class="text-left">
                                            <div class="text-xs font-bold uppercase">Restock</div>
                                            <div class="text-xs">Buy <span class="font-bold">+<?= ceil($f['restock']) ?></span></div>
                                        </div>
                                    </div>
                                <?php elseif($f['status'] === 'Overstocked'): ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">Overstocked</span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Healthy</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        const ctx = document.getElementById('globalChart').getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(30, 58, 29, 0.15)');
        gradient.addColorStop(1, 'rgba(30, 58, 29, 0)');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= $js_labels ?>,
                datasets: [{
                    label: 'Actual Sales Volume',
                    data: <?= $js_data ?>,
                    borderColor: '#1E3A1D',
                    backgroundColor: gradient,
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
                scales: { 
                    x: { grid: { display: false }, ticks: { font: { size: 10 } } }, 
                    y: { beginAtZero: true, grid: { borderDash: [4, 4] } } 
                },
                interaction: { mode: 'nearest', axis: 'x', intersect: false }
            }
        });

        document.querySelectorAll('.sparkline').forEach(canvas => {
            const history = JSON.parse(canvas.dataset.history);
            const color = canvas.dataset.color;
            new Chart(canvas.getContext('2d'), {
                type: 'line',
                data: {
                    labels: history.map((_, i) => i),
                    datasets: [{ data: history, borderColor: color, borderWidth: 1.5, pointRadius: 0, fill: false, tension: 0.1 }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, tooltip: { enabled: false } },
                    scales: { x: { display: false }, y: { display: false, min: 0 } },
                    layout: { padding: { top: 4, bottom: 4, left: 2, right: 2 } }
                }
            });
        });
    </script>
</body>
</html>