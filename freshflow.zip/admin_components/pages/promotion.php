<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!defined('LOW_STOCK_THRESHOLD')) {
    define('LOW_STOCK_THRESHOLD', 5); // Define the threshold for the low stock notification
}

// --- DATABASE CONNECTION ---
// Ensure this path correctly points to your database connection file
include_once '../../includes/db_connection.php'; 

// =========================================================
// ✅ ADDED AUDIT HELPER INCLUSION
include_once '../includes/audit_helper.php'; 
// =========================================================

// --- CONNECTION CHECK ---
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed. Error: " . (isset($conn) ? $conn->connect_error : 'Connection not found.'));
}

// --- Security Check (Admin Role Required) ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || !isset($_SESSION["role_name"]) || $_SESSION["role_name"] !== 'admin') {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        http_response_code(403);
        echo json_encode(['error' => 'Authentication required.']);
        exit;
    }
    header("location: ../admin_login.php");
    exit;
}

// =========================================================
// ✅ NEW HELPER FUNCTIONS (DEFINED BEFORE handle_request)
// =========================================================

// 1. Brevo Email Helper (Copied from auth_handler.php)
function sendEmailViaBrevo($email_data) {
    // NOTE: Ensure this key is correct
    $brevo_api_key = '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'; 

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.brevo.com/v3/smtp/email');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($email_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'api-key: ' . $brevo_api_key,
        'content-type: application/json'
    ]);

    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Return true on success (HTTP 200/201), false otherwise
    return ($http_code == 200 || $http_code == 201);
}

// 2. Function to fetch all active customer emails
function getAllCustomerEmails($conn) {
    $emails = [];
    // Only select users with 'customer' role and 'Active' account status
    $sql = "SELECT username, email FROM users WHERE role_name = 'customer' AND account_status = 'Active'";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $emails[] = ['name' => $row['username'], 'email' => $row['email']];
        }
    }
    return $emails;
}

// 3. Function to send the promotion code email to all customers
// NOTE: $promo_discount_text is the formatted string (e.g., "20% OFF" or "$10 OFF")
function sendPromotionToAllCustomers($conn, $promo_code, $promo_discount_text, $promo_expiry) {
    $customers = getAllCustomerEmails($conn);
    
    if (empty($customers)) {
        return true; 
    }
    
    // Use the code as the descriptive name for simplicity in the email body
    $promo_name = "New Offer: {$promo_code}";

    $email_data = [
        'sender' => ['name' => 'AUTOPORMA Promotions', 'email' => 'autoporma76@gmail.com'],
        // Send a single email to all customers using the 'to' array
        'to' => $customers,
        'subject' => "🎉 Exclusive Offer: Get {$promo_discount_text} with Code {$promo_code}!",
        'htmlContent' => "
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; color: #333; margin: 0; padding: 0; }
        .email-container { max-width: 600px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); border-top: 5px solid #b22222; }
        .header { background-color: #b22222; color: #fff; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 30px; line-height: 1.6; }
        .promo-box { text-align: center; background-color: #f9f9f9; border: 2px dashed #b22222; padding: 20px; margin: 20px 0; border-radius: 5px; }
        .promo-box p { margin: 5px 0; font-size: 16px; }
        .promo-code { font-size: 28px; font-weight: bold; color: #b22222; letter-spacing: 2px; }
        .expiry { color: #888; font-size: 14px; margin-top: 15px; }
        .call-to-action { display: inline-block; background-color: #b22222; color: #ffffff; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 20px; }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='header'>
            <h1>New Exclusive Promotion!</h1>
        </div>
        <div class='content'>
            <p>Dear Valued Customer,</p>
            <p>We're excited to announce a special offer just for you! Use the promotion details below to get a fantastic discount on your next purchase:</p>

            <h2>{$promo_name}</h2>
            
            <div class='promo-box'>
                <p>Your Discount:</p>
                <p style='font-size: 36px; font-weight: bold; color: #b22222;'>{$promo_discount_text}</p>
                <p>Use Code:</p>
                <p class='promo-code'>{$promo_code}</p>
            </div>
            
            <p class='expiry'>This offer expires on: {$promo_expiry}. Don't miss out!</p>

            <p style='text-align: center;'><a href='https://autoporma.com/shop' class='call-to-action'>Shop Now and Save!</a></p>

        </div>
    </div>
</body>
</html>"
    ];

    // Send the email
    return sendEmailViaBrevo($email_data);
}

// --- Centralized AJAX and POST Handler ---
function handle_request($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
        header('Content-Type: application/json');
        $action = $_GET['action'];

        if ($action == 'get_promotion' && isset($_GET['id'])) {
            $promotion_id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT * FROM promotions WHERE promotion_id = ?");
            $stmt->bind_param("i", $promotion_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($promotion = $result->fetch_assoc()) {
                // Determine if the promotion is currently active based on dates
                $now = new DateTime();
                $end_date = new DateTime($promotion['end_date']);
                $start_date = new DateTime($promotion['start_date']);
                $promotion['current_status'] = ($promotion['is_active'] && $now >= $start_date && $now <= $end_date) ? 'Active' : 'Expired/Inactive';
                
                echo json_encode(['success' => true, 'data' => $promotion]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Promotion not found.']);
            }
            $stmt->close();
        }
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        $response = ['success' => false, 'message' => 'An unknown error occurred.'];
        $action = $_POST['action_type'] ?? '';

        if ($action === 'add_promotion' || $action === 'edit_promotion') {
            $is_edit = ($action === 'edit_promotion');
            $promotion_id = $is_edit ? intval($_POST['promotion_id']) : 0;
            
            $errors = [];
            if (empty(trim($_POST['code']))) $errors['code'] = 'Code is required.';
            if (!isset($_POST['discount_value']) || !is_numeric($_POST['discount_value']) || $_POST['discount_value'] < 0) $errors['discount_value'] = 'A valid discount value is required.';
            if (empty($_POST['start_date'])) $errors['start_date'] = 'Start date is required.';
            if (empty($_POST['end_date'])) $errors['end_date'] = 'End date is required.';

            if (empty($errors)) {
                $code = trim($_POST['code']);
                $discount_type = $_POST['discount_type'];
                $discount_value = floatval($_POST['discount_value']);
                // Format dates to MySQL DATETIME format (Y-m-d H:i:s)
                $start_date = date('Y-m-d H:i:s', strtotime($_POST['start_date']));
                $end_date = date('Y-m-d H:i:s', strtotime($_POST['end_date']));
                $is_active = intval($_POST['is_active']);

                if ($is_edit) {
                    $sql = "UPDATE promotions SET code=?, discount_type=?, discount_value=?, start_date=?, end_date=?, is_active=? WHERE promotion_id=?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssdssii", $code, $discount_type, $discount_value, $start_date, $end_date, $is_active, $promotion_id);
                } else {
                    $sql = "INSERT INTO promotions (code, discount_type, discount_value, start_date, end_date, is_active) VALUES (?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssdssi", $code, $discount_type, $discount_value, $start_date, $end_date, $is_active);
                }
                
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => "Promotion " . ($is_edit ? "updated" : "added") . " successfully!"];

                    // =========================================================
                    // ✅ ADDED AUDIT LOGIC FOR CREATE/UPDATE
                    // =========================================================
                    if (function_exists('log_audit_action')) {
                        $action_type = $is_edit ? 'Promotion Update' : 'Promotion Create';
                        $logged_id = $is_edit ? $promotion_id : $conn->insert_id;
                        $action_detail = "Promotion '{$code}' (ID: {$logged_id}) " . ($is_edit ? "updated." : "created.");
                        
                        $metadata = [
                            'promotion_id' => $logged_id,
                            'code' => $code,
                            'discount_type' => $discount_type,
                            'discount_value' => $discount_value,
                            'start_date' => $start_date,
                            'end_date' => $end_date,
                            'is_active' => $is_active
                        ];
                        
                        log_audit_action($action_type, 'Promotions', $action_detail, $metadata);
                    }
                    // =========================================================

                    // =========================================================
                    // ✅ EXISTING CODE: Trigger the bulk email after successful save
                    // =========================================================
                    
                    // 1. Format the discount text based on the type
                    $discount_text = ($discount_type === 'percent') 
                                     ? round($discount_value) . '% OFF' 
                                     : '₱' . number_format($discount_value, 2) . ' OFF';

                    // 2. Call the email function with formatted data
                    $email_sent = sendPromotionToAllCustomers($conn, $code, $discount_text, date('F j, Y', strtotime($end_date)));

                    if ($email_sent) {
                        $response['message'] .= ' Promotion automatically sent to all active customers.';
                    } else {
                        $response['message'] .= ' Promotion saved, but failed to send email to customers (Brevo API error).';
                    }
                    // =========================================================
                    
                } else {
                    $response['message'] = "Database error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $response = ['success' => false, 'message' => "Please correct the errors.", 'errors' => $errors];
            }
        }
        elseif ($action === 'delete_promotion') {
            $promotion_id = intval($_POST['delete_promotion_id'] ?? 0);
            if ($promotion_id > 0) {

                // =========================================================
                // ✅ ADDED AUDIT LOGIC: Fetch data before deletion for logging
                // =========================================================
                $promo_code = 'Unknown';
                if (function_exists('log_audit_action')) {
                    $old_promo_sql = "SELECT code FROM promotions WHERE promotion_id = ?";
                    $old_stmt = $conn->prepare($old_promo_sql);
                    if ($old_stmt) {
                        $old_stmt->bind_param("i", $promotion_id);
                        $old_stmt->execute();
                        $old_result = $old_stmt->get_result();
                        if ($old_promotion = $old_result->fetch_assoc()) {
                            $promo_code = $old_promotion['code'];
                        }
                        $old_stmt->close();
                    }
                }
                // =========================================================

                $stmt = $conn->prepare("DELETE FROM promotions WHERE promotion_id = ?");
                $stmt->bind_param("i", $promotion_id);
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => "Promotion deleted successfully!"];

                    // =========================================================
                    // ✅ ADDED AUDIT LOGIC: Log deletion
                    // =========================================================
                    if (function_exists('log_audit_action')) {
                        $details = "Promotion '{$promo_code}' (ID: {$promotion_id}) deleted.";
                        $metadata = ['promotion_id' => $promotion_id, 'code' => $promo_code];
                        log_audit_action('Promotion Delete', 'Promotions', $details, $metadata);
                    }
                    // =========================================================

                } else {
                    $response['message'] = "Failed to delete promotion.";
                }
                $stmt->close();
            } else {
                $response['message'] = "Invalid promotion ID.";
            }
        }
        elseif ($action === 'bulk_action') {
             $promotion_ids = $_POST['promotion_ids'] ?? [];
             $bulk_action = $_POST['bulk_action_type'] ?? '';
             
             if (!empty($promotion_ids) && !empty($bulk_action) && is_array($promotion_ids)) {
                 $ids_placeholder = implode(',', array_fill(0, count($promotion_ids), '?'));
                 $types = str_repeat('i', count($promotion_ids));

                // =========================================================
                // ✅ ADDED AUDIT LOGIC: Fetch promotion codes for meaningful logging (before action)
                // =========================================================
                $promotions_map = [];
                if (function_exists('log_audit_action')) {
                    $codes_sql = "SELECT promotion_id, code FROM promotions WHERE promotion_id IN ($ids_placeholder)";
                    $codes_stmt = $conn->prepare($codes_sql);
                    
                    // Dynamically bind the parameters
                    $bind_params = array_merge([$types], array_map('intval', $promotion_ids));
                    
                    if ($codes_stmt) {
                        // Using splat operator for PHP 5.6+
                        $codes_stmt->bind_param(...$bind_params);
                        
                        $codes_stmt->execute();
                        $codes_result = $codes_stmt->get_result();
                        while ($row = $codes_result->fetch_assoc()) {
                            $promotions_map[$row['promotion_id']] = $row['code']; // [id => code]
                        }
                        $codes_stmt->close();
                    }
                }
                // =========================================================
                 
                 if ($bulk_action === 'delete') {
                     $stmt = $conn->prepare("DELETE FROM promotions WHERE promotion_id IN ($ids_placeholder)");
                     $stmt->bind_param($types, ...array_map('intval', $promotion_ids));
                     if ($stmt->execute()) {
                         $response = ['success' => true, 'message' => 'Selected promotions deleted.'];

                        // =========================================================
                        // ✅ ADDED AUDIT LOGIC FOR BULK DELETE
                        // =========================================================
                        if (function_exists('log_audit_action')) {
                            $action_type = 'Promotion Bulk Delete';
                            $count = count($promotion_ids);
                            $codes_list = implode(', ', array_values($promotions_map));
                            $details = "Bulk deletion of {$count} promotions. Codes: {$codes_list}";
                            $metadata = [
                                'promotion_ids' => array_map('intval', $promotion_ids),
                                'codes' => $promotions_map,
                            ];
                            log_audit_action($action_type, 'Promotions', $details, $metadata);
                        }
                        // =========================================================

                     } else {
                         $response['message'] = 'Error during bulk deletion: ' . $conn->error;
                     }
                 } elseif ($bulk_action === 'activate' || $bulk_action === 'deactivate') {
                     $new_status = $bulk_action === 'activate' ? 1 : 0;
                     $stmt = $conn->prepare("UPDATE promotions SET is_active = ? WHERE promotion_id IN ($ids_placeholder)");
                     $stmt->bind_param("i" . $types, $new_status, ...array_map('intval', $promotion_ids));
                     if ($stmt->execute()) {
                         $response = ['success' => true, 'message' => 'Status updated for selected promotions.'];

                        // =========================================================
                        // ✅ ADDED AUDIT LOGIC FOR BULK STATUS CHANGE
                        // =========================================================
                        if (function_exists('log_audit_action')) {
                            $action_type = $bulk_action === 'activate' ? 'Promotion Bulk Activate' : 'Promotion Bulk Deactivate';
                            $count = count($promotion_ids);
                            $codes_list = implode(', ', array_values($promotions_map));
                            $details = "Bulk status update ({$bulk_action}d) for {$count} promotions. Codes: {$codes_list}";
                            $metadata = [
                                'promotion_ids' => array_map('intval', $promotion_ids),
                                'new_status' => $new_status,
                                'codes' => $promotions_map,
                            ];
                            log_audit_action($action_type, 'Promotions', $details, $metadata);
                        }
                        // =========================================================

                     } else {
                         $response['message'] = 'Error updating status: ' . $conn->error;
                     }
                 }
                 $stmt->close();
             } else {
                 $response['message'] = "No promotions selected or action specified.";
             }
        }
        echo json_encode($response);
        exit();
    }
}

// --- Execute Request Handler ---
handle_request($conn);

// --- INITIAL PAGE LOAD DATA FETCHING (Runs only on non-AJAX requests) ---
$promotions_per_page = 10;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $promotions_per_page;
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$type_filter = isset($_GET['type']) ? $_GET['type'] : 'all'; // New filter for discount type

$sort_options = ['newest' => 'p.created_at DESC', 'oldest' => 'p.created_at ASC', 'code_asc' => 'p.code ASC', 'end_date_asc' => 'p.end_date ASC', 'end_date_desc' => 'p.end_date DESC'];
$sort_by = isset($_GET['sort']) && isset($sort_options[$_GET['sort']]) ? $_GET['sort'] : 'newest';
$order_by = $sort_options[$sort_by];

$where_clauses = []; $params = []; $types = '';
$now_clause = "(NOW() BETWEEN p.start_date AND p.end_date AND p.is_active = 1)";

if (!empty($search_term)) {
    $where_clauses[] = 'p.code LIKE ?';
    $like_term = "%{$search_term}%";
    array_push($params, $like_term);
    $types .= 's';
}

if ($status_filter !== 'all') {
    if ($status_filter === 'Active') {
        $where_clauses[] = $now_clause;
    } elseif ($status_filter === 'Expired') {
        $where_clauses[] = 'NOW() > p.end_date';
    } elseif ($status_filter === 'Inactive') {
        $where_clauses[] = 'p.is_active = 0 AND NOW() <= p.end_date';
    }
}

if ($type_filter !== 'all') { $where_clauses[] = 'p.discount_type = ?'; $params[] = $type_filter; $types .= 's'; }

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

$base_query = "FROM promotions p ";
$count_sql = "SELECT COUNT(p.promotion_id) as count $base_query $where_sql";
$stmt_count = $conn->prepare($count_sql);

if (count($params) > 0) {
     // Use call_user_func_array for binding parameters since PHP 5.6
     if (!empty($types) && !empty($params)) {
         $bind_params = array_merge([$types], $params);
         $stmt_count->bind_param(...$bind_params);
     }
}
$stmt_count->execute();
$total_promotions_count = $stmt_count->get_result()->fetch_assoc()['count'];
$total_pages = ceil($total_promotions_count / $promotions_per_page);
$stmt_count->close();

$promotions_sql = "SELECT p.*, (NOW() BETWEEN p.start_date AND p.end_date AND p.is_active = 1) AS is_currently_active
                   $base_query $where_sql ORDER BY $order_by LIMIT ? OFFSET ?";

$stmt_promotions = $conn->prepare($promotions_sql);
$final_params = array_merge($params, [$promotions_per_page, $offset]);
$types_with_limit = $types . 'ii';

if (!empty($types_with_limit) && !empty($final_params)) {
    $bind_params = array_merge([$types_with_limit], $final_params);
    $stmt_promotions->bind_param(...$bind_params);
}
$stmt_promotions->execute();
$promotions_data = $stmt_promotions->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_promotions->close();


if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' && !isset($_GET['action'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'promotions' => $promotions_data, 
        'pagination' => ['total_promotions' => $total_promotions_count, 'total_pages' => $total_pages, 'current_page' => $current_page]
    ]);
    exit;
}

// --- Analytics Data ---
// NOTE: I'm re-using the $conn variable from the connection check at the top
$total_promotions = $conn->query("SELECT COUNT(*) as count FROM promotions")->fetch_assoc()['count'];
$active_promotions = $conn->query("SELECT COUNT(*) as count FROM promotions WHERE NOW() BETWEEN start_date AND end_date AND is_active = 1")->fetch_assoc()['count'];
$expired_promotions = $conn->query("SELECT COUNT(*) as count FROM promotions WHERE NOW() > end_date")->fetch_assoc()['count'];
$average_discount = $conn->query("SELECT AVG(discount_value) as avg_value FROM promotions WHERE discount_type = 'percent' AND NOW() BETWEEN start_date AND end_date AND is_active = 1")->fetch_assoc()['avg_value'] ?? 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Promotion Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://npmcdn.com/flatpickr/dist/themes/dark.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .dot-texture-background { background-color: #000000; background-image: radial-gradient(circle, rgba(255, 255, 255, 0.07) 1px, transparent 1px); background-size: 12px 12px; }
        .content-card { background-color: rgba(15, 23, 42, 0.5); border: 1px solid rgba(51, 65, 85, 0.5); backdrop-filter: blur(8px); }
        .form-input, .filter-select { background-color: #1f2937; border: 1px solid #4b5563; color: #d1d5db; }
        .form-input:focus, .filter-select:focus { outline: none; border-color: #ef4444; box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.5); }
        .modal-card { background-color: rgba(15, 23, 42, 0.8); border: 1px solid rgba(51, 65, 85, 0.7); backdrop-filter: blur(12px); }
        .modal { transition: opacity 0.3s ease; }
        .modal-content { transition: opacity 0.3s ease, transform 0.3s ease; max-height: 90vh; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        .modal.hidden .modal-content { opacity: 0; transform: translateY(-20px) scale(0.95); }
        .status-badge { padding: 2px 8px; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
        .status-Active { background-color: rgba(34, 197, 94, 0.1); color: #22c55e; }
        .status-Inactive { background-color: rgba(249, 115, 22, 0.1); color: #f97316; }
        .status-Expired { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; }
        #filterOptions { transition: max-height 0.5s ease-out, opacity 0.3s ease-out, margin-top 0.5s ease-out, padding-top 0.5s ease-out; }
        .filter-icon { transition: transform 0.3s ease-in-out; }
        #filterCountBadge { position: absolute; top: -5px; right: -5px; background-color: #ef4444; color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; display: flex; justify-content: center; align-items: center; font-weight: bold; transform: scale(0); transition: transform 0.2s ease-in-out; }
        #filterCountBadge.visible { transform: scale(1); }
        .form-input.is-invalid { border-color: #ef4444; }
        .error-message { color: #fca5a5; font-size: 0.875rem; margin-top: 0.25rem; min-height: 1.25rem; }
        label.required::after { content: '*'; color: #ef4444; margin-left: 0.25rem; }
    </style>
</head>
<body class="dot-texture-background text-slate-300">
    
    <?php include '../includes/sidebar.php'; ?>

    <div class="lg:pl-20">
        <main class="p-6 md:p-8">
            <header class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <h1 class="font-heading text-4xl font-bold text-white mb-4 md:mb-0">Promotion Management</h1>
                    <div class="flex items-center space-x-4">
                        <button id="addPromotionBtn" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg flex items-center space-x-2 transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                        <span>Add New Promotion</span>
                        </button>
                        <?php include '../includes/low_stock_notif.php'; ?>
                    </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="content-card p-6 rounded-lg"><p class="text-sm text-slate-400">Total Promotions</p><p class="font-heading text-3xl font-bold text-white mt-1"><?= $total_promotions ?></p></div>
                <div class="content-card p-6 rounded-lg"><p class="text-sm text-slate-400">Currently Active</p><p class="font-heading text-3xl font-bold text-white mt-1"><?= $active_promotions ?></p></div>
                <div class="content-card p-6 rounded-lg"><p class="text-sm text-slate-400">Expired</p><p class="font-heading text-3xl font-bold text-white mt-1"><?= $expired_promotions ?></p></div>
                <div class="content-card p-6 rounded-lg"><p class="text-sm text-slate-400">Avg. Active Discount</p><p class="font-heading text-3xl font-bold text-white mt-1"><?= number_format($average_discount, 0) ?>%</p></div>
            </div>

            <div class="content-card p-4 rounded-lg mb-6 relative z-10">
                <div id="filterSortForm">
                    <div class="flex flex-col md:flex-row items-center gap-4">
                        <div class="relative w-full flex-grow">
                            <input type="text" name="search" id="searchInput" placeholder="Search by promotion code..." value="<?= htmlspecialchars($search_term) ?>" class="w-full p-2 rounded-lg form-input" autocomplete="off">
                        </div>
                        <button id="toggleFilterBtn" class="relative flex-shrink-0 bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg flex items-center space-x-2 transition">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 filter-icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L13 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clip-rule="evenodd" /></svg>
                            <span>Filter</span>
                            <span id="filterCountBadge"></span>
                        </button>
                    </div>
                    <div id="filterOptions" style="max-height: 0px; opacity: 0; overflow: hidden;">
                        <div class="border-t border-slate-700 mt-4 pt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                            <div class="w-full">
                                <label class="block text-xs text-slate-400 mb-1">Current Status</label>
                                <select name="status" id="statusFilter" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all" <?= $status_filter == 'all' ? 'selected' : '' ?>>All Statuses</option>
                                    <option value="Active" <?= $status_filter == 'Active' ? 'selected' : '' ?>>Active</option>
                                    <option value="Inactive" <?= $status_filter == 'Inactive' ? 'selected' : '' ?>>Inactive (Manually Disabled)</option>
                                    <option value="Expired" <?= $status_filter == 'Expired' ? 'selected' : '' ?>>Expired (Date Ended)</option>
                                </select>
                            </div>
                            <div class="w-full">
                                <label class="block text-xs text-slate-400 mb-1">Discount Type</label>
                                <select name="type" id="typeFilter" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all" <?= $type_filter == 'all' ? 'selected' : '' ?>>All Types</option>
                                    <option value="percent" <?= $type_filter == 'percent' ? 'selected' : '' ?>>Percentage (%)</option>
                                    <option value="fixed" <?= $type_filter == 'fixed' ? 'selected' : '' ?>>Fixed Amount (₱)</option>
                                </select>
                            </div>
                            <div class="w-full">
                                <label class="block text-xs text-slate-400 mb-1">Sort By</label>
                                <select name="sort" id="sortFilter" class="w-full p-2 rounded-lg filter-select">
                                    <option value="newest" <?= $sort_by == 'newest' ? 'selected' : '' ?>>Newest First</option>
                                    <option value="oldest" <?= $sort_by == 'oldest' ? 'selected' : '' ?>>Oldest First</option>
                                    <option value="code_asc" <?= $sort_by == 'code_asc' ? 'selected' : '' ?>>Code (A-Z)</option>
                                    <option value="end_date_asc" <?= $sort_by == 'end_date_asc' ? 'selected' : '' ?>>End Date (Soonest)</option>
                                    <option value="end_date_desc" <?= $sort_by == 'end_date_desc' ? 'selected' : '' ?>>End Date (Latest)</option>
                                </select>
                            </div>
                            <div class="w-full flex gap-2">
                                <button id="applyFilters" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg">Apply</button>
                                <button id="resetFilters" type="button" class="w-full bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg">Reset</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="bulkActionContainer" class="hidden mb-4 p-4 content-card rounded-lg flex items-center gap-4">
                <select id="bulkActionSelect" class="form-select p-2 bg-slate-700 border-slate-600 rounded-lg">
                    <option value="">Bulk Action...</option> 
                    <option value="activate">Set Status: Enabled</option> 
                    <option value="deactivate">Set Status: Disabled</option> 
                    <option value="delete">Delete Selected</option>
                </select>
                <button id="applyBulkAction" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg">Apply</button>
                <span id="selectionCount" class="text-slate-400"></span>
            </div>

            <div class="content-card rounded-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-slate-800">
                            <tr>
                                <th class="p-4"><input type="checkbox" id="selectAllCheckbox" class="rounded bg-slate-700 border-slate-600 focus:ring-red-500"></th>
                                <th class="p-4 font-semibold">Code</th>
                                <th class="p-4 font-semibold">Type</th>
                                <th class="p-4 font-semibold">Value</th>
                                <th class="p-4 font-semibold">Starts</th>
                                <th class="p-4 font-semibold">Ends</th>
                                <th class="p-4 font-semibold">Status</th>
                                <th class="p-4 font-semibold text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="promotionsTableBody"></tbody>
                    </table>
                </div>
                <div class="p-4 flex flex-col md:flex-row justify-between items-center" id="pagination-container"></div>
            </div>
        </main>
    </div>

    <div id="promotionModal" class="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 hidden transition-opacity duration-300">
        <div class="modal-card rounded-lg w-11/12 md:w-2/3 lg:w-1/2 modal-content overflow-y-auto transition-all duration-300">
            <form id="promotionForm">
                <input type="hidden" name="action_type" id="action_type">
                <input type="hidden" name="promotion_id" id="promotion_id">
                <div class="p-6 md:p-8">
                    <h2 id="modalTitle" class="text-2xl font-bold text-white mb-6">Add New Promotion</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-4 col-span-full">
                            <div>
                                <label for="code" class="block text-slate-400 mb-2 required">Promotion Code</label>
                                <input type="text" id="code" name="code" class="w-full p-2 form-input rounded-lg uppercase">
                                <div class="error-message" id="error-code"></div>
                            </div>
                        </div>
                        
                        <div>
                            <label for="discount_type" class="block text-slate-400 mb-2 required">Discount Type</label>
                            <select id="discount_type" name="discount_type" class="w-full p-2 form-input rounded-lg">
                                <option value="percent">Percentage (%)</option>
                                <option value="fixed">Fixed Amount (₱)</option>
                            </select>
                            <div class="error-message" id="error-discount_type"></div>
                        </div>

                        <div>
                            <label for="discount_value" class="block text-slate-400 mb-2 required">Discount Value</label>
                            <input type="number" id="discount_value" name="discount_value" step="0.01" min="0" class="w-full p-2 form-input rounded-lg">
                            <div class="error-message" id="error-discount_value"></div>
                        </div>
                        
                        <div>
                            <label for="start_date" class="block text-slate-400 mb-2 required">Start Date/Time</label>
                            <input type="text" id="start_date" name="start_date" class="w-full p-2 form-input rounded-lg flatpickr-input" placeholder="Select start date/time">
                            <div class="error-message" id="error-start_date"></div>
                        </div>

                        <div>
                            <label for="end_date" class="block text-slate-400 mb-2 required">End Date/Time</label>
                            <input type="text" id="end_date" name="end_date" class="w-full p-2 form-input rounded-lg flatpickr-input" placeholder="Select end date/time">
                            <div class="error-message" id="error-end_date"></div>
                        </div>
                        
                        <div class="col-span-full">
                             <label for="is_active" class="block text-slate-400 mb-2">Enable Promotion</label>
                            <select id="is_active" name="is_active" class="w-full p-2 form-input rounded-lg">
                                <option value="1">Yes (Allow use, subject to dates)</option>
                                <option value="0">No (Manually Disable)</option>
                            </select>
                        </div>
                        
                    </div>
                    
                    <div id="formMessage" class="mt-6 text-center py-2 text-sm hidden rounded-lg"></div>

                    <div class="mt-8 flex justify-end space-x-4">
                        <button type="button" id="closeModalBtn" class="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg transition">Cancel</button>
                        <button type="submit" id="submitBtn" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition">Save Promotion</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 hidden transition-opacity duration-300">
        <div class="modal-card rounded-lg w-11/12 md:w-1/3 modal-content p-6 transition-all duration-300">
            <h3 class="text-xl font-bold text-white mb-4">Confirm Deletion</h3>
            <p class="text-slate-300 mb-6">Are you sure you want to delete the promotion: <strong id="deletePromotionCode"></strong>? This action cannot be undone.</p>
            <form id="deleteForm">
                <input type="hidden" name="action_type" value="delete_promotion">
                <input type="hidden" name="delete_promotion_id" id="delete_promotion_id">
                <div class="flex justify-end space-x-4">
                    <button type="button" class="bg-slate-600 hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg transition" onclick="document.getElementById('deleteModal').classList.add('hidden');">Cancel</button>
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition">Delete</button>
                </div>
            </form>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const API_ENDPOINT = './promotion.php';  // The script handles its own requests
            const modal = document.getElementById('promotionModal');
            const deleteModal = document.getElementById('deleteModal');
            const promotionForm = document.getElementById('promotionForm');
            const deleteForm = document.getElementById('deleteForm');
            const tableBody = document.getElementById('promotionsTableBody');
            const paginationContainer = document.getElementById('pagination-container');
            const searchInput = document.getElementById('searchInput');
            const addPromotionBtn = document.getElementById('addPromotionBtn');
            const closeModalBtn = document.getElementById('closeModalBtn');
            const formMessage = document.getElementById('formMessage');
            const filterSortForm = document.getElementById('filterSortForm');
            const filterOptions = document.getElementById('filterOptions');
            const toggleFilterBtn = document.getElementById('toggleFilterBtn');
            const applyFiltersBtn = document.getElementById('applyFilters');
            const resetFiltersBtn = document.getElementById('resetFilters');
            const filterInputs = filterOptions.querySelectorAll('select');
            const bulkActionContainer = document.getElementById('bulkActionContainer');
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const applyBulkActionBtn = document.getElementById('applyBulkAction');
            const bulkActionSelect = document.getElementById('bulkActionSelect');
            const selectionCountSpan = document.getElementById('selectionCount');

            let currentURL = new URL(window.location.href);

            // --- Flatpickr Initialization for Date/Time Inputs ---
            flatpickr("#start_date", {
                enableTime: true,
                dateFormat: "Y-m-d H:i",
                time_24hr: true,
                altInput: true,
                altFormat: "F j, Y h:i K",
                theme: "dark"
            });
            flatpickr("#end_date", {
                enableTime: true,
                dateFormat: "Y-m-d H:i",
                time_24hr: true,
                altInput: true,
                altFormat: "F j, Y h:i K",
                theme: "dark"
            });

            // --- Modal Helpers ---
            const openModal = () => { modal.classList.remove('hidden'); document.body.style.overflow = 'hidden'; };
            const closeModal = () => { 
                modal.classList.add('hidden'); 
                document.body.style.overflow = '';
                // Clear validation states
                promotionForm.querySelectorAll('.form-input.is-invalid').forEach(el => el.classList.remove('is-invalid'));
                promotionForm.querySelectorAll('.error-message').forEach(el => el.textContent = '');
                formMessage.classList.add('hidden');
                formMessage.textContent = '';
            };

            const populateModal = async (id) => {
                const submitBtn = document.getElementById('submitBtn');
                submitBtn.disabled = false; // Ensure button is enabled when modal opens

                if (!id) {
                    document.getElementById('modalTitle').textContent = 'Add New Promotion';
                    document.getElementById('action_type').value = 'add_promotion';
                    promotionForm.reset();
                    document.getElementById('promotion_id').value = '';
                    openModal();
                    return;
                }

                document.getElementById('modalTitle').textContent = 'Edit Promotion';
                document.getElementById('action_type').value = 'edit_promotion';
                document.getElementById('promotion_id').value = id;
                formMessage.textContent = 'Loading data...';
                formMessage.className = 'mt-6 text-center py-2 text-sm block rounded-lg bg-slate-800 text-white';

                try {
                    const response = await fetch(`${API_ENDPOINT}?action=get_promotion&id=${id}`);
                    const data = await response.json();

                    if (data.success) {
                        const promo = data.data;
                        document.getElementById('code').value = promo.code;
                        document.getElementById('discount_type').value = promo.discount_type;
                        document.getElementById('discount_value').value = promo.discount_value;
                        document.getElementById('is_active').value = promo.is_active;
                        
                        // Set Flatpickr dates
                        flatpickr("#start_date").setDate(promo.start_date);
                        flatpickr("#end_date").setDate(promo.end_date);
                        
                        formMessage.classList.add('hidden');
                        openModal();
                    } else {
                        alert(data.message);
                    }
                } catch (error) {
                    alert('Failed to fetch promotion data.');
                }
            };
            
            // --- UI Rendering ---
            const getStatusClass = (promo) => {
                // MySQL calculates 'is_currently_active' based on is_active=1 AND dates
                if (promo.is_currently_active == 1) return 'status-Active';
                if (new Date(promo.end_date) < new Date()) return 'status-Expired';
                if (promo.is_active == 0) return 'status-Inactive';
                
                return 'status-Inactive';
            };

            const getStatusText = (promo) => {
                if (promo.is_currently_active == 1) return 'Active';
                if (new Date(promo.end_date) < new Date()) return 'Expired';
                if (promo.is_active == 0) return 'Inactive';
                
                return 'Pending'; // Active but start date is in the future
            };

            const formatValue = (type, value) => {
                if (type === 'percent') return `${parseFloat(value)}%`;
                return `₱${parseFloat(value).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
            };
            
            const renderPromotionRow = (promo) => {
                const statusText = getStatusText(promo);
                const statusClass = getStatusClass(promo);

                return `
                    <tr class="border-b border-slate-800 hover:bg-slate-800 transition promotion-row" data-id="${promo.promotion_id}">
                        <td class="p-4"><input type="checkbox" name="selected_promotions[]" value="${promo.promotion_id}" class="row-checkbox rounded bg-slate-700 border-slate-600 focus:ring-red-500"></td>
                        <td class="p-4 font-semibold text-white">${promo.code}</td>
                        <td class="p-4 capitalize text-slate-400">${promo.discount_type}</td>
                        <td class="p-4 text-green-400 font-mono">${formatValue(promo.discount_type, promo.discount_value)}</td>
                        <td class="p-4 text-sm">${new Date(promo.start_date).toLocaleString()}</td>
                        <td class="p-4 text-sm">${new Date(promo.end_date).toLocaleString()}</td>
                        <td class="p-4"><span class="status-badge ${statusClass}">${statusText}</span></td>
                        <td class="p-4 text-right whitespace-nowrap">
                            <button type="button" data-id="${promo.promotion_id}" class="edit-btn text-blue-400 hover:text-blue-300 font-medium mr-2">Edit</button>
                            <button type="button" data-id="${promo.promotion_id}" data-code="${promo.code}" class="delete-btn text-red-400 hover:text-red-300 font-medium">Delete</button>
                        </td>
                    </tr>
                `;
            };

            const renderTableBody = (promotions) => {
                tableBody.innerHTML = '';
                if (promotions && promotions.length > 0) {
                    tableBody.innerHTML = promotions.map(renderPromotionRow).join('');
                } else {
                    tableBody.innerHTML = '<tr><td colspan="8" class="p-4 text-center text-slate-500">No promotions found matching your criteria.</td></tr>';
                }
                attachEventListeners();
                updateBulkActionVisibility();
            };

            const renderPagination = (data) => {
                paginationContainer.innerHTML = '';
                if (data.total_pages <= 1) return;

                const currentPage = data.current_page;
                const totalPages = data.total_pages;
                
                const createPageLink = (page, text, disabled) => {
                    const newURL = new URL(currentURL.href);
                    newURL.searchParams.set('page', page);
                    return `<a href="${newURL.pathname + newURL.search}" class="px-3 py-1 mx-1 rounded-lg transition ${
                        disabled ? 'text-slate-600 pointer-events-none' : (page === currentPage ? 'bg-red-600 text-white font-bold' : 'bg-slate-700 hover:bg-slate-600 text-white')
                    }">${text}</a>`;
                };

                let html = '<div class="flex items-center">';
                html += createPageLink(currentPage - 1, 'Previous', currentPage <= 1);

                // Page links logic (simplified to show current, prev, next)
                let startPage = Math.max(1, currentPage - 1);
                let endPage = Math.min(totalPages, currentPage + 1);
                
                if (startPage > 1) {
                    html += createPageLink(1, 1, false);
                    if (startPage > 2) html += '<span class="px-2">...</span>';
                }
                
                for (let i = startPage; i <= endPage; i++) {
                    html += createPageLink(i, i, false);
                }
                
                if (endPage < totalPages) {
                    if (endPage < totalPages - 1) html += '<span class="px-2">...</span>';
                    html += createPageLink(totalPages, totalPages, false);
                }

                html += createPageLink(currentPage + 1, 'Next', currentPage >= totalPages);
                html += '</div>';

                html += `<div class="text-sm text-slate-400 mt-2 md:mt-0">Page ${currentPage} of ${totalPages} (${data.total_promotions} total promotions)</div>`;
                
                paginationContainer.innerHTML = html;
            };

            // --- API Calls and Re-render ---
            const loadPromotions = async (page = null) => {
                tableBody.innerHTML = '<tr><td colspan="8" class="p-4 text-center text-slate-500">Loading promotions...</td></tr>';
                
                const currentSearch = currentURL.searchParams.get('search') || '';
                const currentPageParam = page ? `page=${page}` : '';
                
                // Get all active search/filter parameters from the URL
                const searchParams = new URLSearchParams(currentURL.search);
                if (page) searchParams.set('page', page);
                
                const url = `${API_ENDPOINT}?${searchParams.toString()}`;

                try {
                    const response = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                    if (!response.ok) throw new Error('Network response was not ok');
                    
                    const data = await response.json();
                    
                    currentURL.searchParams.set('page', data.pagination.current_page);
                    
                    renderTableBody(data.promotions);
                    renderPagination(data.pagination);
                    checkActiveFilters();
                    
                } catch (error) {
                    console.error('Error loading promotions:', error);
                    tableBody.innerHTML = '<tr><td colspan="8" class="p-4 text-center text-red-500">Failed to load data. Please check server logs.</td></tr>';
                }
            };
            
            const submitForm = async (e) => {
                e.preventDefault();
                const formData = new FormData(promotionForm);
                const submitBtn = document.getElementById('submitBtn');
                
                // Reset errors and button state
                promotionForm.querySelectorAll('.form-input').forEach(el => el.classList.remove('is-invalid'));
                promotionForm.querySelectorAll('.error-message').forEach(el => el.textContent = '');
                formMessage.classList.add('hidden');
                submitBtn.disabled = true; // Button disabled while waiting for API response

                try {
                    const response = await fetch(API_ENDPOINT, { method: 'POST', body: formData });
                    const data = await response.json();

                    if (data.success) {
                        formMessage.textContent = data.message;
                        formMessage.className = 'mt-6 text-center py-2 text-sm block rounded-lg bg-green-900 text-green-300';
                        
                        // FIX: Re-enable the button after success before closing
                        submitBtn.disabled = false; 

                        setTimeout(() => {
                            closeModal();
                            loadPromotions(currentURL.searchParams.get('page'));
                        }, 1500);
                    } else {
                        formMessage.textContent = data.message || 'Error saving promotion.';
                        formMessage.className = 'mt-6 text-center py-2 text-sm block rounded-lg bg-red-900 text-red-300';
                        // Handle field-specific errors
                        if (data.errors) {
                            Object.keys(data.errors).forEach(key => {
                                const input = document.getElementById(key);
                                const errorDiv = document.getElementById(`error-${key}`);
                                if (input) input.classList.add('is-invalid');
                                if (errorDiv) errorDiv.textContent = data.errors[key];
                            });
                        }
                        submitBtn.disabled = false; // Re-enable on error so user can fix and try again
                    }
                } catch (error) {
                    formMessage.textContent = 'Network error. Could not connect to the handler script.';
                    formMessage.className = 'mt-6 text-center py-2 text-sm block rounded-lg bg-red-900 text-red-300';
                    submitBtn.disabled = false; // Re-enable on network failure
                }
            };

            const submitDeleteForm = async (e) => {
                e.preventDefault();
                const formData = new FormData(deleteForm);
                
                try {
                    const response = await fetch(API_ENDPOINT, { method: 'POST', body: formData });
                    const data = await response.json();

                    if (data.success) {
                        deleteModal.classList.add('hidden');
                        loadPromotions(currentURL.searchParams.get('page'));
                        alert(data.message);
                    } else {
                        alert(data.message || 'Error deleting promotion.');
                    }
                } catch (error) {
                    alert('Network error during deletion.');
                }
            };
            
            // --- Event Listeners and Initialization ---
            const attachEventListeners = () => {
                document.querySelectorAll('.edit-btn').forEach(btn => {
                    btn.onclick = () => populateModal(btn.dataset.id);
                });
                
                document.querySelectorAll('.delete-btn').forEach(btn => {
                    btn.onclick = () => {
                        document.getElementById('delete_promotion_id').value = btn.dataset.id;
                        document.getElementById('deletePromotionCode').textContent = btn.dataset.code;
                        deleteModal.classList.remove('hidden');
                    };
                });
                
                document.querySelectorAll('.row-checkbox').forEach(checkbox => {
                    checkbox.onchange = updateBulkActionVisibility;
                });
            };

            addPromotionBtn.onclick = () => populateModal(null);
            closeModalBtn.onclick = closeModal;
            modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
            promotionForm.onsubmit = submitForm;
            deleteForm.onsubmit = submitDeleteForm;

            // --- Filtering Logic ---
            const applyFilters = (e) => {
                if (e) e.preventDefault();
                const newURL = new URL(window.location.pathname, window.location.origin);
                
                if (searchInput.value) newURL.searchParams.set('search', searchInput.value);
                if (statusFilter.value !== 'all') newURL.searchParams.set('status', statusFilter.value);
                if (typeFilter.value !== 'all') newURL.searchParams.set('type', typeFilter.value);
                if (sortFilter.value !== 'newest') newURL.searchParams.set('sort', sortFilter.value);

                // Set page back to 1 when filters change
                newURL.searchParams.set('page', 1);

                window.location.href = newURL.href;
            };
            
            const resetFilters = () => {
                window.location.href = window.location.pathname; // Reloads without any query parameters
            };
            
            const checkActiveFilters = () => {
                const urlParams = currentURL.searchParams;
                let filterCount = 0;
                
                // Count filters other than search and page
                if (urlParams.get('status') && urlParams.get('status') !== 'all') filterCount++;
                if (urlParams.get('type') && urlParams.get('type') !== 'all') filterCount++;
                if (urlParams.get('sort') && urlParams.get('sort') !== 'newest') filterCount++;
                
                const badge = document.getElementById('filterCountBadge');
                if (filterCount > 0) {
                    badge.textContent = filterCount;
                    badge.classList.add('visible');
                    // Ensure filter options are shown if filters are active
                    if (filterOptions.style.maxHeight === '0px') {
                         filterOptions.style.maxHeight = `${filterOptions.scrollHeight}px`;
                         filterOptions.style.opacity = '1';
                         filterOptions.style.paddingTop = '1rem';
                    }
                    toggleFilterBtn.querySelector('.filter-icon').style.transform = 'rotate(180deg)';

                } else {
                    badge.classList.remove('visible');
                }
            };
            
            toggleFilterBtn.onclick = () => {
                const isHidden = filterOptions.style.maxHeight === '0px';
                if (isHidden) {
                    filterOptions.style.maxHeight = `${filterOptions.scrollHeight}px`;
                    filterOptions.style.opacity = '1';
                    filterOptions.style.paddingTop = '1rem';
                    toggleFilterBtn.querySelector('.filter-icon').style.transform = 'rotate(180deg)';
                } else {
                    filterOptions.style.maxHeight = '0px';
                    filterOptions.style.opacity = '0';
                    filterOptions.style.paddingTop = '0';
                    toggleFilterBtn.querySelector('.filter-icon').style.transform = 'rotate(0deg)';
                }
            };

            applyFiltersBtn.onclick = applyFilters;
            resetFiltersBtn.onclick = resetFilters;
            searchInput.onkeypress = (e) => { if(e.key === 'Enter') applyFilters(e); };

            // --- Bulk Action Logic ---
            const updateBulkActionVisibility = () => {
                const checkedBoxes = document.querySelectorAll('.row-checkbox:checked');
                if (checkedBoxes.length > 0) {
                    bulkActionContainer.classList.remove('hidden');
                    selectionCountSpan.textContent = `${checkedBoxes.length} selected`;
                } else {
                    bulkActionContainer.classList.add('hidden');
                }
                
                // If all rows are checked, check the select-all checkbox
                const totalRows = document.querySelectorAll('.promotion-row').length;
                selectAllCheckbox.checked = totalRows > 0 && checkedBoxes.length === totalRows;
            };

            selectAllCheckbox.onchange = (e) => {
                document.querySelectorAll('.row-checkbox').forEach(checkbox => {
                    checkbox.checked = e.target.checked;
                });
                updateBulkActionVisibility();
            };
            
            applyBulkActionBtn.onclick = async () => {
                const actionType = bulkActionSelect.value;
                const checkedBoxes = document.querySelectorAll('.row-checkbox:checked');
                const promotionIds = Array.from(checkedBoxes).map(cb => cb.value);

                if (!actionType) {
                    alert('Please select a bulk action.');
                    return;
                }
                if (promotionIds.length === 0) {
                    alert('Please select at least one promotion.');
                    return;
                }
                
                if (!confirm(`Are you sure you want to perform the action "${actionType.toUpperCase()}" on ${promotionIds.length} promotions?`)) {
                    return;
                }
                
                const formData = new FormData();
                formData.append('action_type', 'bulk_action');
                formData.append('bulk_action_type', actionType);
                promotionIds.forEach(id => formData.append('promotion_ids[]', id));
                
                try {
                    const response = await fetch(API_ENDPOINT, { method: 'POST', body: formData });
                    const data = await response.json();
                    
                    if (data.success) {
                        alert(data.message);
                        loadPromotions(currentURL.searchParams.get('page'));
                    } else {
                        alert(data.message || 'Bulk action failed.');
                    }
                } catch (error) {
                    alert('Network error during bulk action.');
                }
            };

            // --- Initial Load ---
            loadPromotions();
        });
    </script>
</body>
</html>