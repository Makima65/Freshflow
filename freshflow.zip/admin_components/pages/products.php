<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\products.php

// 1. START BUFFERING
ob_start();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- DATABASE CONNECTION ---
include_once '../includes/db_connection.php';

// --- CONFIGURATION ---
if (!defined('LOW_STOCK_THRESHOLD')) {
    define('LOW_STOCK_THRESHOLD', 10);
}

// --- AUDIT HELPER ---
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) {
    include_once $auditHelperPath;
} elseif (!function_exists('log_audit_action')) {
    function log_audit_action($a, $b, $c, $d = []) { return true; }
}

// --- CONNECTION CHECK ---
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed. Error: " . (isset($conn) ? $conn->connect_error : 'Connection variable not set.'));
}

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../admin_login.php");
    exit;
}

// ---------------------------------------------------------
// SERVER-SIDE CATEGORY LOADING
// ---------------------------------------------------------
$category_options = '<option value="">-- Select Category --</option>';
$cat_query = "SELECT * FROM categories ORDER BY category_name ASC";
$cat_result = $conn->query($cat_query);

if ($cat_result) {
    while ($row = $cat_result->fetch_assoc()) {
        $c_id = isset($row['category_id']) ? $row['category_id'] : (isset($row['id']) ? $row['id'] : null);
        $c_name = isset($row['category_name']) ? $row['category_name'] : (isset($row['name']) ? $row['name'] : 'Unknown');
        if ($c_id) {
            $category_options .= '<option value="' . $c_id . '">' . htmlspecialchars($c_name) . '</option>';
        }
    }
}

/**
 * Handles file uploads.
 */
function handle_upload($file_key, $image_type, $existing_url = '') {
    if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] == 0) {
        $relative_dir = ($image_type === 'main') ? "assets/img/products/main/" : "assets/img/products/thumbnails/";
        $target_dir = "../../" . $relative_dir;
        if (!is_dir($target_dir)) @mkdir($target_dir, 0777, true);
        
        $file_name = uniqid() . '-' . preg_replace("/[^a-zA-Z0-9.\-_]+/", "", basename($_FILES[$file_key]["name"]));
        $target_file = $target_dir . $file_name;
        
        if (move_uploaded_file($_FILES[$file_key]["tmp_name"], $target_file)) {
            if ($existing_url && file_exists("../../" . $existing_url)) @unlink("../../" . $existing_url);
            return $relative_dir . $file_name;
        }
    }
    return $existing_url;
}

// --- CENTRALIZED HANDLER WITH DETAILED AUDIT ---
function handle_request($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
        ob_clean(); // Clean buffer
        header('Content-Type: application/json');
        
        if ($_GET['action'] == 'get_product' && isset($_GET['id'])) {
            $product_id = intval($_GET['id']);
            $stmt = $conn->prepare("
                SELECT p.*, pi.quantity, c.category_name, c.category_id as joined_cat_id
                FROM products p
                LEFT JOIN product_inventory pi ON p.product_id = pi.product_id
                LEFT JOIN categories c ON p.category_id = c.category_id
                WHERE p.product_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($product = $result->fetch_assoc()) {
                if(empty($product['category_id']) && !empty($product['joined_cat_id'])) {
                    $product['category_id'] = $product['joined_cat_id'];
                }
                echo json_encode(['success' => true, 'data' => $product]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Not found']);
            }
            $stmt->close();
            exit;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        ob_clean(); // Clean buffer
        header('Content-Type: application/json');
        $action = $_POST['action_type'] ?? '';
        $admin_id = $_SESSION["user_id"] ?? 0;

        // 1. ADD / EDIT PRODUCT
        if ($action === 'add_product' || $action === 'edit_product') {
            $is_edit = ($action === 'edit_product');
            $product_id = $is_edit ? intval($_POST['product_id']) : 0;
            
            $errors = [];
            if (empty(trim($_POST['name']))) $errors['name'] = 'Product name required.';
            if (empty($_POST['category_id'])) $errors['category_id'] = 'Category required.';
            if (!isset($_POST['price'])) $errors['price'] = 'Price required.';
            if (empty(trim($_POST['unit']))) $errors['unit'] = 'Unit required.';

            if (empty($errors)) {
                $conn->begin_transaction();
                try {
                    // Collect New Data
                    $name = trim($_POST['name']);
                    $category_id = (!empty($_POST['category_id'])) ? $_POST['category_id'] : NULL;
                    $description = trim($_POST['description']);
                    $specifications = trim($_POST['specifications']);
                    $price = floatval($_POST['price']);
                    
                    // FIXED: If weight is empty (because it was disabled/not needed), default to 0
                    $weight = !empty($_POST['weight']) ? floatval($_POST['weight']) : 0;
                    
                    $unit = trim($_POST['unit']);
                    
                    $expiration_date = $_POST['expiration_date'] ?? '';
                    if (empty($expiration_date) || $expiration_date === 'null') {
                        $expiration_date = NULL;
                    }

                    $status = $_POST['status'];
                    $product_brand = trim($_POST['product_brand']);
                    $quantity = floatval($_POST['quantity']);
                    $image_url = handle_upload('image_url', 'main', $_POST['existing_image_url'] ?? '');

                    // --- [STEP 1] FETCH OLD DATA FOR COMPARISON ---
                    $changes = [];
                    $old_stock = 0;
                    
                    if ($is_edit) {
                        $old_stmt = $conn->prepare("SELECT p.*, pi.quantity FROM products p LEFT JOIN product_inventory pi ON p.product_id = pi.product_id WHERE p.product_id = ?");
                        $old_stmt->bind_param("i", $product_id);
                        $old_stmt->execute();
                        $old_data = $old_stmt->get_result()->fetch_assoc();
                        
                        if ($old_data) {
                            $old_stock = floatval($old_data['quantity'] ?? 0);
                            
                            // 1. Name Change
                            if ($old_data['name'] !== $name) $changes[] = "Name changed";
                            
                            // 2. Brand Change
                            $old_brand = trim($old_data['product_brand'] ?? '');
                            if ($old_brand !== $product_brand) $changes[] = "Brand: '$old_brand' -> '$product_brand'";
                            
                            // 3. Price Change
                            if (floatval($old_data['price']) !== $price) $changes[] = "Price: " . number_format($old_data['price'], 2) . " -> " . number_format($price, 2);
                            
                            // 4. Status Change
                            if ($old_data['status'] !== $status) $changes[] = "Status: {$old_data['status']} -> $status";
                            
                            // 5. Unit Change
                            $old_unit = isset($old_data['unit']) ? $old_data['unit'] : '';
                            if ($old_unit !== $unit) $changes[] = "Unit: '$old_unit' -> '$unit'";

                            // 6. Expiry Change
                            if ($old_data['expiration_date'] !== $expiration_date) $changes[] = "Expiry: " . ($old_data['expiration_date'] ?? 'None') . " -> " . ($expiration_date ?? 'None');
                            
                            // 7. Category Change (WITH NAME LOOKUP)
                            if ($old_data['category_id'] != $category_id) {
                                $old_cat_name = 'Unknown';
                                $new_cat_name = 'Unknown';

                                // Get Old Category Name
                                if (!empty($old_data['category_id'])) {
                                    $cat_q1 = $conn->query("SELECT category_name FROM categories WHERE category_id = " . intval($old_data['category_id']));
                                    if ($cat_q1 && $r = $cat_q1->fetch_assoc()) $old_cat_name = $r['category_name'];
                                } else { $old_cat_name = "None"; }

                                // Get New Category Name
                                if (!empty($category_id)) {
                                    $cat_q2 = $conn->query("SELECT category_name FROM categories WHERE category_id = " . intval($category_id));
                                    if ($cat_q2 && $r = $cat_q2->fetch_assoc()) $new_cat_name = $r['category_name'];
                                } else { $new_cat_name = "None"; }

                                $changes[] = "Category: '$old_cat_name' -> '$new_cat_name'";
                            }

                            // 8. Stock Change
                            if ($old_stock !== $quantity) $changes[] = "Stock: $old_stock -> $quantity";
                        }
                    }

                    // --- [STEP 2] PERFORM UPDATE/INSERT ---
                    if ($is_edit) {
                        $stmt = $conn->prepare("UPDATE products SET category_id=?, name=?, description=?, specifications=?, price=?, weight=?, unit=?, expiration_date=?, status=?, image_url=?, product_brand=? WHERE product_id=?");
                        $stmt->bind_param("sssdsdsssssi", $category_id, $name, $description, $specifications, $price, $weight, $unit, $expiration_date, $status, $image_url, $product_brand, $product_id);
                        if(!$stmt->execute()) throw new Exception($stmt->error);
                        
                        $conn->query("DELETE FROM product_inventory WHERE product_id = $product_id");
                        $stmt = $conn->prepare("INSERT INTO product_inventory (product_id, quantity) VALUES (?, ?)");
                        $stmt->bind_param("id", $product_id, $quantity);
                        $stmt->execute();
                    } else {
                        $stmt = $conn->prepare("INSERT INTO products (category_id, name, description, specifications, price, weight, unit, expiration_date, status, image_url, product_brand) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssdsdsssss", $category_id, $name, $description, $specifications, $price, $weight, $unit, $expiration_date, $status, $image_url, $product_brand);
                        if(!$stmt->execute()) throw new Exception($stmt->error);
                        $product_id = $conn->insert_id;
                        
                        $stmt = $conn->prepare("INSERT INTO product_inventory (product_id, quantity) VALUES (?, ?)");
                        $stmt->bind_param("id", $product_id, $quantity);
                        $stmt->execute();
                    }
                    
                    // Thumbnails
                    $thumb_urls = [];
                    for($i=1; $i<=4; $i++) $thumb_urls[$i] = handle_upload("thumbnail_img_$i", 'thumbnail', $_POST["existing_thumbnail_img_$i"] ?? '');
                    
                    $conn->query("DELETE FROM thumbnail WHERE product_id = $product_id");
                    $stmt = $conn->prepare("INSERT INTO thumbnail (product_id, thumbnail_img_1, thumbnail_img_2, thumbnail_img_3, thumbnail_img_4) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("issss", $product_id, $thumb_urls[1], $thumb_urls[2], $thumb_urls[3], $thumb_urls[4]);
                    $stmt->execute();

                    $conn->commit();
                    
                    // --- [STEP 3] LOG THE SPECIFIC CHANGES ---
                    if (function_exists('log_audit_action')) {
                        if ($is_edit) {
                            if (!empty($changes)) {
                                log_audit_action('Update Product', 'Products', "Updated '$name'. Details: " . implode(", ", $changes));
                            } else {
                                log_audit_action('Update Product', 'Products', "Updated product '$name' (No major changes detected).");
                            }
                        } else {
                            log_audit_action('Add Product', 'Products', "Added new product '$name'. Unit: $unit, Initial Stock: $quantity");
                        }
                    }

                    echo json_encode(['success' => true, 'message' => "Product saved successfully!"]);
                } catch (Exception $e) {
                    $conn->rollback();
                    echo json_encode(['success' => false, 'message' => "Error: " . $e->getMessage()]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => "Validation errors.", 'errors' => $errors]);
            }
        }
        
        // 2. DELETE PRODUCT
        elseif ($action === 'delete_product') {
            $product_id = intval($_POST['delete_product_id'] ?? 0);
            if ($product_id > 0) {
                try {
                    $name_query = $conn->query("SELECT name FROM products WHERE product_id = $product_id");
                    $prod_name = ($name_query && $row = $name_query->fetch_assoc()) ? $row['name'] : "ID #$product_id";

                    $conn->begin_transaction();
                    $conn->query("SET FOREIGN_KEY_CHECKS=0");
                    $conn->query("DELETE FROM product_inventory WHERE product_id = $product_id");
                    $conn->query("DELETE FROM thumbnail WHERE product_id = $product_id");
                    $conn->query("DELETE FROM products WHERE product_id = $product_id");
                    $conn->query("SET FOREIGN_KEY_CHECKS=1");
                    $conn->commit();

                    if (function_exists('log_audit_action')) {
                        log_audit_action('Delete Product', 'Products', "Deleted product '$prod_name'.");
                    }

                    echo json_encode(['success' => true, 'message' => "Product deleted."]);
                } catch (Exception $e) {
                    $conn->rollback();
                    $conn->query("SET FOREIGN_KEY_CHECKS=1");
                    echo json_encode(['success' => false, 'message' => "Failed: " . $e->getMessage()]);
                }
            }
        }
        
        // 3. UPDATE STOCK (Quick Action)
        elseif ($action === 'update_stock') {
            $product_id = intval($_POST['product_id'] ?? 0);
            $quantity = floatval($_POST['quantity'] ?? -1);
            if ($product_id > 0 && $quantity >= 0) {
                $old_q_query = $conn->query("SELECT quantity FROM product_inventory WHERE product_id = $product_id");
                $old_quantity = ($old_q_query && $row = $old_q_query->fetch_assoc()) ? $row['quantity'] : 0;
                
                $name_query = $conn->query("SELECT name FROM products WHERE product_id = $product_id");
                $prod_name = ($name_query && $row = $name_query->fetch_assoc()) ? $row['name'] : "ID #$product_id";

                $conn->query("DELETE FROM product_inventory WHERE product_id = $product_id");
                $conn->query("INSERT INTO product_inventory (product_id, quantity) VALUES ($product_id, $quantity)");
                $status = ($quantity > 0) ? 'Active' : 'Out of stock';
                $conn->query("UPDATE products SET status = '$status' WHERE product_id = $product_id");

                if (function_exists('log_audit_action')) {
                    $log_details = "Manual Stock Update for '$prod_name': $old_quantity -> $quantity";
                    log_audit_action('Update Stock', 'Inventory', $log_details);
                }

                echo json_encode(['success' => true, 'message' => "Stock updated."]);
            }
        }
        
        // 4. BULK ACTIONS
        elseif ($action === 'bulk_action') {
            $raw_ids = $_POST['product_ids'] ?? [];
            if(is_string($raw_ids)) { $ids = array_map('intval', explode(',', $raw_ids)); } 
            else { $ids = array_map('intval', $raw_ids); }
            $type = $_POST['bulk_action_type'] ?? '';
            
            if(!empty($ids) && $type) {
                $id_str = implode(',', $ids);
                try {
                    $conn->begin_transaction();
                    $log_msg = "";
                    
                    if($type === 'delete') {
                        $conn->query("SET FOREIGN_KEY_CHECKS=0");
                        $conn->query("DELETE FROM product_inventory WHERE product_id IN ($id_str)");
                        $conn->query("DELETE FROM thumbnail WHERE product_id IN ($id_str)");
                        $conn->query("DELETE FROM products WHERE product_id IN ($id_str)");
                        $conn->query("SET FOREIGN_KEY_CHECKS=1");
                        $msg = "Deleted items.";
                        $log_msg = "Bulk Deleted " . count($ids) . " products.";
                    } elseif($type === 'activate') {
                        $conn->query("UPDATE products SET status='Active' WHERE product_id IN ($id_str)");
                        $msg = "Activated items.";
                        $log_msg = "Bulk Activated " . count($ids) . " products.";
                    } elseif($type === 'deactivate') {
                        $conn->query("UPDATE products SET status='Inactive' WHERE product_id IN ($id_str)");
                        $msg = "Deactivated items.";
                        $log_msg = "Bulk Deactivated " . count($ids) . " products.";
                    }
                    $conn->commit();

                    if (function_exists('log_audit_action') && $log_msg) {
                        log_audit_action('Bulk Action', 'Products', $log_msg);
                    }

                    echo json_encode(['success' => true, 'message' => $msg]);
                } catch (Exception $e) {
                    $conn->rollback();
                    $conn->query("SET FOREIGN_KEY_CHECKS=1");
                    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'No items selected.']);
            }
        }
        exit();
    }
}

handle_request($conn);

// 2. FLUSH BUFFER
ob_end_flush();

// --- PAGINATION & FILTERING ---
$products_per_page = 10;
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $products_per_page;
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$brand_filter = isset($_GET['brand']) ? $_GET['brand'] : 'all';
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// --- STATUS LOGIC ---
$status_case = "CASE 
    WHEN p.status = 'Inactive' THEN 'Inactive'
    WHEN p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date < CURDATE() THEN 'Expired'
    WHEN COALESCE(pi.quantity, 0) <= 0 THEN 'Out of Stock'
    WHEN (p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)) 
          AND (COALESCE(pi.quantity, 0) <= " . LOW_STOCK_THRESHOLD . ") 
    THEN 'Expiring & Low Stock'
    WHEN p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'Expiring Soon'
    WHEN COALESCE(pi.quantity, 0) <= " . LOW_STOCK_THRESHOLD . " THEN 'Low Stock'
    ELSE 'Active'
END";

$where_clauses = []; 
if (!empty($search_term)) $where_clauses[] = "(p.name LIKE '%$search_term%' OR p.product_brand LIKE '%$search_term%')";
if ($brand_filter !== 'all') $where_clauses[] = "p.product_brand = '$brand_filter'";
if ($status_filter !== 'all') $where_clauses[] = "($status_case) = '$status_filter'";

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

$sort_sql = match($sort_by) {
    'oldest' => 'p.created_at ASC',
    'name_asc' => 'p.name ASC',
    'name_desc' => 'p.name DESC',
    'price_asc' => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    default => 'p.created_at DESC'
};

$count_res = $conn->query("SELECT COUNT(DISTINCT p.product_id) as count FROM products p LEFT JOIN product_inventory pi ON p.product_id = pi.product_id $where_sql");
$total_products_count = $count_res->fetch_assoc()['count'];
$total_pages = ceil($total_products_count / $products_per_page);

$products_sql = "SELECT p.*, MAX(pi.quantity) as quantity, c.category_name, $status_case as computed_status
                 FROM products p 
                 LEFT JOIN product_inventory pi ON p.product_id = pi.product_id 
                 LEFT JOIN categories c ON p.category_id = c.category_id 
                 $where_sql 
                 GROUP BY p.product_id 
                 ORDER BY $sort_sql LIMIT $products_per_page OFFSET $offset";
$products_data = $conn->query($products_sql)->fetch_all(MYSQLI_ASSOC);

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    ob_clean();
    header('Content-Type: application/json');
    echo json_encode(['products' => $products_data, 'pagination' => ['total_products' => $total_products_count, 'total_pages' => $total_pages, 'current_page' => $current_page]]);
    exit;
}

$total_products = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$active_products = $conn->query("SELECT COUNT(*) as c FROM products WHERE status = 'Active'")->fetch_assoc()['c'];
$out_of_stock_products = $conn->query("SELECT COUNT(*) as c FROM product_inventory WHERE quantity = 0")->fetch_assoc()['c'];
$total_stock_value = $conn->query("SELECT SUM(p.price * pi.quantity) as v FROM products p JOIN product_inventory pi ON p.product_id = pi.product_id WHERE p.status='Active'")->fetch_assoc()['v'] ?? 0;
$brands = $conn->query("SELECT DISTINCT product_brand FROM products WHERE product_brand != '' ORDER BY product_brand ASC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Product Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-green: #1E3A1D; --brand-cream: #F8F5EE; --text-dark: #2B2B2B; --accent-green: #3E6E41; --accent-red: #B33333; }
        body { font-family: 'Inter', sans-serif; background-color: var(--brand-cream); color: var(--text-dark); }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .content-card { background-color: #ffffff; border: 1px solid #e5e7eb; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .form-input, .filter-select { background-color: #ffffff; border: 1px solid #d1d5db; color: #374151; }
        .form-input:focus, .filter-select:focus { outline: none; border-color: var(--brand-green); box-shadow: 0 0 0 3px rgba(30, 58, 29, 0.1); }
        .modal-card { background-color: #ffffff; border-radius: 1rem; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); }
        .modal { transition: opacity 0.3s ease; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        
        /* Your original status badge colors */
        .status-badge { padding: 4px 12px; border-radius: 9999px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; display: inline-block; white-space: nowrap; }
        .status-Active { background-color: #dcfce7; color: #166534; } 
        .status-Inactive { background-color: #f3f4f6; color: #4b5563; }
        .status-Out-of-Stock { background-color: #fee2e2; color: #991b1b; } 
        .status-Low-Stock { background-color: #fef9c3; color: #854d0e; }
        .status-Expired { background-color: #f3e8ff; color: #6b21a8; }
        .status-Expiring-Soon { background-color: #ffedd5; color: #9a3412; }
        .status-Expiring-Low-Stock { background-color: #c2410c; color: #ffffff; border: 2px solid #ea580c; box-shadow: 0 2px 4px rgba(194, 65, 12, 0.3); }

        .btn-primary { background-color: var(--brand-green); color: white; }
        .btn-primary:hover { background-color: #2a4e29; }
        .btn-danger { background-color: var(--accent-red); color: white; }
        #filterCountBadge { position: absolute; top: -5px; right: -5px; background-color: var(--accent-red); color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; display: flex; justify-content: center; align-items: center; font-weight: bold; transform: scale(0); transition: transform 0.2s; }
        #filterCountBadge.visible { transform: scale(1); }
        .image-preview-label { cursor: pointer; display: block; }
        .action-menu { z-index: 100 !important; min-width: 160px; position: absolute; right: 2rem; margin-top: 0.5rem; background: white; border: 1px solid #e5e7eb; border-radius: 0.5rem; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
        .relative-cell { position: relative; }
        .overflow-visible-container { overflow: visible !important; min-height: 400px; }
        
        /* Disabled Input Styling */
        .form-input:disabled { background-color: #f3f4f6; cursor: not-allowed; color: #9ca3af; }
    </style>
</head>
<body>
    
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 transition-all duration-300">
        <main class="p-6 md:p-8">
            <div id="flashMessage" class="fixed top-8 right-8 text-white py-3 px-6 rounded-lg shadow-xl text-sm font-bold transform translate-x-full transition-all duration-500 z-[200] opacity-0 pointer-events-none"></div>

            <header class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <div>
                    <h1 class="font-heading text-3xl font-bold text-[#1E3A1D] mb-1">Product Management</h1>
                    <p class="text-sm text-gray-500">Manage inventory, prices, and stock levels</p>
                </div>
                <div class="flex items-center space-x-4 mt-4 md:mt-0">
                    <button id="addProductBtn" class="btn-primary font-bold py-2 px-6 rounded-lg flex items-center space-x-2 transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                        <span class="material-icons">add</span>
                        <span>Add Product</span>
                    </button>
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 text-center">
                 <div class="content-card p-6">
                      <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Products</p>
                      <p class="font-heading text-3xl font-bold text-[#1E3A1D] mt-1"><?= number_format($total_products) ?></p>
                 </div>
                <div class="content-card p-6">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Active Listings</p>
                    <p class="font-heading text-3xl font-bold text-[#3E6E41] mt-1"><?= number_format($active_products) ?></p>
                </div>
                <div class="content-card p-6">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Out of Stock</p>
                    <p class="font-heading text-3xl font-bold text-[#B33333] mt-1"><?= number_format($out_of_stock_products) ?></p>
                </div>
                <div class="content-card p-6">
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Stock Value</p>
                    <p class="font-heading text-3xl font-bold text-[#1E3A1D] mt-1">₱<?= number_format($total_stock_value, 2) ?></p>
                </div>
            </div>

            <div class="content-card p-4 mb-6 relative z-10">
                <div id="filterSortForm">
                    <div class="flex flex-col md:flex-row items-center gap-4">
                        <div class="relative w-full flex-grow">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400"><span class="material-icons">search</span></span>
                            <input type="text" id="searchInput" placeholder="Search products..." value="<?= htmlspecialchars($search_term) ?>" class="w-full pl-10 p-2 rounded-lg form-input" autocomplete="off">
                        </div>
                        <button id="toggleFilterBtn" class="relative flex-shrink-0 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-2 px-4 rounded-lg flex items-center space-x-2 transition shadow-sm">
                            <span class="material-icons">filter_list</span>
                            <span>Filter</span>
                            <span id="filterCountBadge"></span>
                        </button>
                    </div>
                    
                    <div id="filterOptions" style="max-height: 0px; opacity: 0; overflow: hidden; transition: all 0.3s ease;">
                        <div class="border-t border-gray-200 mt-4 pt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                            <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Status</label>
                                <select id="statusFilter" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all">All Statuses</option>
                                    <option value="Active">Active (Healthy)</option>
                                    <option value="Low Stock">Low Stock</option>
                                    <option value="Out of Stock">Out of Stock</option>
                                    <option value="Expiring Soon">Expiring Soon</option>
                                    <option value="Expiring & Low Stock">Expiring & Low Stock</option>
                                    <option value="Expired">Expired</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Brand</label>
                                <select id="brandFilter" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all">All Brands</option>
                                    <?php foreach ($brands as $brand): ?>
                                    <option value="<?= htmlspecialchars($brand['product_brand']) ?>"><?= htmlspecialchars($brand['product_brand']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                             <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Sort By</label>
                                <select id="sortFilter" class="w-full p-2 rounded-lg filter-select">
                                     <option value="newest">Newest</option>
                                     <option value="oldest">Oldest</option>
                                     <option value="name_asc">Name (A-Z)</option>
                                     <option value="price_asc">Price (Low-High)</option>
                                     <option value="price_desc">Price (High-Low)</option>
                                </select>
                            </div>
                            <div class="w-full flex gap-2">
                                <button id="applyFilters" class="w-full btn-primary font-bold py-2 px-4 rounded-lg">Apply</button>
                                <button id="resetFilters" type="button" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-2 px-4 rounded-lg">Reset</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="bulkActionContainer" class="hidden mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center gap-4">
                 <span class="text-yellow-800 font-semibold" id="selectionCount"></span>
                 <select id="bulkActionSelect" class="form-select p-2 bg-white border border-yellow-300 rounded-lg text-sm">
                     <option value="">Choose Action...</option> 
                     <option value="activate">Set Active</option> 
                     <option value="deactivate">Set Inactive</option> 
                     <option value="delete">Delete Selected</option>
                 </select>
                 <button id="applyBulkAction" class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-1.5 px-4 rounded-lg text-sm">Apply</button>
            </div>

            <div class="content-card overflow-visible-container">
                <div class="overflow-x-auto min-h-[400px]"> 
                    <table class="w-full text-left">
                        <thead class="bg-[#1E3A1D] text-white">
                            <tr>
                                <th class="p-4 w-10"><input type="checkbox" id="selectAllCheckbox" class="rounded text-green-600 focus:ring-green-500"></th>
                                <th class="p-4 font-semibold">Product</th>
                                <th class="p-4 font-semibold">Category</th>
                                <th class="p-4 font-semibold">Weight</th>
                                <th class="p-4 font-semibold">Expiry</th>
                                <th class="p-4 font-semibold">Price</th>
                                <th class="p-4 font-semibold">Stock</th>
                                <th class="p-4 font-semibold">Status</th>
                                <th class="p-4 font-semibold text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="productsTableBody" class="text-gray-700 divide-y divide-gray-100"></tbody>
                    </table>
                </div>
                 <div class="p-4 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4" id="pagination-container"></div>
            </div>
        </main>
    </div>

    <div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 hidden transition-opacity duration-300 backdrop-blur-sm">
        <div class="modal-card w-11/12 md:w-3/4 lg:w-2/3 max-h-[90vh] overflow-y-auto">
            <form id="productForm" enctype="multipart/form-data">
                <input type="hidden" name="action_type" id="action_type">
                <input type="hidden" name="product_id" id="product_id">
                <div class="bg-[#1E3A1D] p-6 text-white rounded-t-lg flex justify-between items-center">
                    <h2 id="modalTitle" class="text-2xl font-bold">Add New Product</h2>
                    <button type="button" id="cancelBtn" class="text-white hover:text-gray-300"><span class="material-icons">close</span></button>
                </div>
                <div class="p-6 md:p-8 space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-4">
                            <div><label class="block text-sm font-bold text-gray-700 mb-1">Product Name <span class="text-red-500">*</span></label><input type="text" id="name" name="name" class="w-full p-2 form-input rounded-lg" required><div class="text-red-500 text-xs mt-1" id="error-name"></div></div>
                            <div class="grid grid-cols-2 gap-4">
                                <div><label class="block text-sm font-bold text-gray-700 mb-1">Brand</label><input type="text" id="product_brand" name="product_brand" class="w-full p-2 form-input rounded-lg"></div>
                                <div><label class="block text-sm font-bold text-gray-700 mb-1">Category <span class="text-red-500">*</span></label><select id="category_id" name="category_id" class="w-full p-2 form-input rounded-lg" required><?= $category_options ?></select></div>
                            </div>
                             <div class="grid grid-cols-2 gap-4">
                                <div><label class="block text-sm font-bold text-gray-700 mb-1">Price (₱) <span class="text-red-500">*</span></label><input type="number" id="price" name="price" step="0.01" min="0" class="w-full p-2 form-input rounded-lg" required></div>
                                <div>
                                    <label class="block text-sm font-bold text-gray-700 mb-1">Stock <span class="text-red-500">*</span></label>
                                    <input type="number" id="quantity" name="quantity" min="0" step="0.01" class="w-full p-2 form-input rounded-lg" required>
                                </div>
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-bold text-gray-700 mb-1">Unit Type <span class="text-red-500">*</span></label>
                                    <select id="unit" name="unit" class="w-full p-2 form-input rounded-lg" required>
                                        <option value="pcs">Pieces (pcs)</option>
                                        <option value="pack">Pack</option>
                                        <option value="box">Box</option>
                                        <option value="kg">Kilograms (kg)</option>
                                        <option value="g">Grams (g)</option>
                                        <option value="liter">Liter</option>
                                        <option value="bottle">Bottle</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-bold text-gray-700 mb-1">Weight (kg/g)</label>
                                    <input type="number" id="weight" name="weight" step="0.01" class="w-full p-2 form-input rounded-lg" placeholder="Optional for pcs">
                                </div>
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div><label class="block text-sm font-bold text-gray-700 mb-1">Expiration Date</label><input type="date" id="expiration_date" name="expiration_date" class="w-full p-2 form-input rounded-lg"></div>
                                <div><label class="block text-sm font-bold text-gray-700 mb-1">Status</label><select id="status" name="status" class="w-full p-2 form-input rounded-lg"><option value="Active">Active</option><option value="Inactive">Inactive</option></select></div>
                            </div>
                        </div>
                        <div class="space-y-4">
                            <div><label class="block text-sm font-bold text-gray-700 mb-1">Main Image</label><label class="image-preview-label group"><div class="relative overflow-hidden rounded-lg border-2 border-dashed border-gray-300 group-hover:border-[#1E3A1D] transition-colors"><img id="image_url_preview" src="../../assets/img/placeholder.png" class="w-full h-48 object-cover bg-gray-50"><div class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-10 transition duration-300"><span class="bg-white px-3 py-1 rounded shadow text-xs font-bold text-gray-700 opacity-0 group-hover:opacity-100">Change</span></div></div><input type="file" name="image_url" class="hidden" onchange="previewImage(this, 'image_url_preview')"></label><input type="hidden" name="existing_image_url" id="existing_image_url"></div>
                            <?php for($i=1; $i<=4; $i++): ?>
                            <div><label class="block text-sm font-bold text-gray-700 mb-1">Thumbnail <?= $i ?></label><input type="file" name="thumbnail_img_<?= $i ?>" class="w-full p-2 form-input rounded-lg"><input type="hidden" name="existing_thumbnail_img_<?= $i ?>" id="existing_thumbnail_img_<?= $i ?>"></div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><label class="block text-sm font-bold text-gray-700 mb-1">Description</label><textarea id="description" name="description" rows="3" class="w-full p-2 form-input rounded-lg"></textarea></div>
                        <div><label class="block text-sm font-bold text-gray-700 mb-1">Specifications (Optional)</label><textarea id="specifications" name="specifications" rows="3" class="w-full p-2 form-input rounded-lg"></textarea></div>
                    </div>
                    <div class="flex justify-end pt-4 border-t border-gray-100"><button type="submit" id="submitBtn" class="btn-primary font-bold py-2 px-8 rounded-lg shadow-lg hover:shadow-xl transition-transform transform hover:-translate-y-0.5">Save Product</button></div>
                </div>
            </form>
        </div>
    </div>
    
    <div id="viewProductModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 hidden transition-opacity duration-300 backdrop-blur-sm">
        <div class="modal-card w-11/12 md:w-3/4 lg:w-2/3 max-h-[90vh] overflow-y-auto">
            <div class="bg-white p-6 md:p-8">
                <div class="flex justify-between items-start mb-6 pb-4 border-b border-gray-100">
                    <div>
                        <h2 id="viewModalTitle" class="text-3xl font-bold text-[#1E3A1D]">Product Details</h2>
                        <span id="view_status" class="inline-block mt-2"></span>
                    </div>
                    <button id="closeViewBtn" class="text-gray-400 hover:text-gray-700"><span class="material-icons">close</span></button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div><img id="view_image_url" src="" class="w-full h-80 object-cover rounded-xl shadow-sm bg-gray-50 mb-4"></div>
                    <div class="space-y-4">
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">PRICE</span><span id="view_price" class="text-2xl font-bold text-[#1E3A1D]"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">STOCK</span><span id="view_quantity" class="text-lg font-bold"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">UNIT TYPE</span><span id="view_unit"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">BRAND</span><span id="view_product_brand"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">CATEGORY</span><span id="view_category_name"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">WEIGHT</span><span id="view_weight"></span></div>
                        <div class="flex justify-between border-b pb-2"><span class="text-gray-500 text-sm font-bold">EXPIRATION</span><span id="view_expiration"></span></div>
                        <div class="pt-2"><span class="text-gray-500 text-sm font-bold block mb-1">DESCRIPTION</span><p id="view_description" class="text-gray-600 text-sm"></p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 hidden transition-opacity duration-300 backdrop-blur-sm">
        <div class="modal-card w-11/12 md:w-96 p-6 text-center">
             <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4"><span class="material-icons text-red-600 text-3xl">warning</span></div>
             <h2 class="text-xl font-bold text-gray-800 mb-2">Delete Product?</h2>
             <p class="text-gray-500 mb-6 text-sm">Are you sure? This action cannot be undone.</p>
             <form id="deleteForm">
                 <input type="hidden" name="action_type" value="delete_product">
                 <input type="hidden" id="delete_product_id" name="delete_product_id" value="">
                 <div class="flex justify-center space-x-3">
                    <button type="button" id="cancelDeleteBtn" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg">Cancel</button>
                    <button type="submit" class="btn-danger font-bold py-2 px-4 rounded-lg shadow-md">Yes, Delete</button>
                 </div>
             </form>
        </div>
    </div>
    
    <script>
    function debounce(func, delay) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => func.apply(this, a), delay) } }
    function previewImage(i, p) { if (i.files && i.files[0]) { const r = new FileReader(); r.onload = e => document.getElementById(p).src = e.target.result; r.readAsDataURL(i.files[0]) } }

    document.addEventListener('DOMContentLoaded', () => {
        const productModal = document.getElementById('productModal');
        const viewProductModal = document.getElementById('viewProductModal');
        const deleteModal = document.getElementById('deleteModal');
        const productForm = document.getElementById('productForm');
        const tableBody = document.getElementById('productsTableBody');
        const paginationContainer = document.getElementById('pagination-container');
        const flashMessage = document.getElementById('flashMessage');
        const unitSelect = document.getElementById('unit');
        const weightInput = document.getElementById('weight');

        let currentFilters = new URLSearchParams(window.location.search);
        const defaultPlaceholder = '../../assets/img/placeholder.png'; 

        // --- DYNAMIC UNIT LOGIC FOR CAPSTONE ---
        // If Unit is 'kg', 'g', or 'liter', weight field is redundant (stock IS weight).
        // If Unit is 'pcs', 'pack', or 'box', weight is useful for shipping calc.
        const updateWeightField = () => {
            const val = unitSelect.value;
            if (['kg', 'g', 'liter'].includes(val)) {
                weightInput.disabled = true;
                weightInput.value = '';
                weightInput.placeholder = 'Not needed for ' + val;
                weightInput.classList.add('bg-gray-100');
            } else {
                weightInput.disabled = false;
                weightInput.placeholder = 'Optional (for shipping)';
                weightInput.classList.remove('bg-gray-100');
            }
        };
        unitSelect.addEventListener('change', updateWeightField);

        let flashTimeout;
        const showFlash = (message, type = 'success') => {
            if(flashTimeout) clearTimeout(flashTimeout);
            flashMessage.textContent = message;
            flashMessage.classList.remove('translate-x-full', 'opacity-0', 'bg-[#1E3A1D]', 'bg-[#B33333]');
            flashMessage.classList.add('translate-x-0', 'opacity-100', (type === 'delete' || type === 'error') ? 'bg-[#B33333]' : 'bg-[#1E3A1D]');
            flashTimeout = setTimeout(() => { flashMessage.classList.add('translate-x-full', 'opacity-0'); }, 2500);
        };
        
        const closeModal = (modal) => modal.classList.add('hidden');
        const openModal = (modal) => modal.classList.remove('hidden');

        const fetchJSON = async (url, options = {}) => {
            options.headers = { ...options.headers, 'X-Requested-With': 'XMLHttpRequest' };
            const response = await fetch(url, options);
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        };

        const openAddModal = () => {
            productForm.reset();
            document.getElementById('modalTitle').textContent = 'Add New Product';
            document.getElementById('action_type').value = 'add_product';
            document.getElementById('product_id').value = '';
            document.getElementById('image_url_preview').src = defaultPlaceholder;
            updateWeightField(); // Reset weight state
            openModal(productModal);
        };

        const openEditModal = async (productId) => {
            productForm.reset();
            document.getElementById('modalTitle').textContent = 'Edit Product';
            document.getElementById('action_type').value = 'edit_product';
            try {
                const { data } = await fetchJSON(`?action=get_product&id=${productId}`);
                Object.keys(data).forEach(key => { const el = document.getElementById(key); if (el) el.value = data[key] || ''; });
                if(data.category_id || data.joined_cat_id) document.getElementById('category_id').value = data.category_id || data.joined_cat_id;
                
                // Set Unit specifically (it might be a select now)
                if(data.unit) {
                    unitSelect.value = data.unit;
                    updateWeightField(); // Trigger logic based on loaded unit
                    // If we have a weight value from DB but field is disabled by logic, we might want to show it or keep it hidden.
                    // Current logic clears it if disabled, but let's re-set it if it exists just in case.
                    if (data.weight) weightInput.value = data.weight;
                }
                
                document.getElementById('image_url_preview').src = data.image_url ? `../../${data.image_url}` : defaultPlaceholder;
                document.getElementById('existing_image_url').value = data.image_url || '';
                openModal(productModal);
            } catch (e) { showFlash('Could not load product data.', 'error'); }
        };
        
        const openViewModal = async (productId) => {
             try {
                const { data } = await fetchJSON(`?action=get_product&id=${productId}`);
                document.getElementById('viewModalTitle').textContent = data.name;
                document.getElementById('view_status').innerHTML = `<span class="status-badge status-${(data.status || '').replace(/\s+/g, '.')}">${data.status}</span>`;
                document.getElementById('view_product_brand').textContent = data.product_brand || 'N/A';
                document.getElementById('view_category_name').textContent = data.category_name || 'Uncategorized';
                document.getElementById('view_price').textContent = `₱${parseFloat(data.price).toFixed(2)}`;
                document.getElementById('view_quantity').textContent = data.quantity;
                document.getElementById('view_weight').textContent = data.weight || '-';
                // Show Unit in View Modal
                document.getElementById('view_unit').textContent = data.unit || 'pcs';
                document.getElementById('view_expiration').textContent = data.expiration_date || '-';
                document.getElementById('view_description').textContent = data.description || 'No description available.';
                document.getElementById('view_image_url').src = data.image_url ? `../../${data.image_url}` : defaultPlaceholder;
                openModal(viewProductModal);
            } catch (e) { showFlash('Could not load details.', 'error'); }
        };

        window.openDeleteModal = (id) => {
            const inputField = document.getElementById('delete_product_id');
            if (inputField) { inputField.value = id; openModal(deleteModal); } 
            else { alert("Error: Delete ID field missing."); }
        };

        const fetchProducts = async (page = 1) => {
            currentFilters.set('page', page);
            try {
                const data = await fetchJSON(`?${currentFilters.toString()}`);
                renderProducts(data.products);
                renderPagination(data.pagination);
                updateBulkActions();
                updateFilterBadge();
            } catch (e) { console.error('Error:', e); }
        };

        const renderProducts = (products) => {
            tableBody.innerHTML = '';
            if (!products || products.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="10" class="p-8 text-center text-gray-400 italic">No products found matching your criteria.</td></tr>';
                return;
            }
            products.forEach(p => {
                const displayStatus = p.computed_status;
                const statusClass = `status-${displayStatus.replace(/[\s&]+/g, '-')}`; 
                const imageSrc = p.image_url ? `../../${p.image_url}` : defaultPlaceholder;
                // Use unit here for display
                const unitDisplay = p.unit ? p.unit : 'pcs';
                
                tableBody.innerHTML += `
                    <tr class="hover:bg-gray-50 transition border-b border-gray-100 relative-cell">
                        <td class="p-4"><input type="checkbox" data-id="${p.product_id}" class="product-checkbox rounded text-green-700 focus:ring-green-600 border-gray-300"></td>
                        <td class="p-4 flex items-center gap-4">
                            <img src="${imageSrc}" alt="${p.name}" class="w-12 h-12 object-cover rounded-lg shadow-sm bg-white">
                            <div><p class="font-bold text-gray-800">${p.name}</p><p class="text-xs text-gray-500">${p.product_brand || 'No Brand'}</p></div>
                        </td>
                        <td class="p-4 text-sm text-gray-600">${p.category_name || 'N/A'}</td>
                         <td class="p-4 text-sm text-gray-600">${p.weight || '-'}</td>
                        <td class="p-4 text-sm text-gray-600">${p.expiration_date || '-'}</td>
                        <td class="p-4 font-mono text-sm font-bold text-gray-700">₱${parseFloat(p.price).toFixed(2)}</td>
                        <td class="p-4 flex items-center gap-2">
                            <input type="number" value="${p.quantity ?? 0}" data-id="${p.product_id}" class="quick-stock-input w-20 text-center p-1 rounded border border-gray-200 text-sm focus:border-green-600 focus:ring-1 focus:ring-green-600">
                            <span class="text-xs text-gray-500">${unitDisplay}</span>
                        </td>
                        <td class="p-4"><span class="status-badge ${statusClass}">${displayStatus}</span></td>
                        <td class="p-4 text-right relative">
                             <button onclick="event.stopPropagation(); window.toggleActionsMenu(${p.product_id})" class="text-gray-400 hover:text-gray-600 focus:outline-none p-2 hover:bg-gray-100 rounded-full transition">
                                <span class="material-icons">more_vert</span>
                             </button>
                             <div id="actions-menu-${p.product_id}" class="action-menu hidden absolute right-8 top-8 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-100 z-50 text-left">
                                <a href="#" onclick="openViewModal(${p.product_id}); return false;" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                                    <span class="material-icons text-sm">visibility</span> View Details
                                </a>
                                <a href="#" onclick="openEditModal(${p.product_id}); return false;" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                                    <span class="material-icons text-sm">edit</span> Edit
                                </a>
                                <hr class="border-gray-100">
                                <a href="#" onclick="window.openDeleteModal(${p.product_id}); return false;" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2">
                                    <span class="material-icons text-sm">delete</span> Delete
                                </a>
                             </div>
                        </td>
                    </tr>`;
            });
        };
        
        const renderPagination = ({ total_products, total_pages, current_page }) => {
            if (total_pages <= 1) { paginationContainer.innerHTML = `<p class="text-sm text-gray-500">Showing all ${total_products} products</p>`; return; }
            let links = '';
            for (let i = 1; i <= total_pages; i++) { 
                const activeClass = i == current_page ? 'bg-[#1E3A1D] text-white' : 'bg-white text-gray-700 hover:bg-gray-100';
                links += `<a href="#" data-page="${i}" class="pagination-link px-3 py-1 rounded border border-gray-200 text-sm font-medium ${activeClass}">${i}</a>`; 
            }
            paginationContainer.innerHTML = `<p class="text-sm text-gray-500">Page ${current_page} of ${total_pages}</p><div class="flex gap-1">${links}</div>`;
        };

        const debouncedFetch = debounce(() => {
            currentFilters.set('search', document.getElementById('searchInput').value);
            fetchProducts(1);
        }, 350);
        
        const updateFilterBadge = () => {
            let count = 0;
            if (document.getElementById('statusFilter').value !== 'all') count++;
            if (document.getElementById('brandFilter').value !== 'all') count++;
            const badge = document.getElementById('filterCountBadge');
            badge.textContent = count;
            badge.classList.toggle('visible', count > 0);
        };

        document.getElementById('addProductBtn').addEventListener('click', openAddModal);
        document.getElementById('cancelBtn').addEventListener('click', () => closeModal(productModal));
        document.getElementById('closeViewBtn').addEventListener('click', () => closeModal(viewProductModal));
        document.getElementById('cancelDeleteBtn').addEventListener('click', () => closeModal(deleteModal));
        
        const toggleFilterBtn = document.getElementById('toggleFilterBtn');
        const filterOptions = document.getElementById('filterOptions');
        toggleFilterBtn.addEventListener('click', () => {
            const isOpen = filterOptions.style.maxHeight && filterOptions.style.maxHeight !== '0px';
            filterOptions.style.maxHeight = isOpen ? '0px' : filterOptions.scrollHeight + "px";
            filterOptions.style.opacity = isOpen ? '0' : '1';
        });
        
        document.getElementById('applyFilters').addEventListener('click', () => {
             currentFilters.set('search', document.getElementById('searchInput').value);
             currentFilters.set('status', document.getElementById('statusFilter').value);
             currentFilters.set('brand', document.getElementById('brandFilter').value);
             currentFilters.set('sort', document.getElementById('sortFilter').value);
             fetchProducts(1);
        });
        
        document.getElementById('resetFilters').addEventListener('click', () => {
            document.getElementById('searchInput').value = '';
            document.getElementById('statusFilter').value = 'all';
            document.getElementById('brandFilter').value = 'all';
            document.getElementById('sortFilter').value = 'newest';
            currentFilters = new URLSearchParams();
            fetchProducts(1);
        });
        
        document.getElementById('searchInput').addEventListener('input', debouncedFetch);
        paginationContainer.addEventListener('click', e => { if (e.target.matches('.pagination-link')) { e.preventDefault(); fetchProducts(e.target.dataset.page); } });

        productForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('submitBtn');
            if(btn.disabled) return; 
            const originalText = btn.textContent;
            btn.disabled = true;
            btn.innerHTML = '<span class="animate-spin inline-block mr-2">&#9696;</span> Saving...';
            try {
                const result = await fetchJSON('', { method: 'POST', body: new FormData(productForm) });
                showFlash(result.message, result.success ? 'success' : 'error');
                if (result.success) { closeModal(productModal); fetchProducts(1); }
            } catch (error) { showFlash('An unexpected error occurred.', 'error'); } 
            finally { btn.disabled = false; btn.textContent = originalText; }
        });
        
        document.getElementById('deleteForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button[type="submit"]');
            if(btn.disabled) return;
            const originalText = btn.textContent;
            btn.disabled = true;
            btn.textContent = 'Deleting...';
            try {
                const formData = new FormData(e.target);
                if (!formData.get('delete_product_id')) { showFlash('Error: Missing Product ID', 'error'); return; }
                const result = await fetchJSON('', { method: 'POST', body: formData });
                showFlash(result.message, result.success ? 'delete' : 'error');
                if (result.success) { closeModal(deleteModal); fetchProducts(1); }
            } catch (error) { showFlash('Request failed.', 'error'); } 
            finally { btn.disabled = false; btn.textContent = originalText; }
        });
        
        const debouncedStockUpdate = debounce(async (productId, quantity) => {
            const formData = new FormData();
            formData.append('action_type', 'update_stock');
            formData.append('product_id', productId);
            formData.append('quantity', quantity);
            try { 
                await fetchJSON('', { method: 'POST', body: formData }); 
                showFlash('Stock updated.', 'success');
                fetchProducts(currentFilters.get('page') || 1); 
            } catch (error) { showFlash('Error updating stock', 'error'); }
        }, 750);
        tableBody.addEventListener('input', e => { if (e.target.classList.contains('quick-stock-input')) { debouncedStockUpdate(e.target.dataset.id, e.target.value); } });
        
        const bulkContainer = document.getElementById('bulkActionContainer');
        const selectAllCb = document.getElementById('selectAllCheckbox');
        const updateBulkActions = () => {
            const selected = tableBody.querySelectorAll('.product-checkbox:checked');
            bulkContainer.classList.toggle('hidden', selected.length === 0);
            if(selected.length > 0) document.getElementById('selectionCount').textContent = `${selected.length} Selected`;
            selectAllCb.checked = selected.length > 0 && selected.length === tableBody.querySelectorAll('.product-checkbox').length;
        };
        selectAllCb.addEventListener('change', () => { tableBody.querySelectorAll('.product-checkbox').forEach(cb => cb.checked = selectAllCb.checked); updateBulkActions(); });
        tableBody.addEventListener('change', e => { if (e.target.classList.contains('product-checkbox')) updateBulkActions(); });
        
        // BULK ACTION HANDLER
        document.getElementById('applyBulkAction').addEventListener('click', async () => {
            const checkboxes = tableBody.querySelectorAll('.product-checkbox:checked');
            const ids = Array.from(checkboxes).map(cb => cb.dataset.id);
            const action = document.getElementById('bulkActionSelect').value;
            
            if (!action) { alert("Please select an action."); return; }
            if (ids.length === 0) { alert("No items selected."); return; }
            
            if(action === 'delete' && !confirm("Are you sure you want to delete the selected items? This cannot be undone.")) return;

            const btn = document.getElementById('applyBulkAction');
            const originalText = btn.textContent;
            btn.disabled = true;
            btn.textContent = 'Processing...';
            
            const formData = new FormData();
            formData.append('action_type', 'bulk_action');
            formData.append('bulk_action_type', action);
            
            // Append as array
            ids.forEach(id => formData.append('product_ids[]', id));
            
            try {
                const result = await fetchJSON('', { method: 'POST', body: formData });
                const type = action === 'delete' ? 'delete' : 'success';
                showFlash(result.message, result.success ? type : 'error');
                if (result.success) {
                    fetchProducts(1);
                    document.getElementById('selectAllCheckbox').checked = false;
                }
            } catch (e) { showFlash('Bulk action failed.', 'error'); } 
            finally { btn.disabled = false; btn.textContent = originalText; }
        });
        
        window.toggleActionsMenu = (productId) => {
            const menu = document.getElementById(`actions-menu-${productId}`);
            const isHidden = menu.classList.contains('hidden');
            document.querySelectorAll('.action-menu').forEach(m => m.classList.add('hidden'));
            if (isHidden) menu.classList.remove('hidden');
        };

        window.addEventListener('click', (e) => {
            if (!e.target.closest('.relative-cell')) {
                document.querySelectorAll('.action-menu').forEach(menu => menu.classList.add('hidden'));
            }
        });

        window.openViewModal = openViewModal;
        window.openEditModal = openEditModal;
        
        fetchProducts(<?= $current_page ?>);
        updateFilterBadge();
    });
    </script>
</body>
</html>