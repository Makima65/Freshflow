<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\returns.php

// 1. START BUFFERING
if (session_status() == PHP_SESSION_NONE) { session_start(); }
ob_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include_once '../includes/db_connection.php';

// --- AUDIT HELPER ---
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) { include_once $auditHelperPath; } 
else { if (!function_exists('log_audit_action')) { function log_audit_action($a, $b, $c, $d = []) { return true; } } }

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        ob_clean(); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => 'Session expired']); exit;
    }
    header("location: ../admin_login.php"); exit;
}

// --- BACKEND HANDLER ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean(); header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    // 1. GET SALE ITEMS (For Modal)
    if ($action === 'get_sale_items') {
        $sale_id = intval($_POST['sale_id']);
        // Fetch items joined with products, calculating remaining returnable quantity
        $query = "
            SELECT si.product_id, si.quantity as sold_qty, si.returned_qty, 
                   (si.quantity - si.returned_qty) as remaining_qty,
                   p.name, p.unit_type
            FROM sales_items si
            JOIN products p ON si.product_id = p.product_id
            WHERE si.sale_id = ? AND (si.quantity - si.returned_qty) > 0
        ";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $sale_id);
        $stmt->execute();
        $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'items' => $items]);
        exit;
    }

    // 2. PROCESS RETURN
    if ($action === 'process_return') {
        $sale_id = intval($_POST['sale_id']);
        $product_id = intval($_POST['product_id']);
        $qty_to_return = floatval($_POST['return_qty']);
        $condition = $_POST['condition']; // 'Good' or 'Spoiled'
        $reason = trim($_POST['reason']);

        if ($qty_to_return <= 0) { echo json_encode(['success' => false, 'message' => 'Invalid quantity']); exit; }

        $conn->begin_transaction();
        try {
            // A. Check if valid return
            $check = $conn->prepare("SELECT quantity, returned_qty FROM sales_items WHERE sale_id = ? AND product_id = ?");
            $check->bind_param("ii", $sale_id, $product_id);
            $check->execute();
            $item = $check->get_result()->fetch_assoc();

            if (!$item || ($item['quantity'] - $item['returned_qty'] < $qty_to_return)) {
                throw new Exception("Cannot return more than sold/remaining.");
            }

            // B. Log to RETURNS table
            $stmt = $conn->prepare("INSERT INTO returns (sale_id, product_id, quantity, reason, condition_status) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iidds", $sale_id, $product_id, $qty_to_return, $reason, $condition);
            $stmt->execute();

            // C. Update SALES_ITEMS (Increase returned_qty)
            $upd = $conn->prepare("UPDATE sales_items SET returned_qty = returned_qty + ? WHERE sale_id = ? AND product_id = ?");
            $upd->bind_param("dii", $qty_to_return, $sale_id, $product_id);
            $upd->execute();

            // D. Inventory Logic
            if ($condition === 'Good') {
                // Restock: Add back to main inventory
                $inv = $conn->prepare("INSERT INTO product_inventory (product_id, quantity) VALUES (?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?");
                $inv->bind_param("idd", $product_id, $qty_to_return, $qty_to_return);
                $inv->execute();
            } else {
                // Spoilage: Log to spoilage table
                $spoil = $conn->prepare("INSERT INTO spoilage (product_id, quantity, reason) VALUES (?, ?, ?)");
                $spoil_reason = "Return from Sale #$sale_id: " . $reason;
                $spoil->bind_param("ids", $product_id, $qty_to_return, $spoil_reason);
                $spoil->execute();
            }

            $conn->commit();
            
            if (function_exists('log_audit_action')) log_audit_action('Return', 'Fulfillment', "Processed return for Sale #$sale_id (Qty: $qty_to_return)");
            
            echo json_encode(['success' => true, 'message' => 'Return processed successfully.']);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
}
ob_end_flush();

// --- FETCH COMPLETED ORDERS ---
// Logic: Get orders that are 'Completed' or 'Delivered'
$orders_sql = "
    SELECT s.sale_id, s.delivered_at, s.driver_name, c.client_name, 
           (SELECT COUNT(*) FROM returns r WHERE r.sale_id = s.sale_id) as return_count
    FROM sales s
    LEFT JOIN clients c ON s.client_id = c.client_id
    WHERE s.order_status IN ('Completed', 'Delivered')
    ORDER BY s.delivered_at DESC
    LIMIT 50
";
$orders = $conn->query($orders_sql)->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Returns</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; color: #2B2B2B; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .btn-primary { background-color: #B33333; color: white; } /* Red for Returns */
        .btn-primary:hover { background-color: #991b1b; }
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 transition-all duration-300 p-6 md:p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="font-heading text-3xl font-bold text-[#1E3A1D] mb-1">Returns & Rejects</h1>
                <p class="text-sm text-gray-500">Process items rejected by clients or returned due to damage.</p>
            </div>
        </header>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase font-bold border-b border-gray-200">
                    <tr>
                        <th class="p-4 w-24">Sale ID</th>
                        <th class="p-4">Client</th>
                        <th class="p-4">Delivered Date</th>
                        <th class="p-4">Driver</th>
                        <th class="p-4 text-center">History</th>
                        <th class="p-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 text-sm text-gray-700">
                    <?php if(empty($orders)): ?>
                        <tr><td colspan="6" class="p-8 text-center text-gray-400 italic">No completed orders found eligible for return.</td></tr>
                    <?php else: ?>
                        <?php foreach($orders as $o): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4 font-mono font-bold text-[#1E3A1D]">#<?= str_pad($o['sale_id'], 5, '0', STR_PAD_LEFT) ?></td>
                            <td class="p-4 font-bold"><?= htmlspecialchars($o['client_name'] ?? 'Unknown') ?></td>
                            <td class="p-4"><?= $o['delivered_at'] ? date('M d, Y h:i A', strtotime($o['delivered_at'])) : '-' ?></td>
                            <td class="p-4"><span class="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-bold"><?= htmlspecialchars($o['driver_name'] ?? 'N/A') ?></span></td>
                            <td class="p-4 text-center">
                                <?php if($o['return_count'] > 0): ?>
                                    <span class="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold"><?= $o['return_count'] ?> Returns</span>
                                <?php else: ?>
                                    <span class="text-gray-300">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-4 text-right">
                                <button onclick="openReturnModal(<?= $o['sale_id'] ?>)" class="btn-primary px-4 py-2 rounded-lg text-xs font-bold shadow hover:shadow-md transition">
                                    Process Return
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="returnModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg p-6 transform transition-all scale-100">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-[#1E3A1D]">Process Return: Order #<span id="modal-sale-id"></span></h2>
                <button type="button" onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><span class="material-icons">close</span></button>
            </div>
            
            <form id="returnForm">
                <input type="hidden" name="action" value="process_return">
                <input type="hidden" name="sale_id" id="form-sale-id">
                
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Select Item to Return</label>
                    <select id="productSelect" name="product_id" required class="w-full p-2 border border-gray-300 rounded-lg outline-none focus:border-[#B33333]">
                        <option value="" disabled selected>Loading items...</option>
                    </select>
                    <p class="text-xs text-gray-400 mt-1 text-right">Remaining Quantity: <span id="maxQtyText" class="font-bold">0</span></p>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Quantity</label>
                        <input type="number" id="returnQty" name="return_qty" step="0.01" min="0.01" required class="w-full p-2 border border-gray-300 rounded-lg outline-none focus:border-[#B33333]">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Condition</label>
                        <select name="condition" required class="w-full p-2 border border-gray-300 rounded-lg outline-none focus:border-[#B33333]">
                            <option value="Spoiled">Spoiled / Damaged</option>
                            <option value="Good">Good / Restock</option>
                        </select>
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Reason</label>
                    <textarea name="reason" rows="2" placeholder="e.g. Wilting leaves, Crushed box..." required class="w-full p-2 border border-gray-300 rounded-lg outline-none focus:border-[#B33333]"></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeModal()" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-bold">Cancel</button>
                    <button type="submit" class="bg-[#B33333] text-white px-6 py-2 rounded-lg text-sm font-bold hover:bg-[#991b1b] shadow-lg">Confirm Return</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('returnModal');
        const productSelect = document.getElementById('productSelect');
        const maxQtyText = document.getElementById('maxQtyText');
        const returnQtyInput = document.getElementById('returnQty');
        let currentItems = {};

        function closeModal() { modal.classList.add('hidden'); }

        async function openReturnModal(saleId) {
            document.getElementById('modal-sale-id').textContent = saleId;
            document.getElementById('form-sale-id').value = saleId;
            productSelect.innerHTML = '<option>Loading...</option>';
            modal.classList.remove('hidden');

            try {
                const formData = new FormData();
                formData.append('action', 'get_sale_items');
                formData.append('sale_id', saleId);

                const res = await fetch('', { method: 'POST', body: formData }).then(r => r.json());
                
                if(res.success && res.items.length > 0) {
                    productSelect.innerHTML = '<option value="" disabled selected>-- Select Product --</option>';
                    currentItems = {};
                    res.items.forEach(item => {
                        currentItems[item.product_id] = item.remaining_qty;
                        productSelect.innerHTML += `<option value="${item.product_id}">${item.name} (Sold: ${parseFloat(item.sold_qty)})</option>`;
                    });
                } else {
                    productSelect.innerHTML = '<option disabled>No returnable items found</option>';
                }
            } catch(e) { console.error(e); }
        }

        // Update Max Qty when product changes
        productSelect.addEventListener('change', function() {
            const max = currentItems[this.value] || 0;
            maxQtyText.textContent = max;
            returnQtyInput.max = max;
            returnQtyInput.value = '';
        });

        document.getElementById('returnForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            if(!confirm("Process this return? Inventory will be updated.")) return;

            const btn = e.target.querySelector('button[type="submit"]');
            const orgText = btn.textContent;
            btn.disabled = true; btn.textContent = "Processing...";

            try {
                const res = await fetch('', { method: 'POST', body: new FormData(e.target) }).then(r => r.json());
                if(res.success) {
                    alert("Return Successful");
                    location.reload();
                } else {
                    alert(res.message);
                }
            } catch(e) { alert("Error processing return"); }
            finally { btn.disabled = false; btn.textContent = orgText; }
        });
    </script>
</body>
</html>