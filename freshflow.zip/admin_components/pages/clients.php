<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\clients.php
ob_start();
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../includes/db_connection.php';
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) { include_once $auditHelperPath; } 
elseif (!function_exists('log_audit_action')) { function log_audit_action($a, $b, $c, $d = []) { return true; } }

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../admin_login.php"); exit;
}

// --- HANDLER ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_client') {
    ob_clean(); header('Content-Type: application/json');
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM clients WHERE client_id = ? LIMIT 1");
    $stmt->bind_param("i", $id); $stmt->execute();
    $res = $stmt->get_result();
    echo json_encode(['success' => true, 'data' => $res->fetch_assoc()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean(); header('Content-Type: application/json');
    $action = $_POST['action_type'] ?? '';

    if ($action === 'add_client' || $action === 'edit_client') {
        $is_edit = ($action === 'edit_client');
        $id = $is_edit ? intval($_POST['client_id']) : 0;
        $name = trim($_POST['client_name']);
        $person = trim($_POST['contact_person']);
        $number = trim($_POST['contact_number']);
        $address = trim($_POST['address']);
        $status = $_POST['status'];

        if (empty($name)) { echo json_encode(['success' => false, 'message' => 'Client Name required.']); exit; }

        if ($is_edit) {
            $stmt = $conn->prepare("UPDATE clients SET client_name=?, contact_person=?, contact_number=?, address=?, status=? WHERE client_id=?");
            $stmt->bind_param("sssssi", $name, $person, $number, $address, $status, $id);
            $stmt->execute();
            if (function_exists('log_audit_action')) log_audit_action('Update Client', 'Clients', "Updated client '$name'.");
        } else {
            $stmt = $conn->prepare("INSERT INTO clients (client_name, contact_person, contact_number, address, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $person, $number, $address, $status);
            $stmt->execute();
            if (function_exists('log_audit_action')) log_audit_action('Add Client', 'Clients', "Added new client '$name'.");
        }
        echo json_encode(['success' => true, 'message' => "Client saved successfully!"]);
        exit;
    }
    
    if ($action === 'delete_client') {
        $id = intval($_POST['delete_client_id']);
        $conn->query("DELETE FROM clients WHERE client_id = $id");
        if (function_exists('log_audit_action')) log_audit_action('Delete Client', 'Clients', "Deleted client ID $id.");
        echo json_encode(['success' => true, 'message' => "Client deleted."]);
        exit;
    }
}
ob_end_flush();

// --- FETCH DATA ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = "WHERE 1";
if ($search) $where .= " AND (client_name LIKE '%$search%' OR contact_person LIKE '%$search%')";
$clients = $conn->query("SELECT * FROM clients $where ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Clients</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; }</style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>
    <div class="ml-20 p-8">
        <div id="flashMessage" class="fixed top-8 right-8 text-white py-3 px-6 rounded-lg shadow-xl hidden z-50"></div>

        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-[#1E3A1D]">Client Management</h1>
            <button onclick="openAddModal()" class="bg-[#1E3A1D] text-white px-6 py-2 rounded-lg font-bold hover:bg-[#2a4e29] flex items-center gap-2">
                <span class="material-icons">add</span> Add Client
            </button>
        </div>

        <div class="bg-white p-4 rounded-lg shadow mb-6">
            <input type="text" id="searchInput" placeholder="Search clients..." value="<?= htmlspecialchars($search) ?>" class="w-full p-2 border rounded-lg" onkeydown="if(event.key === 'Enter') window.location.href='?search='+this.value">
        </div>

        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-[#1E3A1D] text-white">
                    <tr>
                        <th class="p-4">Client Name</th>
                        <th class="p-4">Contact Person</th>
                        <th class="p-4">Phone</th>
                        <th class="p-4">Address</th>
                        <th class="p-4">Status</th>
                        <th class="p-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($clients)): ?>
                        <tr><td colspan="6" class="p-6 text-center text-gray-500">No clients found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($clients as $c): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-4 font-bold"><?= htmlspecialchars($c['client_name']) ?></td>
                            <td class="p-4"><?= htmlspecialchars($c['contact_person']) ?></td>
                            <td class="p-4"><?= htmlspecialchars($c['contact_number']) ?></td>
                            <td class="p-4 truncate max-w-xs"><?= htmlspecialchars($c['address']) ?></td>
                            <td class="p-4"><span class="px-2 py-1 rounded text-xs font-bold <?= $c['status'] == 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' ?>"><?= $c['status'] ?></span></td>
                            <td class="p-4 text-right">
                                <button onclick="openEditModal(<?= $c['client_id'] ?>)" class="text-blue-600 hover:text-blue-800 mr-2"><span class="material-icons">edit</span></button>
                                <button onclick="deleteClient(<?= $c['client_id'] ?>)" class="text-red-600 hover:text-red-800"><span class="material-icons">delete</span></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="clientModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex justify-center items-center z-50">
        <div class="bg-white rounded-lg w-1/2 p-6">
            <h2 id="modalTitle" class="text-2xl font-bold mb-4 text-[#1E3A1D]">Add Client</h2>
            <form id="clientForm">
                <input type="hidden" name="action_type" id="action_type">
                <input type="hidden" name="client_id" id="client_id">
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div><label class="block text-sm font-bold mb-1">Client Name *</label><input type="text" name="client_name" id="client_name" class="w-full p-2 border rounded" required></div>
                    <div><label class="block text-sm font-bold mb-1">Contact Person</label><input type="text" name="contact_person" id="contact_person" class="w-full p-2 border rounded"></div>
                    <div><label class="block text-sm font-bold mb-1">Phone Number</label><input type="text" name="contact_number" id="contact_number" class="w-full p-2 border rounded"></div>
                    <div><label class="block text-sm font-bold mb-1">Status</label><select name="status" id="status" class="w-full p-2 border rounded"><option value="Active">Active</option><option value="Inactive">Inactive</option></select></div>
                </div>
                <div class="mb-6"><label class="block text-sm font-bold mb-1">Address</label><textarea name="address" id="address" class="w-full p-2 border rounded" rows="3"></textarea></div>
                <div class="flex justify-end gap-2">
                    <button type="button" onclick="document.getElementById('clientModal').classList.add('hidden')" class="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-[#1E3A1D] text-white rounded font-bold">Save</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('clientModal');
        const form = document.getElementById('clientForm');
        
        function showFlash(msg, bg='bg-green-600') {
            const f = document.getElementById('flashMessage');
            f.textContent = msg; f.className = `fixed top-8 right-8 text-white py-3 px-6 rounded-lg shadow-xl z-50 ${bg}`;
            f.classList.remove('hidden'); setTimeout(() => f.classList.add('hidden'), 3000);
        }

        function openAddModal() {
            form.reset(); document.getElementById('action_type').value = 'add_client';
            document.getElementById('modalTitle').textContent = 'Add Client';
            modal.classList.remove('hidden');
        }

        async function openEditModal(id) {
            form.reset(); document.getElementById('action_type').value = 'edit_client';
            document.getElementById('modalTitle').textContent = 'Edit Client';
            const res = await fetch(`?action=get_client&id=${id}`).then(r => r.json());
            if(res.success) {
                document.getElementById('client_id').value = res.data.client_id;
                document.getElementById('client_name').value = res.data.client_name;
                document.getElementById('contact_person').value = res.data.contact_person;
                document.getElementById('contact_number').value = res.data.contact_number;
                document.getElementById('address').value = res.data.address;
                document.getElementById('status').value = res.data.status;
                modal.classList.remove('hidden');
            }
        }

        async function deleteClient(id) {
            if(!confirm('Delete this client?')) return;
            const fd = new FormData(); fd.append('action_type', 'delete_client'); fd.append('delete_client_id', id);
            const res = await fetch('', { method:'POST', body:fd }).then(r => r.json());
            if(res.success) window.location.reload();
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const res = await fetch('', { method:'POST', body: new FormData(form) }).then(r => r.json());
            if(res.success) window.location.reload();
            else showFlash(res.message, 'bg-red-600');
        });
    </script>
</body>
</html>