<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\dispatch.php

if (session_status() == PHP_SESSION_NONE) { session_start(); }
ob_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include_once '../includes/db_connection.php';

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        ob_clean(); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => 'Session expired']); exit;
    }
    header("location: ../admin_login.php"); exit;
}

// --- BACKEND HANDLER ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean(); header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    
    // 1. ADD DRIVER
    if ($action === 'add_driver') {
        $name = trim($_POST['driver_name']);
        $plate = trim($_POST['vehicle_plate']);
        if ($name) {
            $stmt = $conn->prepare("INSERT INTO drivers (driver_name, vehicle_plate) VALUES (?, ?)");
            $stmt->bind_param("ss", $name, $plate);
            if($stmt->execute()) echo json_encode(['success' => true, 'message' => 'Driver added!']);
            else echo json_encode(['success' => false, 'message' => 'DB Error']);
        }
        exit;
    }

    // 2. DELETE DRIVER
    if ($action === 'delete_driver') {
        $id = intval($_POST['driver_id']);
        $conn->query("DELETE FROM drivers WHERE driver_id = $id");
        echo json_encode(['success' => true]);
        exit;
    }

    // 3. ASSIGN DRIVER (Dispatch)
    if ($action === 'assign_driver') {
        $sale_id = intval($_POST['sale_id']);
        $driver_id = intval($_POST['driver_id']); 
        
        $d = $conn->query("SELECT * FROM drivers WHERE driver_id = $driver_id")->fetch_assoc();
        
        if ($sale_id && $d) {
            $stmt = $conn->prepare("UPDATE sales SET order_status = 'Out for Delivery', driver_name = ?, vehicle_plate = ?, dispatched_at = NOW() WHERE sale_id = ?");
            $stmt->bind_param("ssi", $d['driver_name'], $d['vehicle_plate'], $sale_id);
            if ($stmt->execute()) echo json_encode(['success' => true]);
            else echo json_encode(['success' => false, 'message' => 'DB Error']);
        } else echo json_encode(['success' => false, 'message' => 'Driver not found']);
        exit;
    }
    
    // 4. MARK COMPLETED (Auto-Timestamp)
    if ($action === 'mark_delivered') {
        $sale_id = intval($_POST['sale_id']);
        if ($sale_id) {
            $stmt = $conn->prepare("UPDATE sales SET order_status = 'Completed', delivered_at = NOW() WHERE sale_id = ?");
            $stmt->bind_param("i", $sale_id);
            $stmt->execute();
            echo json_encode(['success' => true]);
        }
        exit;
    }

    // 5. UPDATE DELIVERY DETAILS (Edit History)
    if ($action === 'update_delivery') {
        $sale_id = intval($_POST['sale_id']);
        $driver = trim($_POST['driver_name']);
        $plate = trim($_POST['vehicle_plate']);
        $date = $_POST['delivery_date']; // YYYY-MM-DD
        $time = $_POST['delivery_time']; // HH:MM
        
        // Combine Date and Time
        $final_datetime = date('Y-m-d H:i:s', strtotime("$date $time"));

        if ($sale_id && $driver) {
            $stmt = $conn->prepare("UPDATE sales SET driver_name = ?, vehicle_plate = ?, delivered_at = ? WHERE sale_id = ?");
            $stmt->bind_param("sssi", $driver, $plate, $final_datetime, $sale_id);
            if ($stmt->execute()) echo json_encode(['success' => true, 'message' => 'Record updated']);
            else echo json_encode(['success' => false, 'message' => 'DB Error']);
        }
        exit;
    }
    
    // 6. FETCH DATA
    if ($action === 'fetch_data') {
        $ready = []; $active = []; $history = []; $drivers = [];

        // A. Get Drivers
        $d_res = $conn->query("SELECT * FROM drivers ORDER BY driver_name ASC");
        if ($d_res) while($d = $d_res->fetch_assoc()) $drivers[] = $d;

        // Helper for Items string
        function getItems($conn, $sale_id) {
            $items = [];
            $q = $conn->query("SELECT si.quantity, p.name, p.unit FROM sales_items si JOIN products p ON si.product_id = p.product_id WHERE si.sale_id = $sale_id");
            if($q) while($row = $q->fetch_assoc()) { 
                $items[] = floatval($row['quantity']) . " " . ($row['unit'] ?? 'pcs') . " x " . $row['name']; 
            }
            return implode(', ', $items);
        }

        // B. Fetch Ready
        $sql = "SELECT s.*, c.client_name FROM sales s LEFT JOIN clients c ON s.client_id = c.client_id WHERE s.order_status = 'Packed' ORDER BY s.sale_id ASC";
        $res = $conn->query($sql);
        if($res) while($r = $res->fetch_assoc()) {
            $r['item_summary'] = getItems($conn, $r['sale_id']);
            $r['formatted_date'] = date('M d, Y', strtotime($r['created_at'] ?? 'now'));
            $r['client_name'] = $r['client_name'] ?? 'Unknown Client';
            $ready[] = $r;
        }

        // C. Fetch Active
        $sql2 = "SELECT s.*, c.client_name FROM sales s LEFT JOIN clients c ON s.client_id = c.client_id WHERE s.order_status = 'Out for Delivery' ORDER BY s.sale_id DESC";
        $res2 = $conn->query($sql2);
        if($res2) while($r = $res2->fetch_assoc()) {
            $r['item_summary'] = getItems($conn, $r['sale_id']);
            $r['client_name'] = $r['client_name'] ?? 'Unknown Client';
            $r['driver_name'] = $r['driver_name'] ?? 'Unassigned';
            $r['vehicle_plate'] = $r['vehicle_plate'] ?? 'N/A';
            $disp = $r['dispatched_at'] ?? null;
            $r['time_ago'] = $disp ? date('h:i A', strtotime($disp)) : 'Just now';
            $active[] = $r;
        }

        // D. Fetch History (Last 50)
        $sql3 = "SELECT s.*, c.client_name FROM sales s LEFT JOIN clients c ON s.client_id = c.client_id WHERE s.order_status = 'Completed' ORDER BY s.delivered_at DESC LIMIT 50";
        $res3 = $conn->query($sql3);
        if($res3) while($r = $res3->fetch_assoc()) {
            $r['item_summary'] = getItems($conn, $r['sale_id']);
            $r['client_name'] = $r['client_name'] ?? 'Unknown';
            $r['driver_name'] = $r['driver_name'] ?? 'Unassigned';
            $r['vehicle_plate'] = $r['vehicle_plate'] ?? '';
            // Split for Edit Form
            $ts = strtotime($r['delivered_at'] ?? 'now');
            $r['delivered_date_raw'] = date('Y-m-d', $ts);
            $r['delivered_time_raw'] = date('H:i', $ts);
            $r['delivered_pretty'] = date('M d, Y h:i A', $ts);
            $history[] = $r;
        }
        
        $today = date('Y-m-d');
        $delivered_count = $conn->query("SELECT COUNT(*) as c FROM sales WHERE order_status = 'Completed' AND DATE(delivered_at) = '$today'")->fetch_assoc()['c'];
        
        echo json_encode([
            'success' => true, 'ready' => $ready, 'active' => $active, 'history' => $history, 'drivers' => $drivers, 
            'stats' => ['pending' => count($ready), 'active' => count($active), 'delivered' => $delivered_count]
        ]);
        exit;
    }
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFlow - Logistics</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F3F4F6; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .custom-scroll::-webkit-scrollbar { width: 6px; background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 4px; }
        
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
        .animate-card { animation: fadeIn 0.3s ease-out forwards; }

        /* --- PRINT CSS FIX --- */
        @media print {
            @page { margin: 0; }
            body > *:not(#manifestArea) { display: none !important; }
            #manifestArea { 
                display: block !important; 
                position: absolute; 
                top: 0; 
                left: 0; 
                width: 100%; 
                height: auto; 
                background: white; 
                z-index: 9999;
                padding: 20px;
            }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    
    <?php include '../includes/sidebar.php'; ?>

    <main class="ml-20 flex-1 flex flex-col h-screen overflow-hidden">
        
        <div class="bg-white border-b border-gray-200 p-6 flex-shrink-0">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-[#1E3A1D] flex items-center gap-2">
                        <span class="material-icons">local_shipping</span> Logistics & Dispatch
                    </h1>
                    <p class="text-sm text-gray-500">Assign drivers, print manifests, track history</p>
                </div>
                <div class="flex gap-2">
                    <button onclick="toggleView('dashboard')" id="btn-dash" class="bg-[#1E3A1D] text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 shadow-md">
                        <span class="material-icons text-sm">dashboard</span> Dashboard
                    </button>
                    <button onclick="toggleView('history')" id="btn-hist" class="bg-white border border-gray-300 text-gray-600 hover:text-[#1E3A1D] px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 shadow-sm transition">
                        <span class="material-icons text-sm">history</span> Delivery History
                    </button>
                    <button onclick="openManageDrivers()" class="bg-white border border-gray-300 text-gray-600 hover:text-[#1E3A1D] px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 shadow-sm transition">
                        <span class="material-icons text-sm">person_add</span> Drivers
                    </button>
                </div>
            </div>

            <div class="grid grid-cols-3 gap-6">
                <div class="bg-gradient-to-r from-yellow-50 to-white p-4 rounded-xl border border-yellow-100 flex items-center gap-4">
                    <div class="p-3 bg-yellow-100 text-yellow-700 rounded-lg shadow-sm"><span class="material-icons">inventory_2</span></div>
                    <div><p class="text-xs font-bold text-yellow-600 uppercase tracking-wide">Queue</p><p class="text-2xl font-bold text-gray-800" id="stat-pending">0</p></div>
                </div>
                <div class="bg-gradient-to-r from-blue-50 to-white p-4 rounded-xl border border-blue-100 flex items-center gap-4">
                    <div class="p-3 bg-blue-100 text-blue-700 rounded-lg shadow-sm"><span class="material-icons">local_shipping</span></div>
                    <div><p class="text-xs font-bold text-blue-600 uppercase tracking-wide">In Transit</p><p class="text-2xl font-bold text-gray-800" id="stat-active">0</p></div>
                </div>
                <div class="bg-gradient-to-r from-green-50 to-white p-4 rounded-xl border border-green-100 flex items-center gap-4">
                    <div class="p-3 bg-green-100 text-green-700 rounded-lg shadow-sm"><span class="material-icons">task_alt</span></div>
                    <div><p class="text-xs font-bold text-green-600 uppercase tracking-wide">Completed Today</p><p class="text-2xl font-bold text-gray-800" id="stat-delivered">0</p></div>
                </div>
            </div>
        </div>

        <div id="view-dashboard" class="flex-1 p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-hidden">
            <div class="flex flex-col h-full bg-gray-50 rounded-xl border border-gray-200">
                <div class="p-4 border-b border-gray-200 bg-white rounded-t-xl sticky top-0 z-10">
                    <h3 class="font-bold text-gray-700 flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-yellow-500"></span> Ready to Dispatch</h3>
                </div>
                <div id="ready-list" class="flex-1 overflow-y-auto p-4 space-y-3 custom-scroll"></div>
            </div>
            <div class="flex flex-col h-full bg-blue-50/30 rounded-xl border border-blue-100">
                <div class="p-4 border-b border-blue-100 bg-white rounded-t-xl sticky top-0 z-10">
                    <h3 class="font-bold text-blue-800 flex items-center gap-2"><span class="w-2 h-2 rounded-full bg-blue-500"></span> On The Road</h3>
                </div>
                <div id="active-list" class="flex-1 overflow-y-auto p-4 space-y-3 custom-scroll"></div>
            </div>
        </div>

        <div id="view-history" class="hidden flex-1 p-6 overflow-hidden flex flex-col">
            <div class="bg-white rounded-xl shadow border border-gray-200 flex-1 overflow-hidden flex flex-col">
                <div class="p-4 border-b border-gray-200 bg-gray-50 font-bold text-gray-700">Completed Deliveries Log</div>
                <div class="overflow-y-auto flex-1 custom-scroll">
                    <table class="w-full text-left">
                        <thead class="bg-white sticky top-0 z-10 text-xs font-bold text-gray-500 uppercase border-b border-gray-100">
                            <tr>
                                <th class="p-4">Order #</th>
                                <th class="p-4">Client</th>
                                <th class="p-4">Driver / Plate</th>
                                <th class="p-4">Delivered At</th>
                                <th class="p-4 text-right">Amount</th>
                                <th class="p-4 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="history-list" class="divide-y divide-gray-100 text-sm"></tbody>
                    </table>
                </div>
            </div>
        </div>

    </main>

    <div id="assignModal" class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden z-50 flex justify-center items-center">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div class="bg-[#1E3A1D] p-4 text-white flex justify-between items-center">
                <h3 class="font-bold">Dispatch Order</h3>
                <button onclick="closeModal('assignModal')" class="hover:text-gray-300"><span class="material-icons">close</span></button>
            </div>
            <div class="p-6">
                <p class="text-sm text-gray-500 mb-1">Order Reference</p>
                <div class="text-2xl font-mono font-bold text-gray-800 mb-6">#<span id="modal-sale-id"></span></div>
                <form id="assignForm" class="space-y-4">
                    <input type="hidden" name="action" value="assign_driver">
                    <input type="hidden" name="sale_id" id="form-sale-id">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Select Driver</label>
                        <select name="driver_id" id="driverSelect" required class="w-full p-2 border border-gray-300 rounded-lg bg-white"></select>
                    </div>
                    <button type="submit" class="w-full bg-[#1E3A1D] hover:bg-[#2a4e29] text-white py-2.5 rounded-lg font-bold text-sm shadow-md mt-2">Confirm Assignment</button>
                </form>
            </div>
        </div>
    </div>

    <div id="editHistoryModal" class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden z-50 flex justify-center items-center">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div class="bg-blue-600 p-4 text-white flex justify-between items-center"><h3 class="font-bold">Edit Delivery Details</h3><button onclick="closeModal('editHistoryModal')" class="hover:text-gray-300"><span class="material-icons">close</span></button></div>
            <div class="p-6">
                <p class="text-xs text-gray-500 mb-4">Correcting Record for Order #<span id="edit-sale-id-disp" class="font-bold text-black"></span></p>
                <form id="editHistoryForm" class="space-y-4">
                    <input type="hidden" name="action" value="update_delivery"><input type="hidden" name="sale_id" id="edit-sale-id">
                    <div><label class="block text-xs font-bold text-gray-500 uppercase mb-1">Driver Name</label><input type="text" name="driver_name" id="edit-driver" class="w-full p-2 border rounded-lg"></div>
                    <div><label class="block text-xs font-bold text-gray-500 uppercase mb-1">Vehicle Plate</label><input type="text" name="vehicle_plate" id="edit-plate" class="w-full p-2 border rounded-lg"></div>
                    <div class="grid grid-cols-2 gap-2">
                        <div><label class="block text-xs font-bold text-gray-500 uppercase mb-1">Date</label><input type="date" name="delivery_date" id="edit-date" class="w-full p-2 border rounded-lg"></div>
                        <div><label class="block text-xs font-bold text-gray-500 uppercase mb-1">Time</label><input type="time" name="delivery_time" id="edit-time" class="w-full p-2 border rounded-lg"></div>
                    </div>
                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-lg font-bold text-sm shadow-md mt-2">Save Corrections</button>
                </form>
            </div>
        </div>
    </div>

    <div id="manageDriversModal" class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden z-50 flex justify-center items-center">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden h-[500px] flex flex-col">
            <div class="bg-gray-800 p-4 text-white flex justify-between items-center">
                <h3 class="font-bold">Manage Drivers</h3>
                <button onclick="closeModal('manageDriversModal')" class="hover:text-gray-300"><span class="material-icons">close</span></button>
            </div>
            <div class="p-4 border-b bg-gray-50">
                <form id="addDriverForm" class="flex gap-2">
                    <input type="hidden" name="action" value="add_driver">
                    <input type="text" name="driver_name" placeholder="Driver Name" required class="flex-1 p-2 border rounded text-sm">
                    <input type="text" name="vehicle_plate" placeholder="Plate #" required class="w-24 p-2 border rounded text-sm">
                    <button type="submit" class="bg-green-600 text-white p-2 rounded hover:bg-green-700"><span class="material-icons text-sm">add</span></button>
                </form>
            </div>
            <div class="flex-1 overflow-y-auto p-4 space-y-2 custom-scroll" id="driverList"></div>
        </div>
    </div>

    <div id="manifestArea" class="hidden bg-white">
        <div class="max-w-[800px] mx-auto border-2 border-black p-8 mt-10">
            <div class="flex justify-between items-center border-b-2 border-black pb-4 mb-6">
                <div class="text-3xl font-bold uppercase tracking-widest">Delivery Receipt</div>
                <div class="text-right">
                    <div class="font-bold text-xl">FreshFlow</div>
                    <div class="text-sm text-gray-500">Logistics Department</div>
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-8 mb-8 text-sm font-mono border border-black p-4">
                <div>
                    <p class="mb-2"><span class="font-bold w-20 inline-block">DRIVER:</span> <span id="print-driver" class="border-b border-black w-40 inline-block"></span></p>
                    <p><span class="font-bold w-20 inline-block">PLATE:</span> <span id="print-plate" class="border-b border-black w-40 inline-block"></span></p>
                </div>
                <div class="text-right">
                    <p class="mb-2"><span class="font-bold">DATE:</span> <span id="print-date"></span></p>
                    <p><span class="font-bold">TIME:</span> <span id="print-time"></span></p>
                </div>
            </div>

            <table class="w-full border-collapse border border-black text-sm mb-8">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="border border-black p-2 text-left w-24">Order ID</th>
                        <th class="border border-black p-2 text-left w-48">Client</th>
                        <th class="border border-black p-2 text-left">Items / Details</th>
                        <th class="border border-black p-2 w-32">Amount</th>
                    </tr>
                </thead>
                <tbody id="manifest-table-body"></tbody>
            </table>

            <div class="flex justify-between pt-12 text-sm">
                <div class="text-center">
                    <div class="border-t border-black w-48 pt-1">Driver Signature</div>
                </div>
                <div class="text-center">
                    <div class="border-t border-black w-48 pt-1">Received By</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // --- UI LOGIC ---
        function toggleView(view) {
            const dash = document.getElementById('view-dashboard');
            const hist = document.getElementById('view-history');
            const btnDash = document.getElementById('btn-dash');
            const btnHist = document.getElementById('btn-hist');

            if(view === 'dashboard') {
                dash.classList.remove('hidden');
                hist.classList.add('hidden');
                btnDash.classList.add('bg-[#1E3A1D]', 'text-white'); btnDash.classList.remove('bg-white', 'text-gray-600', 'border');
                btnHist.classList.remove('bg-[#1E3A1D]', 'text-white'); btnHist.classList.add('bg-white', 'text-gray-600', 'border');
            } else {
                dash.classList.add('hidden');
                hist.classList.remove('hidden');
                btnHist.classList.add('bg-[#1E3A1D]', 'text-white'); btnHist.classList.remove('bg-white', 'text-gray-600', 'border');
                btnDash.classList.remove('bg-[#1E3A1D]', 'text-white'); btnDash.classList.add('bg-white', 'text-gray-600', 'border');
            }
        }

        async function fetchData() {
            try {
                const res = await fetch('', { method: 'POST', body: new URLSearchParams({ action: 'fetch_data' }) }).then(r => r.json());
                if(res.success) {
                    renderReady(res.ready);
                    renderActive(res.active);
                    renderHistory(res.history);
                    renderDrivers(res.drivers);
                    document.getElementById('stat-pending').innerText = res.stats.pending;
                    document.getElementById('stat-active').innerText = res.stats.active;
                    document.getElementById('stat-delivered').innerText = res.stats.delivered;
                }
            } catch(e) { console.error(e); }
        }

        function renderDrivers(drivers) {
            const driverSelect = document.getElementById('driverSelect');
            const driverList = document.getElementById('driverList');
            
            driverSelect.innerHTML = '<option value="" disabled selected>Select Driver...</option>';
            driverList.innerHTML = '';
            
            drivers.forEach(d => {
                driverSelect.innerHTML += `<option value="${d.driver_id}">${d.driver_name} (${d.vehicle_plate})</option>`;
                driverList.innerHTML += `
                    <div class="flex justify-between items-center bg-white p-3 rounded border shadow-sm">
                        <div>
                            <p class="font-bold text-sm text-gray-800">${d.driver_name}</p>
                            <p class="text-xs text-gray-500">${d.vehicle_plate}</p>
                        </div>
                        <button onclick="deleteDriver(${d.driver_id})" class="text-red-400 hover:text-red-600"><span class="material-icons text-sm">delete</span></button>
                    </div>`;
            });
        }

        function renderReady(orders) {
            const list = document.getElementById('ready-list');
            if(orders.length === 0) { list.innerHTML = `<div class="flex flex-col items-center justify-center h-48 text-gray-400"><span class="material-icons text-4xl mb-2 text-gray-300">inventory</span><p class="text-sm">No packed orders ready.</p></div>`; return; }
            list.innerHTML = '';
            orders.forEach(o => {
                list.innerHTML += `
                <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition animate-card mb-3">
                    <div class="flex justify-between items-start mb-2"><span class="font-mono font-bold text-[#1E3A1D] bg-green-50 px-2 py-0.5 rounded text-sm">#${String(o.sale_id).padStart(5, '0')}</span><span class="text-xs text-gray-400">${o.formatted_date}</span></div>
                    <h4 class="font-bold text-gray-800 text-sm mb-1">${o.client_name}</h4>
                    <p class="text-xs text-gray-500 bg-gray-50 p-2 rounded mb-3 line-clamp-2">${o.item_summary}</p>
                    <button onclick="openAssignModal(${o.sale_id})" class="w-full bg-white border border-gray-300 hover:border-[#1E3A1D] hover:text-[#1E3A1D] text-gray-600 py-1.5 rounded text-xs font-bold transition flex justify-center items-center gap-2"><span>Assign Driver</span> <span class="material-icons text-xs">arrow_forward</span></button>
                </div>`;
            });
        }

        function renderActive(orders) {
            const list = document.getElementById('active-list');
            if(orders.length === 0) { list.innerHTML = `<div class="flex flex-col items-center justify-center h-48 text-gray-400"><span class="material-icons text-4xl mb-2 text-gray-300">local_shipping</span><p class="text-sm">No active deliveries.</p></div>`; return; }
            list.innerHTML = '';
            orders.forEach(o => {
                const isThirdParty = o.driver_name.includes('Lalamove') || o.driver_name.includes('Grab');
                const badgeColor = isThirdParty ? 'bg-orange-100 text-orange-700' : 'bg-blue-100 text-blue-700';
                list.innerHTML += `
                <div class="bg-white p-4 rounded-lg shadow-sm border-l-4 border-blue-500 animate-card mb-3">
                    <div class="flex justify-between items-start mb-2">
                        <div class="flex items-center gap-2"><span class="font-mono font-bold text-blue-700 text-sm">#${String(o.sale_id).padStart(5, '0')}</span><span class="text-[10px] uppercase font-bold text-gray-400">Dispatched ${o.time_ago}</span></div>
                        <button onclick="printManifest('${o.driver_name}', '${o.vehicle_plate}', '${String(o.sale_id).padStart(5,'0')}', '${o.client_name}', '${o.item_summary.replace(/'/g, "")}', '${o.total_amount}')" class="text-gray-400 hover:text-blue-600"><span class="material-icons text-sm">print</span></button>
                    </div>
                    <h4 class="font-bold text-gray-800 text-sm mb-2">${o.client_name}</h4>
                    <div class="flex items-center gap-2 text-xs mb-3 ${badgeColor} p-1.5 rounded w-fit"><span class="material-icons text-[14px]">local_shipping</span><span class="font-bold">${o.driver_name}</span><span class="text-opacity-50">|</span><span class="font-mono">${o.vehicle_plate}</span></div>
                    <button onclick="markDone(${o.sale_id})" class="w-full bg-green-600 hover:bg-green-700 text-white py-1.5 rounded text-xs font-bold transition flex justify-center items-center gap-1"><span class="material-icons text-xs">check</span> Mark Delivered</button>
                </div>`;
            });
        }

        function renderHistory(hist) {
            const list = document.getElementById('history-list');
            list.innerHTML = '';
            hist.forEach(h => {
                // ESCAPE STRINGS FOR JS
                const safeItems = h.item_summary.replace(/'/g, "\\'");
                const safeClient = h.client_name.replace(/'/g, "\\'");
                
                list.innerHTML += `
                <tr class="hover:bg-gray-50 border-b border-gray-100">
                    <td class="p-4 font-mono font-bold text-[#1E3A1D]">#${String(h.sale_id).padStart(5,'0')}</td>
                    <td class="p-4 font-bold text-gray-700">${h.client_name}</td>
                    <td class="p-4 text-gray-600 flex items-center gap-2">
                        <span class="material-icons text-xs">local_shipping</span> 
                        <div><p class="font-bold text-xs">${h.driver_name}</p><p class="text-[10px] text-gray-400">${h.vehicle_plate}</p></div>
                    </td>
                    <td class="p-4 text-gray-500 text-xs">${h.delivered_pretty}</td>
                    <td class="p-4 text-right font-bold text-gray-800">₱${parseFloat(h.total_amount || 0).toLocaleString()}</td>
                    <td class="p-4 text-center">
                        <div class="flex justify-center gap-1">
                            <button onclick="openEditHistory(${h.sale_id}, '${h.driver_name}', '${h.vehicle_plate}', '${h.delivered_date_raw}', '${h.delivered_time_raw}')" class="text-blue-500 hover:bg-blue-50 p-1 rounded" title="Edit Details"><span class="material-icons text-sm">edit</span></button>
                            <button onclick="printManifest('${h.driver_name}', '${h.vehicle_plate}', '${h.sale_id}', '${safeClient}', '${safeItems}', '${h.total_amount}')" class="text-gray-500 hover:bg-gray-100 p-1 rounded" title="Reprint"><span class="material-icons text-sm">print</span></button>
                        </div>
                    </td>
                </tr>`;
            });
        }

        // --- ACTIONS ---
        function openAssignModal(id) { document.getElementById('modal-sale-id').textContent = String(id).padStart(5, '0'); document.getElementById('form-sale-id').value = id; document.getElementById('assignModal').classList.remove('hidden'); }
        function openManageDrivers() { document.getElementById('manageDriversModal').classList.remove('hidden'); }
        function openEditHistory(id, driver, plate, date, time) {
            document.getElementById('edit-sale-id').value = id;
            document.getElementById('edit-sale-id-disp').textContent = String(id).padStart(5, '0');
            document.getElementById('edit-driver').value = driver;
            document.getElementById('edit-plate').value = plate;
            document.getElementById('edit-date').value = date;
            document.getElementById('edit-time').value = time;
            document.getElementById('editHistoryModal').classList.remove('hidden');
        }
        function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

        document.getElementById('assignForm').onsubmit = async (e) => { e.preventDefault(); await fetch('', { method: 'POST', body: new FormData(e.target) }); closeModal('assignModal'); fetchData(); };
        document.getElementById('editHistoryForm').onsubmit = async (e) => { e.preventDefault(); await fetch('', { method: 'POST', body: new FormData(e.target) }); closeModal('editHistoryModal'); fetchData(); };
        document.getElementById('addDriverForm').onsubmit = async (e) => { e.preventDefault(); const res = await fetch('', { method: 'POST', body: new FormData(e.target) }).then(r => r.json()); if(res.success) { e.target.reset(); fetchData(); } };
        async function deleteDriver(id) { if(confirm('Delete driver?')) { await fetch('', { method: 'POST', body: new URLSearchParams({ action: 'delete_driver', driver_id: id }) }); fetchData(); } }
        async function markDone(id) { if(confirm('Confirm delivery complete?')) { await fetch('', { method: 'POST', body: new URLSearchParams({ action: 'mark_delivered', sale_id: id }) }); fetchData(); } }

        function printManifest(driver, plate, id, client, items, total) {
            document.getElementById('print-driver').textContent = driver;
            document.getElementById('print-plate').textContent = plate;
            document.getElementById('print-date').textContent = new Date().toLocaleDateString();
            document.getElementById('print-time').textContent = new Date().toLocaleTimeString();
            
            document.getElementById('manifest-table-body').innerHTML = `
                <tr>
                    <td class="border border-black p-2 font-mono">#${id}</td>
                    <td class="border border-black p-2 font-bold">${client}</td>
                    <td class="border border-black p-2 text-xs italic">${items}</td>
                    <td class="border border-black p-2 font-bold text-right">₱${parseFloat(total).toLocaleString()}</td>
                </tr>`;
            setTimeout(() => window.print(), 300);
        }

        fetchData(); setInterval(fetchData, 30000);
    </script>
</body>
</html>