<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\order_queue.php
ob_start();
session_start();
include_once '../includes/db_connection.php';

// --- AUDIT HELPER ---
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) { include_once $auditHelperPath; } 
else { if (!function_exists('log_audit_action')) { function log_audit_action($a, $b, $c, $d = []) { return true; } } }

// --- 1. HANDLE AJAX REQUEST FOR ITEMS (Populates the Modal) ---
if (isset($_GET['action']) && $_GET['action'] === 'get_items' && isset($_GET['id'])) {
    ob_clean();
    header('Content-Type: application/json');
    
    $sale_id = intval($_GET['id']);
    
    $query = "
        SELECT si.*, p.name, p.product_brand, p.image_url, p.unit
        FROM sales_items si
        JOIN products p ON si.product_id = p.product_id
        WHERE si.sale_id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode($items);
    exit; 
}

// --- 2. HANDLE STATUS UPDATES ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // ACTION: UPDATE STATUS
    if ($_POST['action'] === 'update_status') {
        $sale_id = intval($_POST['sale_id']);
        $new_status = $_POST['new_status'];
        
        // If marking as Completed, set the delivered_at timestamp
        $sql = "UPDATE sales SET order_status = ?";
        if ($new_status === 'Completed') {
            $sql .= ", delivered_at = NOW(), payment_status = 'Pending'"; 
        }
        $sql .= " WHERE sale_id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $new_status, $sale_id);
        
        if($stmt->execute()) {
             // Logic handled in SQL above
        }
        header("Location: order_queue.php?success=status_updated");
        exit;
    }

    // ACTION: CANCEL ORDER
    if ($_POST['action'] === 'cancel_order') {
        $sale_id = intval($_POST['sale_id']);

        if ($sale_id > 0) {
            $conn->begin_transaction();
            try {
                // 1. Get items to restore inventory
                $stmt = $conn->prepare("SELECT product_id, quantity FROM sales_items WHERE sale_id = ?");
                $stmt->bind_param("i", $sale_id);
                $stmt->execute();
                $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

                // 2. Restore Inventory
                $update_inv = $conn->prepare("UPDATE product_inventory SET quantity = quantity + ? WHERE product_id = ?");
                foreach ($items as $item) {
                    $update_inv->bind_param("di", $item['quantity'], $item['product_id']);
                    $update_inv->execute();
                }

                // 3. Update Status to Cancelled
                $cancel_stmt = $conn->prepare("UPDATE sales SET order_status = 'Cancelled', payment_status = 'Cancelled' WHERE sale_id = ?");
                $cancel_stmt->bind_param("i", $sale_id);
                $cancel_stmt->execute();

                $conn->commit();
                
                if (function_exists('log_audit_action')) log_audit_action('Cancel', 'Fulfillment', "Cancelled Order #$sale_id (Restocked)");

                header("Location: order_queue.php?success=order_cancelled");
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                header("Location: order_queue.php?error=cancel_failed");
                exit;
            }
        }
    }
}

// --- 3. FETCH ORDERS LIST ---
$query = "
    SELECT s.*, c.client_name
    FROM sales s
    LEFT JOIN clients c ON s.client_id = c.client_id
    ORDER BY 
        CASE 
            WHEN s.order_status = 'Pending' THEN 1
            WHEN s.order_status = 'Packed' THEN 2
            WHEN s.order_status = 'Out for Delivery' THEN 3
            WHEN s.order_status = 'Completed' THEN 4
            ELSE 5 -- Cancelled last
        END,
        s.delivery_date ASC
";
$orders = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// --- 4. CALCULATE STATS ---
$stats = [
    'Pending' => 0, 'Packed' => 0, 'Out for Delivery' => 0, 'Completed' => 0, 'Cancelled' => 0, 'Total_Revenue_Pending' => 0
];
foreach ($orders as $o) {
    $status = $o['order_status'] ?? 'Pending';
    if (isset($stats[$status])) $stats[$status]++;
    // Only count revenue for active/completed orders
    if ($status !== 'Cancelled' && $status !== 'Completed') $stats['Total_Revenue_Pending'] += (float)($o['total_amount'] ?? 0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Order Fulfillment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F3F4F6; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 3px; }
        
        /* Stepper */
        .step-connector { flex-grow: 1; height: 2px; background-color: #E2E8F0; margin: 0 4px; }
        .step-connector.active { background-color: #1E3A1D; }
        .step-circle { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: bold; color: white; background-color: #E2E8F0; }
        .step-circle.active { background-color: #1E3A1D; }
        
        /* Actions */
        .btn-action { transition: all 0.2s; }
        .btn-action:active { transform: scale(0.95); }
        
        /* Cancelled Style */
        .order-row[data-status="Cancelled"] { opacity: 0.6; background-color: #f9fafb; }
        .order-row[data-status="Cancelled"] td { text-decoration: line-through; color: #9ca3af; }
        .order-row[data-status="Cancelled"] .no-strike { text-decoration: none; } /* For badges/buttons */

        @media print {
            body * { visibility: hidden; }
            #orderModal, #orderModal * { visibility: visible; }
            #orderModal { position: absolute; left: 0; top: 0; width: 100%; height: auto; background: white; padding: 0; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    
    <?php include '../includes/sidebar.php'; ?>

    <main class="ml-20 flex-1 flex flex-col h-screen overflow-hidden relative">
        <div class="bg-white border-b border-gray-200 p-6 flex-shrink-0">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-[#1E3A1D] flex items-center gap-2">
                        <span class="material-icons">inventory</span> Fulfillment Queue
                    </h1>
                    <p class="text-sm text-gray-500">Track, pack, and ship client orders</p>
                </div>
                <a href="order_create.php" class="bg-[#1E3A1D] hover:bg-[#2a4e29] text-white px-5 py-2.5 rounded-lg font-bold shadow-lg flex items-center gap-2 transition transform active:scale-95">
                    <span class="material-icons text-sm">add</span> New Order
                </a>
            </div>

            <div class="grid grid-cols-4 gap-4">
                <div class="bg-orange-50 border border-orange-100 p-4 rounded-xl flex items-center gap-4">
                    <div class="p-3 bg-orange-100 text-orange-600 rounded-lg"><span class="material-icons">pending_actions</span></div>
                    <div><p class="text-xs font-bold text-orange-400 uppercase">To Pack</p><p class="text-2xl font-bold text-orange-900"><?= $stats['Pending'] ?></p></div>
                </div>
                <div class="bg-blue-50 border border-blue-100 p-4 rounded-xl flex items-center gap-4">
                    <div class="p-3 bg-blue-100 text-blue-600 rounded-lg"><span class="material-icons">inventory_2</span></div>
                    <div><p class="text-xs font-bold text-blue-400 uppercase">To Ship</p><p class="text-2xl font-bold text-blue-900"><?= $stats['Packed'] ?></p></div>
                </div>
                <div class="bg-red-50 border border-red-100 p-4 rounded-xl flex items-center gap-4">
                    <div class="p-3 bg-red-100 text-red-600 rounded-lg"><span class="material-icons">cancel</span></div>
                    <div><p class="text-xs font-bold text-red-400 uppercase">Cancelled</p><p class="text-2xl font-bold text-red-900"><?= $stats['Cancelled'] ?></p></div>
                </div>
                <div class="bg-green-50 border border-green-100 p-4 rounded-xl flex items-center gap-4">
                    <div class="p-3 bg-green-100 text-green-600 rounded-lg"><span class="material-icons">payments</span></div>
                    <div><p class="text-xs font-bold text-green-400 uppercase">Open Value</p><p class="text-2xl font-bold text-green-900">₱<?= number_format($stats['Total_Revenue_Pending'] / 1000, 1) ?>k</p></div>
                </div>
            </div>
        </div>

        <div class="flex-1 overflow-hidden flex flex-col p-6">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-4">
                <div class="flex bg-white p-1 rounded-lg border border-gray-200 shadow-sm">
                    <button onclick="filterStatus('All')" class="filter-btn active px-4 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:bg-gray-50" data-status="All">All</button>
                    <button onclick="filterStatus('Pending')" class="filter-btn px-4 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:bg-gray-50" data-status="Pending">Pending</button>
                    <button onclick="filterStatus('Packed')" class="filter-btn px-4 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:bg-gray-50" data-status="Packed">Packed</button>
                    <button onclick="filterStatus('Out for Delivery')" class="filter-btn px-4 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:bg-gray-50" data-status="Out for Delivery">In Transit</button>
                    <button onclick="filterStatus('Cancelled')" class="filter-btn px-4 py-1.5 rounded-md text-sm font-medium transition text-gray-600 hover:text-red-600 hover:bg-red-50" data-status="Cancelled">Cancelled</button>
                </div>
                
                <div class="relative w-full md:w-64">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400"><span class="material-icons text-sm">search</span></span>
                    <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search Order ID or Client..." class="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-green-800 focus:ring-1 focus:ring-green-800 transition">
                </div>
            </div>

            <div class="bg-white rounded-xl shadow border border-gray-200 flex-1 overflow-hidden flex flex-col">
                <div class="overflow-y-auto flex-1">
                    <table class="w-full text-left" id="ordersTable">
                        <thead class="bg-gray-50 text-gray-500 text-xs uppercase font-bold sticky top-0 z-10 border-b border-gray-200">
                            <tr>
                                <th class="p-4 w-24">Order ID</th>
                                <th class="p-4">Client Details</th>
                                <th class="p-4 w-48">Timeline</th>
                                <th class="p-4 w-32">Date</th>
                                <th class="p-4 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if (empty($orders)): ?>
                                <tr><td colspan="5" class="p-10 text-center text-gray-400 italic">No orders found in the system.</td></tr>
                            <?php else: ?>
                                <?php foreach ($orders as $o): 
                                    $s = $o['order_status'] ?? 'Pending';
                                    
                                    // Step Logic
                                    $step1 = ($s == 'Pending' || $s == 'Packed' || $s == 'Out for Delivery' || $s == 'Completed');
                                    $step2 = ($s == 'Packed' || $s == 'Out for Delivery' || $s == 'Completed');
                                    $step3 = ($s == 'Out for Delivery' || $s == 'Completed');
                                    $step4 = ($s == 'Completed');
                                    
                                    // Date Logic: Show Completed Date if done, otherwise Scheduled Date
                                    if ($s == 'Completed' && !empty($o['delivered_at'])) {
                                        $displayDate = $o['delivered_at'];
                                        $dateLabel = 'DELIVERED';
                                        $badgeColor = 'bg-green-100 text-green-700 border-green-200';
                                    } else {
                                        $displayDate = $o['delivery_date'];
                                        $dateLabel = 'SCHEDULED';
                                        $badgeColor = 'bg-gray-100 text-gray-600 border-gray-200';
                                    }

                                    $dateStr = $displayDate ?? null;
                                    $isToday = ($dateStr && date('Y-m-d') == date('Y-m-d', strtotime($dateStr)));
                                    $isOverdue = ($dateStr && date('Y-m-d') > date('Y-m-d', strtotime($dateStr))) && $s != 'Completed' && $s != 'Cancelled';
                                    
                                    $clientName = htmlspecialchars($o['client_name'] ?? 'Unknown Client');
                                    $isCancelled = ($s == 'Cancelled');
                                ?>
                                <tr class="order-row group hover:bg-gray-50 transition" data-status="<?= $s ?>">
                                    <td class="p-4 align-top">
                                        <div class="font-mono font-bold text-[#1E3A1D] bg-green-50 px-2 py-1 rounded inline-block no-strike">
                                            #<?= str_pad($o['sale_id'], 5, '0', STR_PAD_LEFT) ?>
                                        </div>
                                    </td>
                                    <td class="p-4 align-top">
                                        <div class="font-bold text-gray-800 text-sm"><?= $clientName ?></div>
                                        <?php if(!$isCancelled): ?>
                                            <div class="text-xs text-gray-500 mt-0.5 flex items-center gap-1"><span class="material-icons text-[10px]">person</span> Valid Customer</div>
                                            <div class="mt-2 text-xs font-bold text-gray-400 uppercase">Value: <span class="text-gray-700">₱<?= number_format((float)($o['total_amount'] ?? 0), 2) ?></span></div>
                                        <?php else: ?>
                                            <div class="text-xs text-red-400 mt-1 font-bold uppercase no-strike">ORDER CANCELLED</div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 align-middle">
                                        <?php if(!$isCancelled): ?>
                                            <div class="flex items-center justify-between w-full max-w-[180px]">
                                                <div class="step-circle <?= $step1 ? 'active' : '' ?>" title="Pending">1</div>
                                                <div class="step-connector <?= $step2 ? 'active' : '' ?>"></div>
                                                <div class="step-circle <?= $step2 ? 'active' : '' ?>" title="Packed">2</div>
                                                <div class="step-connector <?= $step3 ? 'active' : '' ?>"></div>
                                                <div class="step-circle <?= $step3 ? 'active' : '' ?>" title="Out for Delivery">3</div>
                                                <div class="step-connector <?= $step4 ? 'active' : '' ?>"></div>
                                                <div class="step-circle <?= $step4 ? 'active' : '' ?>" title="Completed"><span class="material-icons text-[10px]">check</span></div>
                                            </div>
                                            <div class="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-wide text-center w-full max-w-[180px]"><?= $s ?></div>
                                        <?php else: ?>
                                            <div class="bg-red-50 text-red-500 text-xs font-bold px-3 py-1 rounded-full text-center border border-red-100 no-strike">
                                                <span class="material-icons text-sm align-middle">block</span> Cancelled
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-4 align-top">
                                        <?php if ($dateStr): ?>
                                            <div class="text-sm font-medium text-gray-700"><?= date('M d, Y', strtotime($dateStr)) ?></div>
                                            <div class="text-[10px] text-gray-400"><?= date('h:i A', strtotime($dateStr)) ?></div>
                                            
                                            <?php if($s == 'Completed'): ?>
                                                <span class="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-green-100 text-green-700 border border-green-200 no-strike">DELIVERED</span>
                                            <?php elseif($isToday && !$isCancelled): ?>
                                                <span class="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-700 border border-orange-200 no-strike">TODAY</span>
                                            <?php elseif($isOverdue): ?>
                                                <span class="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-700 border border-red-200 no-strike">OVERDUE</span>
                                            <?php endif; ?>
                                        <?php else: ?><span class="text-xs text-gray-400 italic">No Date</span><?php endif; ?>
                                    </td>
                                    <td class="p-4 align-middle text-right">
                                        <div class="flex justify-end gap-2 items-center no-strike">
                                            
                                            <?php if ($s == 'Packed'): ?>
                                                <form method="POST" class="inline">
                                                    <input type="hidden" name="action" value="update_status">
                                                    <input type="hidden" name="sale_id" value="<?= $o['sale_id'] ?>">
                                                    <button type="submit" name="new_status" value="Pending" title="Undo to Pending" class="bg-gray-100 hover:bg-gray-200 text-gray-600 px-2 py-1.5 rounded shadow-sm btn-action transition"><span class="material-icons text-sm">undo</span></button>
                                                </form>
                                            <?php endif; ?>

                                            <form method="POST" class="inline">
                                                <input type="hidden" name="action" value="update_status">
                                                <input type="hidden" name="sale_id" value="<?= $o['sale_id'] ?>">
                                                
                                                <?php if ($s == 'Pending'): ?>
                                                    <button type="submit" name="new_status" value="Packed" class="bg-[#1E3A1D] hover:bg-[#2a4e29] text-white px-3 py-1.5 rounded text-xs font-bold shadow-sm btn-action flex items-center gap-1">Pack <span class="material-icons text-[14px]">inventory_2</span></button>
                                                
                                                <?php elseif ($s == 'Packed'): ?>
                                                    <span class="text-xs text-blue-500 font-bold bg-blue-50 px-2 py-1 rounded border border-blue-100 cursor-default" title="Assign Driver in Dispatch Module">Ready for Dispatch</span>
                                                
                                                <?php elseif ($s == 'Out for Delivery'): ?>
                                                    <span class="text-xs text-purple-500 font-bold bg-purple-50 px-2 py-1 rounded border border-purple-100 cursor-default">On the Way</span>
                                                
                                                <?php elseif ($s == 'Cancelled'): ?>
                                                    <span class="text-xs text-gray-400 italic">No Actions</span>
                                                <?php endif; ?>
                                            </form>
                                            
                                            <button onclick="openOrderModal(<?= $o['sale_id'] ?>, '<?= $clientName ?>', '<?= $dateStr ? date('M d, Y', strtotime($dateStr)) : 'N/A' ?>')" class="border border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-500 px-2 py-1.5 rounded transition" title="View Details"><span class="material-icons text-sm">visibility</span></button>
                                            
                                            <?php if ($s != 'Cancelled' && $s != 'Completed'): ?>
                                                <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to CANCEL this order?\n\n- Stock will be restored\n- Order will be marked Cancelled');">
                                                    <input type="hidden" name="action" value="cancel_order">
                                                    <input type="hidden" name="sale_id" value="<?= $o['sale_id'] ?>">
                                                    <button type="submit" class="bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-500 px-2 py-1.5 rounded transition border border-gray-200 hover:border-red-200" title="Cancel Order"><span class="material-icons text-sm">block</span></button>
                                                </form>
                                            <?php endif; ?>

                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <div id="orderModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex justify-center items-center backdrop-blur-sm modal print-full-width p-4">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden transform transition-all scale-100 flex flex-col max-h-[90vh]">
            <div class="p-6 border-b border-gray-200 flex justify-between items-start bg-gray-50 print:bg-white">
                <div><div class="text-[#1E3A1D] font-black text-2xl tracking-tight uppercase">PACKING SLIP</div><div class="text-sm text-gray-500 mt-1">FreshFlow Distribution Center</div></div>
                <div class="text-right"><h2 class="text-xl font-mono font-bold text-gray-800" id="modalOrderId">#00000</h2><p class="text-xs text-gray-500" id="modalDate">Jan 01, 2026</p></div>
            </div>
            <div class="px-6 py-4 bg-white border-b border-gray-100 grid grid-cols-2 gap-4">
                <div><span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Bill To</span><div class="font-bold text-gray-800 text-lg" id="modalClientName">Client Name</div></div>
                <div><span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Order Status</span><div class="text-sm text-gray-600">Standard Fulfillment</div></div>
            </div>
            <div class="flex-1 overflow-y-auto p-6">
                <table class="w-full text-left border-collapse">
                    <thead><tr class="text-xs font-bold text-gray-400 uppercase border-b-2 border-gray-100"><th class="pb-2 w-16">Qty</th><th class="pb-2">Description</th><th class="pb-2 text-right">Unit Price</th><th class="pb-2 text-right">Amount</th></tr></thead>
                    <tbody id="modalItemsBody" class="text-sm text-gray-700"></tbody>
                    <tfoot><tr class="border-t-2 border-gray-100"><td colspan="3" class="pt-4 text-right font-bold text-gray-500 uppercase text-xs">Total Due</td><td class="pt-4 text-right font-black text-xl text-[#1E3A1D]" id="modalTotal">₱0.00</td></tr></tfoot>
                </table>
            </div>
            <div class="bg-gray-50 p-4 flex justify-between items-center border-t border-gray-200 no-print">
                <div class="text-xs text-gray-400 italic">Generated by FreshFlow System</div>
                <div class="flex gap-3"><button onclick="window.print()" class="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-bold hover:bg-gray-50 flex items-center gap-2 shadow-sm"><span class="material-icons text-sm">print</span> Print Slip</button><button onclick="closeModal()" class="bg-[#1E3A1D] text-white px-6 py-2 rounded-lg font-bold hover:bg-[#2a4e29] shadow-md">Done</button></div>
            </div>
        </div>
    </div>

    <script>
        function filterStatus(status) {
            document.querySelectorAll('.filter-btn').forEach(btn => {
                const btnStatus = btn.dataset.status;
                
                // Reset styles
                btn.className = 'filter-btn px-4 py-1.5 rounded-md text-sm font-medium transition';
                
                if(btnStatus === status) {
                    // Active State
                    if(status === 'Cancelled') {
                        btn.classList.add('bg-red-600', 'text-white', 'shadow-md');
                    } else {
                        btn.classList.add('bg-[#1E3A1D]', 'text-white', 'shadow-md');
                    }
                } else {
                    // Inactive State
                    if(btnStatus === 'Cancelled') {
                        btn.classList.add('text-red-500', 'hover:bg-red-50');
                    } else {
                        btn.classList.add('text-gray-600', 'hover:bg-gray-50');
                    }
                }
            });
            
            const rows = document.querySelectorAll('.order-row');
            rows.forEach(row => { 
                const rowStatus = row.dataset.status;
                if(status === 'All') {
                    // In 'All' view, usually we hide Cancelled to keep it clean, or show all. 
                    // Let's hide Cancelled in 'All' view to avoid clutter, as requested "toggle where i can see cancelled"
                    row.style.display = (rowStatus !== 'Cancelled') ? '' : 'none';
                } else {
                    row.style.display = (rowStatus === status) ? '' : 'none'; 
                }
            });
        }
        function searchTable() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            document.querySelectorAll('.order-row').forEach(row => {
                // Allow search to override filter temporarily
                if (row.style.display !== 'none' || input === '') { row.style.display = row.innerText.toLowerCase().includes(input) ? '' : 'none'; }
            });
        }
        filterStatus('All');
        const modal = document.getElementById('orderModal');
        const modalBody = document.getElementById('modalItemsBody');
        function closeModal() { modal.classList.add('hidden'); }
        async function openOrderModal(saleId, clientName, dateStr) {
            document.getElementById('modalOrderId').textContent = "#" + String(saleId).padStart(5, '0');
            document.getElementById('modalClientName').textContent = clientName;
            document.getElementById('modalDate').textContent = dateStr;
            modalBody.innerHTML = '<tr><td colspan="4" class="text-center py-8"><span class="animate-spin material-icons text-gray-300">autorenew</span></td></tr>';
            modal.classList.remove('hidden');
            try {
                const response = await fetch(`order_queue.php?action=get_items&id=${saleId}`);
                const items = await response.json();
                modalBody.innerHTML = '';
                let total = 0;
                if (items.length === 0) { modalBody.innerHTML = '<tr><td colspan="4" class="text-center py-4 italic text-gray-400">No items found.</td></tr>'; } 
                else {
                    items.forEach(item => {
                        const subtotal = parseFloat(item.quantity) * parseFloat(item.price);
                        total += subtotal;
                        modalBody.innerHTML += `<tr class="border-b border-gray-50"><td class="py-3 font-mono font-bold text-gray-800 text-center bg-gray-50 rounded">${parseFloat(item.quantity)} <span class="text-[10px] text-gray-400 font-normal">${item.unit || ''}</span></td><td class="py-3 pl-4"><div class="font-bold text-gray-800">${item.name}</div><div class="text-[10px] text-gray-400 uppercase tracking-wide">${item.product_brand || 'Generic'}</div></td><td class="py-3 text-right text-gray-500">₱${parseFloat(item.price).toFixed(2)}</td><td class="py-3 text-right font-bold text-gray-800">₱${subtotal.toFixed(2)}</td></tr>`;
                    });
                }
                document.getElementById('modalTotal').textContent = '₱' + total.toLocaleString('en-US', {minimumFractionDigits: 2});
            } catch (error) { console.error(error); modalBody.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-red-500">Error loading items.</td></tr>'; }
        }
        document.addEventListener('keydown', (e) => { if(e.key === 'Escape') closeModal(); });
    </script>
</body>
</html>