<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\order_create.php
ob_start();
session_start();
include_once '../includes/db_connection.php';

// --- SEARCH & DEFAULT LOAD LOGIC ---
$search_results = [];

// FIXED QUERY: Added GROUP BY to prevent duplicates if inventory has multiple entries
// Also used SUM() so if you have two inventory rows (e.g., 5 and 10), it shows 15 total.
$sql_base = "SELECT p.*, SUM(COALESCE(pi.quantity, 0)) as current_stock 
             FROM products p 
             LEFT JOIN product_inventory pi ON p.product_id = pi.product_id";

if (isset($_GET['search_query']) && !empty($_GET['search_query'])) {
    // Search Mode
    $q = "%" . trim($_GET['search_query']) . "%";
    // Added GROUP BY p.product_id
    $stmt = $conn->prepare("$sql_base WHERE p.name LIKE ? OR p.product_brand LIKE ? GROUP BY p.product_id LIMIT 20");
    $stmt->bind_param("ss", $q, $q);
    $stmt->execute();
    $search_results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    // Default Mode
    // Added GROUP BY p.product_id
    $search_results = $conn->query("$sql_base GROUP BY p.product_id ORDER BY p.name ASC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
}

// --- SUBMIT ORDER LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_order') {
    $client_id = intval($_POST['client_id']);
    $delivery_date = $_POST['delivery_date'];
    $items = json_decode($_POST['cart_items'], true);
    $total = floatval($_POST['total_amount']);
    $created_by = $_SESSION['user_id'] ?? 1; 

    if ($client_id > 0 && !empty($items)) {
        
        // --- 1. STRICT STOCK VALIDATION ---
        $stock_errors = [];
        // Use SUM in validation too, just in case
        $check_stmt = $conn->prepare("SELECT p.name, SUM(COALESCE(pi.quantity, 0)) as quantity FROM products p LEFT JOIN product_inventory pi ON p.product_id = pi.product_id WHERE p.product_id = ? GROUP BY p.product_id");
        
        foreach ($items as $item) {
            $check_stmt->bind_param("i", $item['id']);
            $check_stmt->execute();
            $result = $check_stmt->get_result()->fetch_assoc();
            
            // If product exists in DB
            if ($result) {
                $available_stock = floatval($result['quantity']);
                $requested_qty = floatval($item['qty']);
                $prod_name = $result['name'];
                
                if ($available_stock <= 0) {
                    $stock_errors[] = "Error: '$prod_name' is Out of Stock (Available: 0).";
                } elseif ($available_stock < $requested_qty) {
                    $stock_errors[] = "Error: Insufficient stock for '$prod_name'. Requested: $requested_qty, Available: $available_stock.";
                }
            } else {
                $stock_errors[] = "Error: Product ID {$item['id']} not found in database.";
            }
        }
        $check_stmt->close();

        if (!empty($stock_errors)) {
            $error_msg = implode("\\n", $stock_errors);
            echo "<script>alert('$error_msg'); window.history.back();</script>";
            exit;
        }
        // --- END VALIDATION ---

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO sales (created_by, client_id, total_amount, order_status, payment_status, delivery_date) VALUES (?, ?, ?, 'Pending', 'Pending', ?)");
            $stmt->bind_param("iids", $created_by, $client_id, $total, $delivery_date);
            
            if (!$stmt->execute()) throw new Exception("Database Error: " . $stmt->error);
            $sale_id = $conn->insert_id;

            $stmt_item = $conn->prepare("INSERT INTO sales_items (sale_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)");
            // Inventory deduction assumes typical structure. 
            // If you have duplicates, this reduces one of them randomly. 
            // Ideally, you should clean your DB, but this query works for standard setups.
            $stmt_inv = $conn->prepare("UPDATE product_inventory SET quantity = quantity - ? WHERE product_id = ? LIMIT 1");

            foreach ($items as $item) {
                $subtotal = $item['price'] * $item['qty'];
                $stmt_item->bind_param("iiddd", $sale_id, $item['id'], $item['qty'], $item['price'], $subtotal);
                $stmt_item->execute();

                $stmt_inv->bind_param("di", $item['qty'], $item['id']);
                $stmt_inv->execute();
            }

            $conn->commit();
            header("Location: order_queue.php?success=1");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            die("Error submitting order: " . $e->getMessage()); 
        }
    } else {
        echo "<script>alert('Please select a client and add items.'); window.history.back();</script>";
        exit;
    }
}

// Fetch Clients
$clients = $conn->query("SELECT * FROM clients WHERE status='Active' ORDER BY client_name ASC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Create Order</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; }</style>
</head>
<body class="h-screen flex overflow-hidden">
    
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 flex-1 flex flex-col h-screen overflow-hidden relative">
        <header class="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 flex-shrink-0">
            <h1 class="text-2xl font-bold text-[#1E3A1D]">Create B2B Order</h1>
            <div class="text-sm text-gray-500">Date: <?= date('M d, Y') ?></div>
        </header>

        <div class="flex-1 flex overflow-hidden">
            <div class="w-2/3 flex flex-col p-6 overflow-y-auto">
                <form method="GET" class="mb-6 relative">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400"><span class="material-icons">search</span></span>
                    <input type="text" name="search_query" class="w-full pl-10 p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-800 focus:outline-none shadow-sm" placeholder="Search products..." value="<?= htmlspecialchars($_GET['search_query'] ?? '') ?>" autocomplete="off" onchange="this.form.submit()">
                </form>

                <?php if (!empty($search_results)): ?>
                    <div class="grid grid-cols-3 gap-4">
                        <?php foreach ($search_results as $p): 
                            $stock = floatval($p['current_stock']);
                            $unit = htmlspecialchars($p['unit'] ?? 'pcs');
                            $hasStock = $stock > 0;
                            $stockClass = $hasStock ? 'text-green-600 bg-green-50 border-green-200' : 'text-red-600 bg-red-50 border-red-200';
                            $cardOpacity = $hasStock ? 'opacity-100' : 'opacity-75 grayscale-[0.5]';
                        ?>
                        <div onclick="<?= $hasStock ? 'addToCart('.htmlspecialchars(json_encode($p)).')' : 'alert(\'Item is out of stock!\')' ?>" 
                             class="relative bg-white p-4 rounded-lg shadow cursor-pointer hover:border-green-600 border border-transparent transition group <?= $cardOpacity ?>">
                            
                            <div class="absolute top-3 right-3 text-[10px] font-bold px-2 py-1 rounded border <?= $stockClass ?>">
                                Stock: <?= number_format($stock) ?> <?= $unit ?>
                            </div>

                            <div class="flex flex-col h-full justify-between">
                                <div>
                                    <h3 class="font-bold text-gray-800 pr-16"><?= htmlspecialchars($p['name']) ?></h3>
                                    <span class="text-xs text-gray-500 block mt-1"><?= htmlspecialchars($p['product_brand'] ?? 'Generic') ?></span>
                                </div>
                                <div class="mt-4 flex justify-between items-end">
                                    <span class="text-[#1E3A1D] font-mono font-bold">₱<?= number_format($p['price'], 2) ?></span>
                                    <button type="button" class="bg-gray-100 p-1 rounded-full text-green-700 group-hover:bg-green-700 group-hover:text-white transition">
                                        <span class="material-icons text-sm"><?= $hasStock ? 'add' : 'block' ?></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-gray-400 mt-10">
                        No products found. <br>
                        <a href="products.php" class="text-green-700 underline">Add products to inventory</a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="w-1/3 bg-white border-l border-gray-200 flex flex-col shadow-xl z-10">
                <form method="POST" id="orderForm" class="flex flex-col h-full">
                    <input type="hidden" name="action" value="submit_order">
                    <input type="hidden" name="cart_items" id="cart_items_input">
                    <input type="hidden" name="total_amount" id="total_amount_input">

                    <div class="p-6 bg-gray-50 border-b border-gray-200">
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Select Client</label>
                        <select name="client_id" required class="w-full p-3 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-green-800">
                            <option value="">-- Choose Client --</option>
                            <?php foreach ($clients as $c): ?>
                                <option value="<?= $c['client_id'] ?>"><?= htmlspecialchars($c['client_name']) ?></option>
                            <?php endforeach; ?>
                        </select>

                        <label class="block text-xs font-bold text-gray-500 uppercase mt-4 mb-1">Delivery Date</label>
                        <input type="date" name="delivery_date" required class="w-full p-3 border border-gray-300 rounded-lg bg-white" value="<?= date('Y-m-d') ?>">
                    </div>

                    <div class="flex-1 overflow-y-auto p-4 space-y-2" id="cart_container">
                        <div id="empty_cart_msg" class="text-center text-gray-400 text-sm italic mt-10">Order list is empty.</div>
                    </div>

                    <div class="p-6 bg-gray-50 border-t border-gray-200">
                        <div class="flex justify-between items-center mb-4">
                            <span class="text-gray-600 font-bold">Total</span>
                            <span class="text-3xl font-bold text-[#1E3A1D]" id="display_total">₱0.00</span>
                        </div>
                        <button type="submit" class="w-full bg-[#1E3A1D] hover:bg-[#2a4e29] text-white font-bold py-4 rounded-lg shadow-lg flex justify-center items-center gap-2 transition transform active:scale-95">
                            <span class="material-icons">check_circle</span> Submit Order
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let cart = [];

        function addToCart(product) {
            // JS check for initial add
            const maxStock = parseFloat(product.current_stock);
            
            if (maxStock <= 0) {
                alert("This item is out of stock!");
                return;
            }

            const existing = cart.find(item => item.id == product.product_id);
            const unitType = product.unit ? product.unit : 'pcs';
            
            if (existing) { 
                if (existing.qty + 1 > maxStock) {
                    alert(`Cannot add more. Max stock is ${maxStock}.`);
                    return;
                }
                existing.qty++; 
            } else { 
                cart.push({ 
                    id: product.product_id, 
                    name: product.name, 
                    price: parseFloat(product.price), 
                    unit: unitType,
                    qty: 1,
                    max_stock: maxStock // Store max stock for frontend validation
                }); 
            }
            renderCart();
        }

        function updateQty(id, change) {
            const item = cart.find(i => i.id == id);
            if (item) {
                const newQty = item.qty + change;
                
                // Prevent going above available stock
                if (newQty > item.max_stock) {
                    alert(`Cannot exceed available stock (${item.max_stock} ${item.unit}).`);
                    return;
                }

                item.qty = newQty;
                if (item.qty <= 0) cart = cart.filter(i => i.id != id);
            }
            renderCart();
        }

        function renderCart() {
            const container = document.getElementById('cart_container');
            const totalDisplay = document.getElementById('display_total');
            container.innerHTML = '';
            let total = 0;

            if (cart.length === 0) { container.innerHTML = '<div class="text-center text-gray-400 text-sm italic mt-10">Order list is empty.</div>'; } 
            else {
                cart.forEach(item => {
                    total += item.price * item.qty;
                    container.innerHTML += `
                        <div class="flex justify-between items-center bg-white p-3 rounded shadow-sm border border-gray-100">
                            <div>
                                <div class="font-bold text-sm text-gray-800">${item.name}</div>
                                <div class="text-xs text-gray-500">₱${item.price.toFixed(2)} / ${item.unit}</div>
                            </div>
                            <div class="flex items-center gap-2">
                                <button onclick="updateQty(${item.id}, -1)" type="button" class="text-gray-400 hover:text-red-500"><span class="material-icons text-base">remove_circle</span></button>
                                <span class="font-bold min-w-[30px] text-center text-sm">${item.qty} <span class="text-[10px] text-gray-400 font-normal">${item.unit}</span></span>
                                <button onclick="updateQty(${item.id}, 1)" type="button" class="text-gray-400 hover:text-green-600"><span class="material-icons text-base">add_circle</span></button>
                            </div>
                        </div>`;
                });
            }
            totalDisplay.textContent = '₱' + total.toLocaleString('en-US', {minimumFractionDigits: 2});
            document.getElementById('total_amount_input').value = total;
            document.getElementById('cart_items_input').value = JSON.stringify(cart);
        }
    </script>
</body>
</html>