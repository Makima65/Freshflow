<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\users.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once '../includes/db_connection.php';

// --- CONFIGURATION ---
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) include_once $auditHelperPath;
else if (!function_exists('log_audit_action')) { function log_audit_action($a, $b, $c, $d = []) { return true; } }

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || !isset($_SESSION["role_name"]) || $_SESSION["role_name"] !== 'admin') {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        http_response_code(403);
        echo json_encode(['error' => 'Authentication required.']);
        exit;
    }
    header("location: ../admin_login.php");
    exit;
}

// --- HANDLE REQUESTS ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    // 1. ADD / EDIT USER
    if ($action === 'save_user') {
        $user_id = !empty($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $username = trim($_POST['username']);
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $password = trim($_POST['password']);
        $role = $_POST['role'];
        $status = $_POST['status'];

        if (empty($username) || empty($first_name) || empty($last_name)) { 
            echo json_encode(['success' => false, 'message' => 'All fields are required.']); exit; 
        }

        // Duplicate Check
        $check = $conn->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
        $check->bind_param("si", $username, $user_id);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Username taken.']); exit;
        }

        if ($user_id > 0) {
            // UPDATE
            if (!empty($password)) {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET username=?, first_name=?, last_name=?, password=?, role=?, status=? WHERE user_id=?");
                $stmt->bind_param("ssssssi", $username, $first_name, $last_name, $hash, $role, $status, $user_id);
            } else {
                $stmt = $conn->prepare("UPDATE users SET username=?, first_name=?, last_name=?, role=?, status=? WHERE user_id=?");
                $stmt->bind_param("sssssi", $username, $first_name, $last_name, $role, $status, $user_id);
            }
            $stmt->execute();
            if(function_exists('log_audit_action')) log_audit_action('Update User', 'Users', "Updated user: $username ($status)");
            echo json_encode(['success' => true, 'message' => 'User updated successfully.']);
        } else {
            // INSERT
            if (empty($password)) { echo json_encode(['success' => false, 'message' => 'Password required.']); exit; }
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, first_name, last_name, password, role, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $username, $first_name, $last_name, $hash, $role, $status);
            $stmt->execute();
            if(function_exists('log_audit_action')) log_audit_action('Create User', 'Users', "Created user: $username");
            echo json_encode(['success' => true, 'message' => 'User created successfully.']);
        }
        exit;
    }
}

// --- FETCH USERS ---
$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - User Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-green: #1E3A1D; --brand-cream: #F8F5EE; }
        body { font-family: 'Inter', sans-serif; background-color: var(--brand-cream); color: #2B2B2B; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .content-card { background-color: #ffffff; border: 1px solid #e5e7eb; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .form-input { width: 100%; padding: 0.5rem; border: 1px solid #d1d5db; border-radius: 0.375rem; }
        .modal { transition: opacity 0.3s ease; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        .btn-primary { background-color: var(--brand-green); color: white; }
        .btn-primary:hover { background-color: #2a4e29; }
        .status-Active { background-color: #dcfce7; color: #166534; }
        .status-Inactive { background-color: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>

    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 transition-all duration-300">
        <main class="p-6 md:p-8">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="font-heading text-3xl font-bold text-[#1E3A1D]">System Users</h1>
                    <p class="text-sm text-gray-500">Manage admin and staff accounts</p>
                </div>
                <button onclick="openModal()" class="btn-primary font-bold py-2 px-6 rounded-lg flex items-center gap-2 shadow-lg hover:-translate-y-0.5 transition">
                    <span class="material-icons">person_add</span> <span>Add User</span>
                </button>
            </header>

            <div class="content-card">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-[#1E3A1D] text-white">
                            <tr>
                                <th class="p-4">User</th>
                                <th class="p-4">Role</th>
                                <th class="p-4">Status</th>
                                <th class="p-4">Last Login</th>
                                <th class="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-gray-700">
                            <?php foreach($users as $u): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-4">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-800 font-bold">
                                            <?= strtoupper(substr($u['first_name'] ?? 'U', 0, 1) . substr($u['last_name'] ?? 'U', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <p class="font-bold text-gray-900"><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name']) ?></p>
                                            <p class="text-xs text-gray-500">@<?= htmlspecialchars($u['username']) ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="p-4">
                                    <span class="px-2 py-1 rounded text-xs font-bold uppercase bg-gray-100 text-gray-600">
                                        <?= $u['role'] ?>
                                    </span>
                                </td>
                                <td class="p-4">
                                    <span class="px-2 py-1 rounded-full text-xs font-bold uppercase status-<?= $u['status'] ?>">
                                        <?= $u['status'] ?>
                                    </span>
                                </td>
                                <td class="p-4 text-sm text-gray-500">
                                    <?= $u['last_login'] ? date('M d, h:i A', strtotime($u['last_login'])) : 'Never' ?>
                                </td>
                                <td class="p-4 text-right">
                                    <button onclick='editUser(<?= json_encode($u) ?>)' class="text-blue-600 hover:text-blue-800 font-bold text-sm">Edit</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <div id="userModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 hidden backdrop-blur-sm">
        <div class="bg-white rounded-lg w-96 p-6 shadow-2xl">
            <h2 id="modalTitle" class="text-xl font-bold text-[#1E3A1D] mb-4">Add User</h2>
            <form id="userForm">
                <input type="hidden" name="action" value="save_user">
                <input type="hidden" name="user_id" id="user_id">
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">First Name</label>
                        <input type="text" name="first_name" id="first_name" class="form-input" required>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Last Name</label>
                        <input type="text" name="last_name" id="last_name" class="form-input" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Username</label>
                    <input type="text" name="username" id="username" class="form-input" required>
                </div>

                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Password</label>
                    <input type="password" name="password" id="password" class="form-input" placeholder="Leave blank if editing">
                </div>

                <div class="grid grid-cols-2 gap-4 mb-6">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Role</label>
                        <select name="role" id="role" class="form-input">
                            <option value="staff">Staff</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Status</label>
                        <select name="status" id="status" class="form-input">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeModal()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-[#1E3A1D] text-white rounded hover:opacity-90">Save</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('userModal');
        const form = document.getElementById('userForm');

        function openModal() { 
            form.reset(); 
            document.getElementById('user_id').value = ''; 
            document.getElementById('modalTitle').textContent = 'Add User';
            modal.classList.remove('hidden'); 
        }
        
        function closeModal() { modal.classList.add('hidden'); }

        window.editUser = (user) => {
            document.getElementById('user_id').value = user.user_id;
            document.getElementById('first_name').value = user.first_name;
            document.getElementById('last_name').value = user.last_name;
            document.getElementById('username').value = user.username;
            document.getElementById('role').value = user.role;
            document.getElementById('status').value = user.status;
            document.getElementById('password').value = ''; 
            document.getElementById('modalTitle').textContent = 'Edit User';
            modal.classList.remove('hidden');
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            try {
                const res = await fetch('', { method: 'POST', body: new FormData(form) });
                const data = await res.json();
                if(data.success) location.reload();
                else alert(data.message);
            } catch(e) { alert("Error saving user."); }
        });
    </script>
</body>
</html>