<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\dashboard.php

session_start();
ob_start();

// TEMPORARY: Enable error reporting to see specific issues instead of "500 Error"
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- DATABASE CONNECTION ---
include_once '../includes/db_connection.php';

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../admin_login.php");
    exit;
}

// --- CONFIGURATION ---
if (!defined('LOW_STOCK_THRESHOLD')) {
    define('LOW_STOCK_THRESHOLD', 10);
}

// Helper to safely fetch single row
function fetch_assoc_safe($conn, $sql) {
    $result = $conn->query($sql);
    if ($result) {
        return $result->fetch_assoc();
    }
    return []; 
}

// =================================================================================
//                       1. ORDER FULFILLMENT STATS (OPERATIONS)
// =================================================================================
$ops_query = "
    SELECT 
        SUM(CASE WHEN order_status = 'Pending' THEN 1 ELSE 0 END) as to_pack,
        SUM(CASE WHEN order_status = 'Packed' THEN 1 ELSE 0 END) as ready_to_dispatch,
        SUM(CASE WHEN order_status = 'Out for Delivery' THEN 1 ELSE 0 END) as on_route,
        SUM(CASE WHEN order_status = 'Completed' AND DATE(delivered_at) = CURDATE() THEN 1 ELSE 0 END) as delivered_today,
        -- Finance Stats
        SUM(CASE WHEN order_status = 'Completed' AND payment_status != 'Paid' AND payment_status != 'Cancelled' THEN (total_amount - amount_paid) ELSE 0 END) as total_collectibles,
        SUM(CASE WHEN order_status = 'Completed' AND MONTH(delivered_at) = MONTH(CURRENT_DATE()) AND YEAR(delivered_at) = YEAR(CURRENT_DATE()) THEN total_amount ELSE 0 END) as revenue_this_month
    FROM sales
    WHERE order_status != 'Cancelled'
";
$ops = fetch_assoc_safe($conn, $ops_query);

// Defaults if query failed
$to_pack = $ops['to_pack'] ?? 0;
$ready_to_dispatch = $ops['ready_to_dispatch'] ?? 0;
$on_route = $ops['on_route'] ?? 0;
$delivered_today = $ops['delivered_today'] ?? 0;
$total_collectibles = $ops['total_collectibles'] ?? 0;
$revenue_this_month = $ops['revenue_this_month'] ?? 0;

// =================================================================================
//                       2. INVENTORY HEALTH
// =================================================================================
// Check if expiration_date column exists to prevent crash on older DBs
$has_expiry = false;
$col_check = $conn->query("SHOW COLUMNS FROM products LIKE 'expiration_date'");
if($col_check && $col_check->num_rows > 0) { $has_expiry = true; }

// Build Query dynamically based on whether expiration exists
$expiry_logic_1 = $has_expiry ? "WHEN p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date < CURDATE() THEN 'Expired'" : "";
$expiry_logic_2 = $has_expiry ? "WHEN (p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AND (COALESCE(pi.quantity, 0) <= " . LOW_STOCK_THRESHOLD . ") THEN 'Expiring & Low Stock'" : "";
$expiry_logic_3 = $has_expiry ? "WHEN p.expiration_date IS NOT NULL AND p.expiration_date != '0000-00-00' AND p.expiration_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'Expiring Soon'" : "";

$stats_query = "
    SELECT 
        COUNT(*) as total_products,
        SUM(CASE WHEN status_bucket = 'Out of Stock' THEN 1 ELSE 0 END) as out_of_stock,
        SUM(CASE WHEN status_bucket = 'Expired' THEN 1 ELSE 0 END) as expired_count,
        SUM(CASE WHEN status_bucket = 'Expiring & Low Stock' THEN 1 ELSE 0 END) as expiring_low_stock,
        SUM(CASE WHEN status_bucket = 'Expiring Soon' THEN 1 ELSE 0 END) as expiring_soon,
        SUM(CASE WHEN status_bucket = 'Low Stock' THEN 1 ELSE 0 END) as low_stock,
        SUM(CASE WHEN status_bucket = 'Healthy' THEN 1 ELSE 0 END) as healthy_stock
    FROM (
        SELECT 
            CASE 
                WHEN COALESCE(pi.quantity, 0) <= 0 THEN 'Out of Stock'
                $expiry_logic_1
                $expiry_logic_2
                $expiry_logic_3
                WHEN COALESCE(pi.quantity, 0) <= " . LOW_STOCK_THRESHOLD . " THEN 'Low Stock'
                ELSE 'Healthy'
            END as status_bucket
        FROM products p
        LEFT JOIN product_inventory pi ON p.product_id = pi.product_id
        WHERE p.status != 'Archived'
    ) as calc_table
";
$inv_stats = fetch_assoc_safe($conn, $stats_query);

// JS Data for Inventory Chart
$stock_data = json_encode([
    $inv_stats['healthy_stock'] ?? 0, 
    $inv_stats['expiring_low_stock'] ?? 0, 
    $inv_stats['expiring_soon'] ?? 0, 
    $inv_stats['low_stock'] ?? 0, 
    $inv_stats['out_of_stock'] ?? 0, 
    $inv_stats['expired_count'] ?? 0
]);

// =================================================================================
//                       3. SALES CHART DATA (LAST 7 DAYS)
// =================================================================================
$dates = [];
$sales_data = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $dates[] = date('M d', strtotime($d));
    
    $sql = "SELECT SUM(total_amount) as daily_total FROM sales WHERE order_status = 'Completed' AND DATE(delivered_at) = '$d'";
    $res = $conn->query($sql);
    $sales_data[] = $res ? floatval($res->fetch_assoc()['daily_total'] ?? 0) : 0;
}
$chart_dates = json_encode($dates);
$chart_sales = json_encode($sales_data);

// =================================================================================
//                       4. RECENT ORDERS TABLE
// =================================================================================
$recent_orders = [];
// FIX: Changed 'created_at' to 'sale_date' to match your database structure
$ro_query = "SELECT s.*, c.client_name 
             FROM sales s 
             LEFT JOIN clients c ON s.client_id = c.client_id 
             ORDER BY s.sale_date DESC LIMIT 5";
$ro_res = $conn->query($ro_query);
if($ro_res) $recent_orders = $ro_res->fetch_all(MYSQLI_ASSOC);

?>

<?php include '../includes/sidebar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Command Center</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root { --brand-green: #1E3A1D; --brand-cream: #F8F5EE; --text-dark: #2B2B2B; }
        body { font-family: 'Inter', sans-serif; background-color: var(--brand-cream); color: var(--text-dark); }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .content-card { background-color: #ffffff; border: 1px solid #e5e7eb; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .content-card:hover { transform: translateY(-2px); box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05); transition: all 0.3s ease; }
        
        .status-badge { padding: 2px 8px; border-radius: 99px; font-size: 0.65rem; font-weight: 700; text-transform: uppercase; }
        .st-Pending { background: #fee2e2; color: #991b1b; }
        .st-Packed { background: #eff6ff; color: #1e40af; }
        .st-Out { background: #faf5ff; color: #6b21a8; }
        .st-Completed { background: #f0fdf4; color: #166534; }
        .st-Cancelled { background: #f3f4f6; color: #374151; text-decoration: line-through; }
    </style>
</head>
<body>
    
    <div class="ml-20 transition-all duration-300">
        <main class="p-6 md:p-8">
            <header class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <div>
                    <h1 class="font-heading text-3xl font-bold text-[#1E3A1D] mb-1">Dashboard</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="text-right hidden md:block">
                        <p class="text-xs text-gray-400 font-bold uppercase">Current Date</p>
                        <p class="text-sm font-bold text-[#1E3A1D]"><?= date('F d, Y') ?></p>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-[#1E3A1D] text-white flex items-center justify-center font-bold shadow-lg">
                        <?= htmlspecialchars(strtoupper(substr($_SESSION["username"] ?? 'A', 0, 1))) ?>
                    </div>
                </div>
            </header>

            <h2 class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Operations Pipeline</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <a href="order_queue.php" class="content-card p-5 border-l-4 border-orange-400 flex items-center justify-between cursor-pointer group">
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">Pending Orders</p>
                        <p class="font-heading text-3xl font-bold text-orange-600 mt-1 group-hover:scale-110 transition-transform origin-left"><?= $to_pack ?></p>
                        <p class="text-[10px] text-gray-400 mt-1">Needs Packing</p>
                    </div>
                    <div class="bg-orange-50 p-3 rounded-full text-orange-600"><span class="material-icons">inventory_2</span></div>
                </a>

                <a href="dispatch.php" class="content-card p-5 border-l-4 border-blue-500 flex items-center justify-between cursor-pointer group">
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">Ready to Ship</p>
                        <p class="font-heading text-3xl font-bold text-blue-600 mt-1 group-hover:scale-110 transition-transform origin-left"><?= $ready_to_dispatch ?></p>
                        <p class="text-[10px] text-gray-400 mt-1">Assign Driver</p>
                    </div>
                    <div class="bg-blue-50 p-3 rounded-full text-blue-600"><span class="material-icons">local_shipping</span></div>
                </a>

                <a href="dispatch.php" class="content-card p-5 border-l-4 border-purple-500 flex items-center justify-between cursor-pointer group">
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">On the Road</p>
                        <p class="font-heading text-3xl font-bold text-purple-600 mt-1 group-hover:scale-110 transition-transform origin-left"><?= $on_route ?></p>
                        <p class="text-[10px] text-gray-400 mt-1">Active Deliveries</p>
                    </div>
                    <div class="bg-purple-50 p-3 rounded-full text-purple-600"><span class="material-icons">near_me</span></div>
                </a>

                <div class="content-card p-5 border-l-4 border-green-600 flex items-center justify-between">
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">Completed Today</p>
                        <p class="font-heading text-3xl font-bold text-green-700 mt-1"><?= $delivered_today ?></p>
                        <p class="text-[10px] text-gray-400 mt-1">Successful Drops</p>
                    </div>
                    <div class="bg-green-50 p-3 rounded-full text-green-700"><span class="material-icons">check_circle</span></div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                
                <div class="lg:col-span-2 space-y-6">
                    <div class="grid grid-cols-2 gap-4">
                        <a href="invoices.php" class="content-card p-5 bg-gradient-to-br from-white to-red-50 border border-red-100 hover:border-red-300">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="text-xs font-bold text-red-400 uppercase tracking-wider">Unpaid Invoices</p>
                                    <h3 class="font-heading text-2xl font-bold text-red-700 mt-1">₱<?= number_format($total_collectibles, 2) ?></h3>
                                </div>
                                <span class="material-icons text-red-300">receipt_long</span>
                            </div>
                            <p class="text-[10px] text-red-400 mt-2 font-medium">Total Collectibles</p>
                        </a>
                        <div class="content-card p-5 bg-gradient-to-br from-white to-green-50 border border-green-100">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="text-xs font-bold text-green-600 uppercase tracking-wider">Monthly Revenue</p>
                                    <h3 class="font-heading text-2xl font-bold text-[#1E3A1D] mt-1">₱<?= number_format($revenue_this_month, 2) ?></h3>
                                </div>
                                <span class="material-icons text-green-300">trending_up</span>
                            </div>
                            <p class="text-[10px] text-green-600 mt-2 font-medium">Total Sales (<?= date('M') ?>)</p>
                        </div>
                    </div>

                    <div class="content-card p-6">
                        <h2 class="font-bold text-gray-700 mb-4 flex items-center gap-2"><span class="material-icons text-sm">bar_chart</span> Daily Sales Revenue</h2>
                        <div class="relative h-64 w-full"><canvas id="salesChart"></canvas></div>
                    </div>
                </div>

                <div class="content-card p-6 flex flex-col">
                    <h2 class="font-bold text-gray-700 mb-4 flex items-center gap-2"><span class="material-icons text-sm">health_and_safety</span> Inventory Health</h2>
                    <div class="relative h-48 w-full flex justify-center mb-4"><canvas id="stockChart"></canvas></div>
                    
                    <div class="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
                        <?php 
                        $alerts = [
                            ['label' => 'Out of Stock', 'count' => $inv_stats['out_of_stock'] ?? 0, 'color' => 'bg-red-600', 'text' => 'text-red-700'],
                            ['label' => 'Expired', 'count' => $inv_stats['expired_count'] ?? 0, 'color' => 'bg-purple-600', 'text' => 'text-purple-700'],
                            ['label' => 'Critial (Low & Exp)', 'count' => $inv_stats['expiring_low_stock'] ?? 0, 'color' => 'bg-orange-600', 'text' => 'text-orange-700'],
                            ['label' => 'Low Stock', 'count' => $inv_stats['low_stock'] ?? 0, 'color' => 'bg-yellow-500', 'text' => 'text-yellow-700'],
                        ];
                        foreach($alerts as $a): 
                            if($a['count'] > 0):
                        ?>
                        <div class="flex justify-between items-center p-2 rounded bg-gray-50 border border-gray-100">
                            <div class="flex items-center gap-2">
                                <span class="w-2 h-2 rounded-full <?= $a['color'] ?>"></span>
                                <span class="text-xs font-medium text-gray-600"><?= $a['label'] ?></span>
                            </div>
                            <span class="text-sm font-bold <?= $a['text'] ?>"><?= $a['count'] ?></span>
                        </div>
                        <?php endif; endforeach; ?>
                        
                        <div class="flex justify-between items-center p-2 rounded bg-green-50 border border-green-100">
                            <div class="flex items-center gap-2">
                                <span class="w-2 h-2 rounded-full bg-[#1E3A1D]"></span>
                                <span class="text-xs font-medium text-gray-600">Healthy Stock</span>
                            </div>
                            <span class="text-sm font-bold text-[#1E3A1D]"><?= $inv_stats['healthy_stock'] ?? 0 ?></span>
                        </div>
                    </div>
                    <a href="inventory.php" class="mt-4 text-center text-xs font-bold text-[#1E3A1D] hover:underline">Manage Inventory →</a>
                </div>
            </div>

            <div class="content-card overflow-hidden">
                <div class="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                    <h3 class="font-bold text-gray-700 text-sm uppercase tracking-wide">Latest Orders</h3>
                    <a href="order_queue.php" class="text-xs font-bold text-blue-600 hover:text-blue-800">View Queue</a>
                </div>
                <table class="w-full text-left">
                    <tbody class="divide-y divide-gray-100 text-sm">
                        <?php if (empty($recent_orders)): ?>
                            <tr><td class="p-4 text-center text-gray-400 italic">No orders yet.</td></tr>
                        <?php else: ?>
                            <?php foreach($recent_orders as $o): 
                                $statusClass = 'st-' . str_replace(' ', '', $o['order_status']);
                                // Fallback for long status names like 'Out for Delivery' -> 'st-Out' logic handled roughly by css or manual fix
                                if($o['order_status'] == 'Out for Delivery') $statusClass = 'st-Out';
                            ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-3 pl-5 font-mono font-bold text-[#1E3A1D] text-xs">#<?= str_pad($o['sale_id'], 5, '0', STR_PAD_LEFT) ?></td>
                                <td class="p-3 font-medium text-gray-700"><?= htmlspecialchars($o['client_name'] ?? 'Unknown') ?></td>
                                <td class="p-3 text-gray-500 text-xs"><?= date('M d, h:i A', strtotime($o['sale_date'])) ?></td>
                                <td class="p-3 text-right font-bold text-gray-700">₱<?= number_format($o['total_amount'], 2) ?></td>
                                <td class="p-3 text-right">
                                    <span class="status-badge <?= $statusClass ?>"><?= $o['order_status'] ?></span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

    <script>
        Chart.defaults.font.family = "'Inter', sans-serif";
        
        // --- SALES CHART ---
        const ctxSales = document.getElementById('salesChart').getContext('2d');
        const gradient = ctxSales.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(30, 58, 29, 0.1)');
        gradient.addColorStop(1, 'rgba(30, 58, 29, 0)');

        new Chart(ctxSales, {
            type: 'line',
            data: {
                labels: <?= $chart_dates ?>,
                datasets: [{
                    label: 'Revenue (₱)',
                    data: <?= $chart_sales ?>,
                    borderColor: '#1E3A1D',
                    backgroundColor: gradient,
                    borderWidth: 2,
                    pointBackgroundColor: '#1E3A1D',
                    pointRadius: 3,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { borderDash: [2, 4] } },
                    x: { grid: { display: false } }
                }
            }
        });

        // --- INVENTORY CHART ---
        const ctxStock = document.getElementById('stockChart').getContext('2d');
        new Chart(ctxStock, {
            type: 'doughnut',
            data: {
                labels: ['Healthy', 'Critical', 'Expiring', 'Low', 'Out', 'Expired'],
                datasets: [{
                    data: <?= $stock_data ?>,
                    backgroundColor: ['#1E3A1D', '#ea580c', '#f97316', '#eab308', '#dc2626', '#9333ea'],
                    borderWidth: 0,
                    hoverOffset: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: { legend: { display: false } }
            }
        });
    </script>
</body>
</html>