<?php
// update_return_status.php

// --- DEBUGGING ---
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- SECURITY AND DATABASE CONNECTION ---
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include_once '../../includes/db_connection.php';

// --- AUDIT LOGGING HELPER INCLUSION (New) ---
// This is the correct path: .../admin_components/includes/
$auditHelperPath = '../includes/audit_helper.php'; 
if (file_exists($auditHelperPath)) {
    include_once $auditHelperPath;
} else {
    // This will write to your server's error log if the file is missing
    error_log("CRITICAL: audit_helper.php not found at: " . $auditHelperPath);
}

header('Content-Type: application/json');

// --- Security Check (Admin Only) ---
$is_admin = isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && isset($_SESSION["role_name"]) && $_SESSION["role_name"] === 'admin';
if (!$is_admin) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Forbidden: Admin access required.']);
    exit;
}
$admin_user_id = $_SESSION["user_id"] ?? 0;

// --- SESSION PREP FOR AUDIT LOG (New) ---
// This is required by audit_helper.php to know which admin is acting
$admin_user_name = ($_SESSION["first_name"] ?? '') . " " . ($_SESSION["last_name"] ?? '');
if (trim($admin_user_name) === "") {
    $admin_user_name = $_SESSION["username"] ?? 'Unknown Admin';
}
// Ensure the specific session key 'username' expected by audit_helper.php is set
if (!isset($_SESSION['username']) || empty($_SESSION['username']) || $_SESSION['username'] === 'SYSTEM') {
    $temp_username = trim($admin_user_name);
    if ($temp_username !== 'Unknown Admin') {
        $_SESSION['username'] = $temp_username; // Set it for log_audit_action
    }
}
// --- END SESSION PREP ---


// --- Stripe Configuration ---
// Assuming stripe-php is located in the root directory: /stripe-php/init.php
$stripe_lib_path = __DIR__ . '/../../stripe-php/init.php'; 
if (file_exists($stripe_lib_path)) {
    require_once $stripe_lib_path;
    // NOTE: This secret key should be stored securely, e.g., in an environment variable.
    $stripeSecretKey = 'sk_test_51SDRD2KLsgahIll1V81w8mkMxJxuE2ar0GWiSqtbmpBvSHjJvKbWzS2InQV1qiiPwpZ7BH0WAfdS6LbsW8RQ7B5w00L3kJQOSe';

    try {
        if (class_exists('\Stripe\Stripe')) { 
            \Stripe\Stripe::setApiKey($stripeSecretKey);
        } else {
             error_log("CRITICAL: Stripe classes not loaded after requiring init.php.");
        }
    } catch (\Exception $e) {
        error_log("Stripe API key configuration error: " . $e->getMessage());
    }
} else {
    error_log('CRITICAL: Stripe PHP library not found at expected path: ' . $stripe_lib_path);
}

// --- Stripe Refund Helper Function ---
function processStripeRefund($paymentIntentId, $amount_php) {
    // Stripe amounts are in the smallest currency unit (cents).
    // The amount in PHP (base unit) is converted by multiplying by 100.
    $amount_cents = (int)round($amount_php * 100);

    if (empty($paymentIntentId) || $amount_cents <= 0) {
        return ['success' => false, 'message' => 'Invalid payment intent or refund amount.'];
    }

    try {
        if (!class_exists('\Stripe\Refund')) {
            return ['success' => false, 'message' => 'Stripe library is not initialized properly.'];
        }
        
        $refund = \Stripe\Refund::create([
            'payment_intent' => $paymentIntentId,
            'amount' => $amount_cents, // Partial or full refund amount
        ]);

        if ($refund->status === 'succeeded' || $refund->status === 'pending') {
            return ['success' => true, 'message' => 'Stripe refund initiated successfully (Refund ID: ' . $refund->id . ').'];
        } else {
            return ['success' => false, 'message' => 'Stripe refund failed with status: ' . $refund->status];
        }

    } catch (\Stripe\Exception\InvalidRequestException $e) {
        error_log("Stripe Refund Invalid Request Error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Stripe API Error: ' . $e->getMessage()];
    } catch (\Exception $e) {
        error_log("Stripe Refund General Error: " . $e->getMessage());
        return ['success' => false, 'message' => 'An unexpected error occurred during Stripe processing.'];
    }
}


// --- Brevo Email Helper Function (from auth_handler.php) ---
function sendEmailViaBrevo($email_data) {
    $brevo_api_key = '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';

    $ch = curl_init(); // This line causes a fatal error if cURL is not installed
    curl_setopt($ch, CURLOPT_URL, 'https://api.brevo.com/v3/smtp/email');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($email_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'api-key: ' . $brevo_api_key,
        'content-type: application/json'
    ]);
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $http_code >= 200 && $http_code < 300;
}

// --- Main Logic ---
$response = ['success' => false, 'message' => 'An unknown error occurred.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- Input Validation ---
    $returnId = filter_input(INPUT_POST, 'return_id', FILTER_VALIDATE_INT);
    $refundAmount = filter_input(INPUT_POST, 'refund_amount', FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    if ($refundAmount === false || $refundAmount < 0) $refundAmount = 0.00;

    $adminNotes = isset($_POST['admin_notes']) ? trim($_POST['admin_notes']) : null;
    $returnStatus = isset($_POST['return_status']) ? trim($_POST['return_status']) : '';

    $allowed_statuses = ['Requested', 'Approved', 'Rejected', 'Received', 'Refunded'];
    if (!$returnId || !in_array($returnStatus, $allowed_statuses)) {
        $response['message'] = 'Invalid data provided. Please check the fields and try again.';
        echo json_encode($response);
        exit;
    }

    // --- START: Stripe Refund Processing (Pre-DB Update) ---
    // We set $stripe_message to capture any output from this block
    $stripe_message = '';
    if ($returnStatus === 'Refunded') {
        // 1. Get the order's payment details
        $payment_query = $conn->prepare("
            SELECT o.transaction_id, o.payment_method
            FROM orders o
            JOIN order_returns r ON o.order_id = r.order_id
            WHERE r.return_id = ?
        ");
        $payment_query->bind_param("i", $returnId);
        $payment_query->execute();
        $payment_details = $payment_query->get_result()->fetch_assoc();
        $payment_query->close();

        $is_stripe_refund_needed = false;
        $transactionId = $payment_details['transaction_id'] ?? null;
        $paymentMethod = $payment_details['payment_method'] ?? null;

        // Check if Stripe is initialized and if it was a Card payment with a transaction ID
        if ($paymentMethod === 'Card' && !empty($transactionId) && class_exists('\Stripe\Stripe')) {
            $is_stripe_refund_needed = true;
        }

        if ($is_stripe_refund_needed) {
            // Initiate Stripe Refund
            $stripe_result = processStripeRefund($transactionId, $refundAmount);

            if (!$stripe_result['success']) {
                // Stripe refund failed, stop the process and inform admin
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Stripe Refund Failed: ' . $stripe_result['message'] . ' Database not updated.']);
                exit;
            }
            // Success: append Stripe message to the final response message
            $stripe_message = $stripe_result['message'];

        } else if ($paymentMethod === 'Card' && empty($transactionId)) {
            // Card payment but no transaction ID - issue warning but proceed if admin confirms manual refund
            $stripe_message = ' WARNING: Card payment detected but Stripe Transaction ID is missing. Assuming manual off-platform refund. ';
        } else if ($paymentMethod === 'COD') {
            // Cash on Delivery - no Stripe action needed
            $stripe_message = ' Note: This is a COD order; no external payment gateway refund required. ';
        } else {
            // Unknown payment method or Stripe library missing
            $stripe_message = ' WARNING: Payment method is unknown (' . htmlspecialchars($paymentMethod) . '). No external refund processed. ';
        }
    }
    // --- END: Stripe Refund Processing ---


    // --- Database Operation ---
    // If we reached here, either status is not 'Refunded', it was COD, or Stripe refund succeeded.
    $stmt = $conn->prepare("
        UPDATE order_returns
        SET
            refund_amount = ?,
            admin_notes = ?,
            return_status = ?,
            processed_by = ?,
            processed_date = NOW()
        WHERE return_id = ?
    ");

    $stmt->bind_param("dssii", $refundAmount, $adminNotes, $returnStatus, $admin_user_id, $returnId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $response['success'] = true;
            
            // --- FIX for Message Bug ---
            // Start with the success message
            $final_message = 'Return request updated successfully.';
            // Append the Stripe message ONLY if it's not empty
            if (!empty($stripe_message)) {
                $final_message .= ' ' . $stripe_message;
            }
            $response['message'] = $final_message; // This overwrites the default "An unknown error occurred."
            // --- END FIX ---

            // --- AUDITING FUNCTION CALL (New) ---
            // This now runs *only* if the include_once was successful and function exists
            if (function_exists('log_audit_action')) {
                
                $order_id_for_log = 0;
                // This query is safe and necessary for the log
                $audit_order_query = $conn->prepare("SELECT order_id FROM order_returns WHERE return_id = ?");
                $audit_order_query->bind_param("i", $returnId);
                if ($audit_order_query->execute()) {
                    $audit_result = $audit_order_query->get_result()->fetch_assoc();
                    $order_id_for_log = $audit_result['order_id'] ?? 0;
                }
                $audit_order_query->close();

                
                $log_action = "Updated Return Status";
                $log_category = "Return Management";
                
                // Create a detailed description for the log
                $log_details = sprintf(
                    "Admin (ID: %d) updated return request (ID: %d) to status: '%s'. Order ID: %d.",
                    $admin_user_id,
                    $returnId,
                    $returnStatus,
                    $order_id_for_log // Use the correctly fetched Order ID
                );
                
                // Add refund info if applicable
                if ($returnStatus === 'Refunded' && $refundAmount > 0) {
                    $log_details .= sprintf(" Refund Amount: ₱%.2f.", $refundAmount);
                }
                
                // Add admin notes if they were provided
                if (!empty($adminNotes)) {
                    // Sanitize notes slightly for logging (e.g., limit length)
                    $log_notes = (strlen($adminNotes) > 150) ? substr($adminNotes, 0, 147) . '...' : $adminNotes;
                    $log_details .= " Admin Notes: '" . $log_notes . "'";
                }

                // Log the action (use array() for PHP 7.2 compatible empty array)
                log_audit_action($log_action, $log_category, $log_details, array());
            }
            // --- END AUDIT CALL ---


            // --- START: EXPANDED EMAIL NOTIFICATION LOGIC ---
            $email_trigger_statuses = ['Approved', 'Refunded', 'Rejected', 'Received'];

            if (in_array($returnStatus, $email_trigger_statuses)) {

                // --- FIX for New Users ---
                // Get customer email, name, AND username
                $email_query = $conn->prepare("SELECT u.email, u.first_name, u.username, r.order_id FROM order_returns r JOIN users u ON r.user_id = u.user_id WHERE r.return_id = ?");
                $email_query->bind_param("i", $returnId);
                $email_query->execute();
                $customer = $email_query->get_result()->fetch_assoc();
                $email_query->close();

                if ($customer) {
                    $subject = '';
                    $body = '';
                    
                    // --- FIX for New Users: Fallback to username ---
                    $customerName = trim($customer['first_name']);
                    if (empty($customerName)) {
                        $customerName = $customer['username']; // Fallback to username
                    }
                    $customerName = htmlspecialchars($customerName);
                    // --- END FIX ---

                    $orderId = $customer['order_id'];
                    // !! IMPORTANT: Change this URL to your actual store's URL
                    $storeUrl = "https://autoporma.com/"; // e.g., https://autoporma.com

                    // --- Base Email Template ---
                    $emailTemplate = '
                    <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <style>
                            body { margin: 0; padding: 0; font-family: Arial, sans-serif; line-height: 1.6; background-color: #f4f4f4; }
                            .container { width: 90%; max-width: 600px; margin: 20px auto; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; background-color: #ffffff; }
                            .header { background-color: #a91d2d; color: #ffffff; padding: 20px; text-align: center; }
                            .header h1 { margin: 0; font-size: 24px; }
                            .content { padding: 30px; }
                            .content p { margin-bottom: 20px; color: #333; }
                            .highlight-box {
                                border: 2px dashed #a91d2d;
                                border-radius: 8px;
                                padding: 20px;
                                text-align: center;
                                margin-top: 20px;
                                margin-bottom: 20px;
                            }
                            .highlight-box h2 { margin: 0 0 10px 0; font-size: 20px; color: #333; }
                            .highlight-box p { margin: 0; font-size: 16px; }
                            .highlight-box .amount { font-size: 32px; font-weight: bold; color: #333; margin-top: 10px; }
                            .highlight-box .reason { font-size: 16px; color: #333; font-style: italic; margin-top: 10px; }
                            .footer-note { text-align: center; font-size: 12px; color: #777; margin-top: 20px; }
                            .button-container { text-align: center; margin-top: 30px; }
                            .button {
                                background-color: #a91d2d;
                                color: #ffffff !important; /* Force color */
                                padding: 12px 25px;
                                text-decoration: none;
                                border-radius: 5px;
                                font-weight: bold;
                                display: inline-block;
                            }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <div class="header">
                                <h1>{HEADER_TEXT}</h1>
                            </div>
                            <div class="content">
                                <p>Hi {CUSTOMER_NAME},</p>
                                <p>{INTRO_TEXT}</p>
                                
                                <div class="highlight-box">
                                    {BOX_CONTENT}
                                </div>

                                <p>{CLOSING_TEXT}</p>

                                <div class="button-container">
                                    <a href="{BUTTON_URL}" class="button">{BUTTON_TEXT}</a>
                                </div>

                                <p style="margin-top: 30px;">Sincerely,<br>The AUTOPORMA Team</p>
                            </div>
                        </div>
                    </body>
                    </html>';
                    // --- End Base Email Template ---


                    switch ($returnStatus) {
                        case 'Approved':
                            $subject = "Your Return Request for AUTOPORMA Order #$orderId has been Approved";
                            $body = str_replace(
                                ['{HEADER_TEXT}', '{CUSTOMER_NAME}', '{INTRO_TEXT}', '{BOX_CONTENT}', '{CLOSING_TEXT}', '{BUTTON_URL}', '{BUTTON_TEXT}'],
                                [
                                    "Return Request Approved",
                                    $customerName,
                                    "Good news! Your return request for Order #$orderId has been approved.",
                                    "<h2>Next Steps</h2><p>Please prepare the item for shipment. You can find our return address and shipping instructions on our website.</p>",
                                    "Once we receive the returned item, we will inspect it and process your refund. You will receive another email confirmation once the item is received.",
                                    "$storeUrl/return-policy", // Change this link
                                    "View Return Guidelines"
                                ],
                                $emailTemplate
                            );
                            break;

                        case 'Refunded':
                            if ($refundAmount > 0) {
                                $subject = "Your Refund for AUTOPORMA Order #$orderId has been Processed";
                                
                                // Customize message based on Stripe result/payment method
                                $closing_message = "The amount should appear in your original payment method's account within 5-10 business days.";
                                if (isset($is_stripe_refund_needed) && $is_stripe_refund_needed && isset($stripe_result['message'])) {
                                    $closing_message = $stripe_result['message'] . ' The amount should appear in your original payment method\'s account within 5-10 business days.';
                                } else if (isset($paymentMethod) && $paymentMethod === 'COD') {
                                    $closing_message = "Your refund has been processed manually (COD). Please check your preferred refund method (e.g., bank transfer, e-wallet) within 5-10 business days.";
                                }


                                $body = str_replace(
                                    ['{HEADER_TEXT}', '{CUSTOMER_NAME}', '{INTRO_TEXT}', '{BOX_CONTENT}', '{CLOSING_TEXT}', '{BUTTON_URL}', '{BUTTON_TEXT}'],
                                    [
                                        "Your Refund Has Been Processed",
                                        $customerName,
                                        "We have successfully processed your refund for your return from Order #$orderId.",
                                        '<h2>Refund Amount</h2><p class="amount">₱' . number_format($refundAmount, 2) . '</p>',
                                        $closing_message,
                                        "$storeUrl/products", // Change this link
                                        "Shop New Arrivals"
                                    ],
                                    $emailTemplate
                                );
                            }
                            break;

                        case 'Rejected':
                            $subject = "An Update on Your Return Request for Order #$orderId";
                            $reason_text = !empty($adminNotes) ? htmlspecialchars($adminNotes) : "Please contact our support team for more details.";
                            $body = str_replace(
                                ['{HEADER_TEXT}', '{CUSTOMER_NAME}', '{INTRO_TEXT}', '{BOX_CONTENT}', '{CLOSING_TEXT}', '{BUTTON_URL}', '{BUTTON_TEXT}'],
                                [
                                    "Return Request Update",
                                    $customerName,
                                    "We are writing to provide an update on your return request for Order #$orderId. After a review, we were unable to approve your request at this time.",
                                    '<h2>Reason</h2><p class="reason">"' . $reason_text . '"</p>',
                                    "If you have any questions, please feel free to reply to this email or contact our support team.",
                                    "$storeUrl/contact-us", // Change this link
                                    "Contact Support"
                                ],
                                $emailTemplate
                            );
                            break;

                        case 'Received':
                            $subject = "We've Received Your Returned Item for Order #$orderId";
                            $body = str_replace(
                                ['{HEADER_TEXT}', '{CUSTOMER_NAME}', '{INTRO_TEXT}', '{BOX_CONTENT}', '{CLOSING_TEXT}', '{BUTTON_URL}', '{BUTTON_TEXT}'],
                                [
                                    "Your Return Has Been Received",
                                    $customerName,
                                    "This is a confirmation that we have successfully received the returned item from your Order #$orderId.",
                                    "<h2>Current Status</h2><p>Our team will now inspect the item. Once the inspection is complete, we will process your refund and send a final confirmation email.</p>",
                                    "You can track the status of your return by logging into your account.",
                                    "$storeUrl/user_profile#orders", // Change this link
                                    "View My Orders"
                                ],
                                $emailTemplate
                            );
                            break;
                    }

                    if (!empty($subject) && !empty($body)) {
                        $email_data = [
                            'sender' => ['name' => 'AUTOPORMA Support', 'email' => 'autoporma76@gmail.com'],
                            'to' => [['email' => $customer['email'], 'name' => $customerName]], // $customerName is now fixed
                            'subject' => $subject,
                            'htmlContent' => $body
                        ];

                        // --- Keep this check for safety ---
                        // Check if cURL is available before trying to send email
                        if (function_exists('curl_init')) {
                            if (sendEmailViaBrevo($email_data)) {
                                $response['message'] .= ' A notification email has been sent to the customer.';
                            } else {
                                $response['message'] .= ' However, the notification email could not be sent.';
                            }
                        } else {
                            // cURL is not enabled, log this error and inform admin in the response
                            error_log("FATAL: cURL extension not enabled. Cannot send Brevo email.");
                            $response['message'] .= ' [Email not sent: cURL is not enabled on server]';
                        }
                        // --- END CHECK ---
                    }
                }
            }
            // --- END: EXPANDED EMAIL NOTIFICATION LOGIC ---

        } else {
            $response['success'] = true;
            $response['message'] = 'No changes detected for this return request.' . ($response['message'] ?? '');
        }
    } else {
        $response['message'] = 'Database update failed: ' . $stmt->error;
    }

    $stmt->close();
} else {
    $response['message'] = 'Invalid request method.';
}

$conn->close();
echo json_encode($response);
?>