<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\audit_logs.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once '../includes/db_connection.php';

// --- CONFIGURATION ---
// Set Timezone to Philippines
date_default_timezone_set('Asia/Manila');
if ($conn) $conn->query("SET time_zone = '+08:00'");

// --- SECURITY: ADMIN ONLY ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role_name"] !== 'admin') {
    header("location: ../admin_login.php");
    exit;
}

// --- PAGINATION & FILTERS ---
$perPage = 20;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$search = trim($_GET['search'] ?? '');
$user_filter = intval($_GET['user_id'] ?? 0);
$action_filter = trim($_GET['action_type'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

// Role Filter (Tabs)
$role_filter = trim($_GET['role_type'] ?? 'admin');
if (!in_array($role_filter, ['admin', 'staff'])) {
    $role_filter = 'admin';
}

// Count Active Filters for Badge
$active_filter_count = 0;
if ($user_filter > 0) $active_filter_count++;
if ($action_filter !== '') $active_filter_count++;
if ($date_from !== '') $active_filter_count++;
if ($date_to !== '') $active_filter_count++;

// --- BUILD QUERY ---
$where = [];
$params = [];
$types = '';

// Base Join
$from_sql = "FROM audit_trail a LEFT JOIN users u ON a.user_id = u.user_id";

// 1. Role Filter
$where[] = "u.role = ?"; // FreshFlow uses 'role'
$params[] = $role_filter;
$types .= "s";

// 2. Other Filters
if ($search !== '') {
    $where[] = "(a.username LIKE ? OR a.details LIKE ? OR a.action_type LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types .= "sss";
}
if ($user_filter > 0) {
    $where[] = "a.user_id = ?";
    $params[] = $user_filter;
    $types .= "i";
}
if ($action_filter !== '') {
    $where[] = "a.action_type = ?";
    $params[] = $action_filter;
    $types .= "s";
}
if ($date_from !== '') {
    $where[] = "a.log_time >= ?";
    $params[] = $date_from . " 00:00:00";
    $types .= "s";
}
if ($date_to !== '') {
    $where[] = "a.log_time <= ?";
    $params[] = $date_to . " 23:59:59";
    $types .= "s";
}

$where_sql = "WHERE " . implode(" AND ", $where);

// --- EXECUTE QUERIES ---

// 1. Total Count
$count_sql = "SELECT COUNT(*) as total $from_sql $where_sql";
$stmt = $conn->prepare($count_sql);
if (!empty($types)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalRows = $stmt->get_result()->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalRows / $perPage));
$stmt->close();

// 2. Fetch Data
$sql = "SELECT a.* $from_sql $where_sql ORDER BY a.log_time DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$params[] = $perPage;
$params[] = $offset;
$types .= "ii";
$stmt->bind_param($types, ...$params);
$stmt->execute();
$logs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// 3. Stats (All Time)
$stats_total = $conn->query("SELECT COUNT(*) as c FROM audit_trail")->fetch_assoc()['c'];
$stats_today = $conn->query("SELECT COUNT(*) as c FROM audit_trail WHERE DATE(log_time) = CURDATE()")->fetch_assoc()['c'];
// Count only users who actually exist and are Active
$stats_users = $conn->query("SELECT COUNT(*) as c FROM users WHERE status = 'Active'")->fetch_assoc()['c'];
$action_types = $conn->query("SELECT DISTINCT action_type FROM audit_trail ORDER BY action_type ASC")->fetch_all(MYSQLI_ASSOC);

// Helper for Metadata
function pretty_meta($json) {
    if (empty($json) || $json === 'null') return '';
    return htmlspecialchars($json, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFlow - Audit Trail</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-green: #1E3A1D; --brand-cream: #F8F5EE; }
        body { font-family: 'Inter', sans-serif; background-color: var(--brand-cream); color: #2B2B2B; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .content-card { background-color: #ffffff; border: 1px solid #e5e7eb; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        
        /* Tabs */
        .tab-link { padding: 0.75rem 1.5rem; font-weight: 600; color: #9ca3af; border-bottom: 2px solid transparent; transition: all 0.2s; position: relative; z-index: 10; }
        .tab-link:hover { color: #4b5563; }
        .tab-link.active { color: #1E3A1D; }
        #tab-slider { position: absolute; bottom: 0; height: 2px; background-color: #1E3A1D; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }

        /* Badges */
        .badge { padding: 2px 8px; border-radius: 999px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; }
        .badge-Login { background: #dbeafe; color: #1e40af; }
        .badge-Create { background: #dcfce7; color: #166534; }
        .badge-Update { background: #fef9c3; color: #854d0e; }
        .badge-Delete { background: #fee2e2; color: #991b1b; }
        .badge-Spoilage { background: #ffedd5; color: #9a3412; }

        /* Modal */
        .modal { transition: opacity 0.3s ease; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        
        #filterOptions { transition: max-height 0.3s ease-out, opacity 0.3s ease-out; }
    </style>
</head>
<body>

    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 transition-all duration-300">
        <main class="p-6 md:p-8">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="font-heading text-3xl font-bold text-[#1E3A1D]">Audit Trail</h1>
                    <p class="text-sm text-gray-500">Secure log of all system activities</p>
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="content-card p-6 border-l-4 border-green-600">
                    <p class="text-xs font-bold text-gray-400 uppercase">Total Actions</p>
                    <p class="font-heading text-3xl font-bold text-[#1E3A1D]"><?= number_format($stats_total) ?></p>
                </div>
                <div class="content-card p-6 border-l-4 border-blue-500">
                    <p class="text-xs font-bold text-gray-400 uppercase">Active Users</p>
                    <p class="font-heading text-3xl font-bold text-blue-700"><?= number_format($stats_users) ?></p>
                </div>
                <div class="content-card p-6 border-l-4 border-orange-500">
                    <p class="text-xs font-bold text-gray-400 uppercase">Logs Today</p>
                    <p class="font-heading text-3xl font-bold text-orange-700"><?= number_format($stats_today) ?></p>
                </div>
            </div>

            <div class="content-card p-4 mb-6 relative z-10">
                <form method="GET" id="filterForm">
                    <input type="hidden" name="page" value="1">
                    <input type="hidden" name="role_type" value="<?= htmlspecialchars($role_filter) ?>">

                    <div class="flex flex-col md:flex-row items-center gap-4 mb-4">
                        <div class="relative flex border-b border-gray-200" id="tab-nav-container">
                            <a href="?role_type=admin" class="tab-link <?= $role_filter === 'admin' ? 'active' : '' ?>">Admin Logs</a>
                            <a href="?role_type=staff" class="tab-link <?= $role_filter === 'staff' ? 'active' : '' ?>">Staff Logs</a>
                            <div id="tab-slider"></div>
                        </div>

                        <div class="flex-grow"></div>

                        <div class="relative w-64">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400"><span class="material-icons text-sm">search</span></span>
                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search..." class="w-full pl-9 p-2 border rounded-lg text-sm focus:outline-none focus:border-[#1E3A1D]">
                        </div>

                        <button type="button" id="toggleFilterBtn" class="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2 px-4 rounded-lg flex items-center gap-2 text-sm transition">
                            <span class="material-icons text-sm">filter_list</span> Filters
                            <?php if($active_filter_count > 0): ?>
                                <span class="bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center"><?= $active_filter_count ?></span>
                            <?php endif; ?>
                        </button>
                    </div>

                    <div id="filterOptions" style="max-height: <?= $active_filter_count > 0 ? '500px' : '0px' ?>; opacity: <?= $active_filter_count > 0 ? '1' : '0' ?>; overflow: hidden;">
                        <div class="border-t border-gray-200 pt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-gray-500 mb-1">User ID</label>
                                <input type="number" name="user_id" value="<?= $user_filter > 0 ? $user_filter : '' ?>" class="w-full p-2 border rounded-lg text-sm">
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-500 mb-1">Action Type</label>
                                <select name="action_type" class="w-full p-2 border rounded-lg text-sm bg-white">
                                    <option value="">All Actions</option>
                                    <?php foreach ($action_types as $t): ?>
                                        <option value="<?= $t['action_type'] ?>" <?= $action_filter === $t['action_type'] ? 'selected' : '' ?>><?= $t['action_type'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-500 mb-1">From Date</label>
                                <input type="date" name="date_from" value="<?= $date_from ?>" class="w-full p-2 border rounded-lg text-sm">
                            </div>
                            <div class="flex items-end gap-2">
                                <div class="flex-grow">
                                    <label class="block text-xs font-bold text-gray-500 mb-1">To Date</label>
                                    <input type="date" name="date_to" value="<?= $date_to ?>" class="w-full p-2 border rounded-lg text-sm">
                                </div>
                                <button type="submit" class="bg-[#1E3A1D] text-white p-2 rounded-lg hover:bg-[#2a4e29]"><span class="material-icons text-sm">check</span></button>
                                <a href="?role_type=<?= $role_filter ?>" class="bg-gray-200 text-gray-600 p-2 rounded-lg hover:bg-gray-300"><span class="material-icons text-sm">refresh</span></a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="content-card overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-[#1E3A1D] text-white">
                        <tr>
                            <th class="p-4 font-semibold w-40">Time</th>
                            <th class="p-4 font-semibold w-48">User</th>
                            <th class="p-4 font-semibold w-32">Action</th>
                            <th class="p-4 font-semibold w-32">Category</th>
                            <th class="p-4 font-semibold">Details</th>
                            <th class="p-4 w-20"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 text-gray-700 text-sm">
                        <?php if (empty($logs)): ?>
                            <tr><td colspan="6" class="p-8 text-center text-gray-400 italic">No logs found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($logs as $log): 
                                $badgeClass = 'badge-' . explode(' ', $log['action_type'])[0];
                               // Use '??' to default to null if the column is missing
$metaSafe = pretty_meta($log['metadata'] ?? null);                            ?>
                            <tr class="hover:bg-gray-50 transition cursor-pointer" onclick="viewLog(this)"
                                data-user="<?= htmlspecialchars($log['username']) ?>"
                                data-id="<?= $log['user_id'] ?>"
                                data-action="<?= htmlspecialchars($log['action_type']) ?>"
                                data-cat="<?= htmlspecialchars($log['action_category']) ?>"
                                data-details="<?= htmlspecialchars($log['details']) ?>"
                                data-time="<?= date('M j, Y h:i A', strtotime($log['log_time'])) ?>"
                                data-meta='<?= $metaSafe ?>'>
                                
                                <td class="p-4 whitespace-nowrap text-gray-500 font-mono text-xs">
                                    <?= date('M d, H:i', strtotime($log['log_time'])) ?>
                                </td>
                                <td class="p-4 font-bold text-gray-800">
                                    <?= htmlspecialchars($log['username']) ?> <span class="text-xs text-gray-400 font-normal">#<?= $log['user_id'] ?></span>
                                </td>
                                <td class="p-4">
                                    <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($log['action_type']) ?></span>
                                </td>
                                <td class="p-4 text-gray-500 text-xs uppercase"><?= htmlspecialchars($log['action_category']) ?></td>
                                <td class="p-4 truncate max-w-md"><?= htmlspecialchars($log['details']) ?></td>
                                <td class="p-4 text-right">
                                    <button class="text-blue-600 hover:text-blue-800 text-xs font-bold bg-blue-50 px-3 py-1 rounded">View</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if($totalPages > 1): ?>
                <div class="p-4 border-t border-gray-100 flex justify-between items-center bg-gray-50">
                    <span class="text-xs text-gray-500">Page <?= $page ?> of <?= $totalPages ?></span>
                    <div class="flex gap-1">
                        <?php if($page > 1): ?>
                            <a href="?role_type=<?=$role_filter?>&page=<?=$page-1?>&search=<?=$search?>" class="px-3 py-1 border rounded hover:bg-gray-200">Prev</a>
                        <?php endif; ?>
                        <?php if($page < $totalPages): ?>
                            <a href="?role_type=<?=$role_filter?>&page=<?=$page+1?>&search=<?=$search?>" class="px-3 py-1 border rounded hover:bg-gray-200">Next</a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <div id="viewModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 hidden backdrop-blur-sm">
        <div class="bg-white rounded-lg w-full max-w-lg p-6 shadow-2xl m-4 transform transition-all scale-100">
            <div class="flex justify-between items-start mb-4 border-b pb-4">
                <div>
                    <h2 class="text-xl font-bold text-[#1E3A1D]">Log Details</h2>
                    <p class="text-xs text-gray-500" id="modalTime"></p>
                </div>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><span class="material-icons">close</span></button>
            </div>
            
            <div class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">User</p>
                        <p class="font-medium text-gray-800" id="modalUser"></p>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-gray-400 uppercase">Category</p>
                        <p class="font-medium text-gray-800" id="modalCat"></p>
                    </div>
                </div>
                <div>
                    <p class="text-xs font-bold text-gray-400 uppercase">Action</p>
                    <span id="modalActionBadge" class="badge"></span>
                </div>
                <div>
                    <p class="text-xs font-bold text-gray-400 uppercase mb-1">Description</p>
                    <div class="text-sm bg-gray-50 p-3 rounded border border-gray-200 text-gray-700" id="modalDetails"></div>
                </div>
                <div id="metaContainer" class="hidden">
                    <p class="text-xs font-bold text-gray-400 uppercase mb-1">Technical Metadata (Changes)</p>
                    <div class="text-xs bg-gray-900 text-green-400 p-3 rounded overflow-auto max-h-40 font-mono" id="modalMeta"></div>
                </div>
            </div>

            <div class="mt-6 text-right">
                <button onclick="closeModal()" class="bg-gray-200 text-gray-700 px-4 py-2 rounded hover:bg-gray-300 font-bold text-sm">Close</button>
            </div>
        </div>
    </div>

    <script>
        // Tab Slider Logic
        const initTabSlider = () => {
            const container = document.getElementById('tab-nav-container');
            if (!container) return;
            const activeTab = container.querySelector('.tab-link.active');
            const slider = document.getElementById('tab-slider');
            if (activeTab && slider) {
                slider.style.width = `${activeTab.offsetWidth}px`;
                slider.style.transform = `translateX(${activeTab.offsetLeft}px)`;
            }
        };
        window.addEventListener('load', initTabSlider);
        window.addEventListener('resize', initTabSlider);

        // Filter Toggle
        const toggleBtn = document.getElementById('toggleFilterBtn');
        const filterOpts = document.getElementById('filterOptions');
        toggleBtn.addEventListener('click', () => {
            const isOpen = filterOpts.style.maxHeight !== '0px';
            filterOpts.style.maxHeight = isOpen ? '0px' : '500px';
            filterOpts.style.opacity = isOpen ? '0' : '1';
        });

        // Modal Logic
        const modal = document.getElementById('viewModal');
        
        function viewLog(row) {
            document.getElementById('modalUser').textContent = row.dataset.user + " (ID: " + row.dataset.id + ")";
            document.getElementById('modalCat').textContent = row.dataset.cat;
            document.getElementById('modalTime').textContent = row.dataset.time;
            document.getElementById('modalDetails').textContent = row.dataset.details;
            
            const badge = document.getElementById('modalActionBadge');
            badge.textContent = row.dataset.action;
            badge.className = 'badge badge-' + row.dataset.action.split(' ')[0];

            const metaContainer = document.getElementById('metaContainer');
            const metaDiv = document.getElementById('modalMeta');
            
            if (row.dataset.meta && row.dataset.meta !== 'null') {
                try {
                    const metaObj = JSON.parse(row.dataset.meta);
                    
                    if (metaObj.changes) {
                        // Pretty Print Changes
                        let html = '<ul class="list-disc pl-4 space-y-1">';
                        for (const [key, val] of Object.entries(metaObj.changes)) {
                            html += `<li><span class="text-white">${key}:</span> <span class="text-red-400">${val.old}</span> &rarr; <span class="text-green-400">${val.new}</span></li>`;
                        }
                        html += '</ul>';
                        metaDiv.innerHTML = html;
                    } else {
                        // Raw JSON
                        metaDiv.textContent = JSON.stringify(metaObj, null, 2);
                    }
                    metaContainer.classList.remove('hidden');
                } catch(e) {
                    metaContainer.classList.add('hidden');
                }
            } else {
                metaContainer.classList.add('hidden');
            }

            modal.classList.remove('hidden');
        }

        function closeModal() {
            modal.classList.add('hidden');
        }
    </script>
</body>
</html>