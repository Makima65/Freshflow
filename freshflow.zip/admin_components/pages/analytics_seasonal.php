<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\analytics_seasonal.php
session_start();
ini_set('display_errors', 0);
include_once '../includes/db_connection.php';

// Security Check
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: ../admin_login.php"); exit;
}

// --- GET FILTERS ---
// 1. Set Current Year
$current_year = date('Y');

// 2. DEFAULT TO LAST YEAR (2025) if no specific year is clicked
// This fixes the "Insufficient Data" error on load
$selected_year = isset($_GET['year']) ? (int)$_GET['year'] : ($current_year - 1);
$selected_pid = isset($_GET['pid']) ? (int)$_GET['pid'] : null;

// 3. Fetch Available Years for Toggle
$year_query = $conn->query("SELECT DISTINCT YEAR(sale_date) as yr FROM sales ORDER BY yr DESC");
$available_years = [];
while($yr_row = $year_query->fetch_assoc()) {
    $available_years[] = $yr_row['yr'];
}
// Ensure we always have at least last year and this year in the list
if (empty($available_years)) { 
    $available_years[] = $current_year; 
    $available_years[] = $current_year - 1; 
}
$available_years = array_unique($available_years);
rsort($available_years);

// --- ENGINE: SEASONAL INDEX ANALYZER ---
function getSeasonalInsights($conn, $product_id, $year) {
    // Construct conditions based on parameters
    $conditions = ["s.order_status = 'Completed'"];
    if ($product_id) { $conditions[] = "si.product_id = $product_id"; }
    if ($year) { $conditions[] = "YEAR(s.sale_date) = '$year'"; }
    
    $where_sql = implode(" AND ", $conditions);

    // 1. Fetch Monthly Sales
    $sql = "
        SELECT MONTH(s.sale_date) as mo, SUM(si.quantity) as qty
        FROM sales_items si
        JOIN sales s ON si.sale_id = s.sale_id
        WHERE $where_sql
        GROUP BY MONTH(s.sale_date)
        ORDER BY mo ASC
    ";
    
    $res = $conn->query($sql);
    $monthly_data = array_fill(1, 12, 0); 
    $total_sales = 0;
    
    while ($row = $res->fetch_assoc()) {
        $monthly_data[$row['mo']] = floatval($row['qty']);
        $total_sales += floatval($row['qty']);
    }
    
    // 2. Statistics
    $avg_monthly = ($total_sales > 0) ? $total_sales / 12 : 0;
    $max_month_val = max($monthly_data);
    
    if ($max_month_val > 0) {
        $peak_month_num = array_search($max_month_val, $monthly_data);
        $peak_month_name = date('F', mktime(0, 0, 0, $peak_month_num, 10));
    } else {
        $peak_month_name = "N/A";
    }
    
    $seasonal_indices = [];
    for ($m = 1; $m <= 12; $m++) {
        $actual = $monthly_data[$m];
        $index = ($avg_monthly > 0) ? ($actual / $avg_monthly) : 0;
        $seasonal_indices[$m] = $index;
    }

    return [
        'data' => array_values($monthly_data), 
        'indices' => $seasonal_indices,
        'avg' => $avg_monthly,
        'total' => $total_sales,
        'peak_month' => $peak_month_name,
        'peak_val' => $max_month_val
    ];
}

// --- DATA FETCHING ---
$prod_res = $conn->query("SELECT product_id, name FROM products WHERE status = 'Active'");
$products = $prod_res->fetch_all(MYSQLI_ASSOC);

$insights = getSeasonalInsights($conn, $selected_pid, $selected_year);

// --- SMART PRESCRIPTIVE LOGIC (INVENTORY AWARE + YEAR CONTEXT) ---
$current_month = (int)date('n'); 
$next_month = ($current_month % 12) + 1;
$next_month_name = date('F', mktime(0, 0, 0, $next_month, 10));

// Default Status
$status_color = "blue";
$status_icon = "insights";
$status_title = "Steady Operations";
$prescription = "Market stability detected based on <strong>$selected_year</strong> trends. <br><strong>Strategy:</strong> Maintain standard inventory levels.";

// Check if we are looking at an empty year
if ($insights['total'] == 0) {
    $status_color = "gray";
    $status_icon = "cloud_off";
    $status_title = "Insufficient Data";
    $prescription = "No sales data available for <strong>$selected_year</strong> yet. <br><strong>Strategy:</strong> Start recording sales or switch to a previous year to view historical trends.";
} 
// IF DATA EXISTS, RUN LOGIC
else {
    if ($selected_pid) {
        // --- SINGLE PRODUCT VIEW (Deep Dive) ---
        // 1. Fetch Current Stock
        $stock_q = $conn->query("SELECT quantity FROM product_inventory WHERE product_id = $selected_pid");
        $current_stock = ($stock_q && $stock_q->num_rows > 0) ? floatval($stock_q->fetch_assoc()['quantity']) : 0;

        $next_index = $insights['indices'][$next_month] ?? 0;
        
        // 2. Compare Trend vs Stock
        if ($next_index > 1.15) { 
            $percent = round(($next_index - 1) * 100);
            if ($current_stock < 50) { 
                $status_color = "red"; $status_icon = "warning"; $status_title = "🚨 Stockout Risk";
                $prescription = "<strong>CRITICAL:</strong> Viral spike of <strong>+$percent%</strong> seen in $selected_year history, but you only have <strong>$current_stock units</strong>.<br><strong>Action:</strong> Place emergency order.";
            } else {
                $status_color = "emerald"; $status_icon = "rocket_launch"; $status_title = "Peak Season Ready";
                $prescription = "Demand surge of <strong>+$percent%</strong> expected based on historical trends.<br><strong>Strategy:</strong> You are well stocked ($current_stock units).";
            }
        } elseif ($next_index < 0.85 && $next_index > 0) {
            $percent = round((1 - $next_index) * 100);
            if ($current_stock > 100) {
                $status_color = "orange"; $status_icon = "production_quantity_limits"; $status_title = "⚠️ Overstock Warning";
                $prescription = "Historical data shows a <strong>-$percent%</strong> drop in $next_month_name. You have $current_stock units.<br><strong>Action:</strong> Run clearance promo.";
            } else {
                $status_color = "amber"; $status_icon = "trending_down"; $status_title = "Off-Peak Season";
                $prescription = "Demand drop of <strong>-$percent%</strong> expected.<br><strong>Strategy:</strong> Reduce purchase orders.";
            }
        }
    } else {
        // --- MANAGER VIEW (Scanning All Products for Risks) ---
        $risks = []; // Overstock risks
        $opportunities = []; // Restock opportunities

        foreach ($products as $p) {
            $pid = $p['product_id'];
            // Analyze seasonality for this product
            $p_insights = getSeasonalInsights($conn, $pid, $selected_year);
            $p_idx = $p_insights['indices'][$next_month] ?? 0;
            
            // Fetch Current Stock for this product
            $sq = $conn->query("SELECT quantity FROM product_inventory WHERE product_id = $pid");
            $stk = ($sq && $sq->num_rows > 0) ? floatval($sq->fetch_assoc()['quantity']) : 0;

            // Logic: Find Mismatches between History and Inventory
            if ($p_idx > 1.20 && $stk < 20) {
                $opportunities[] = "{$p['name']} (High Demand, Low Stock)";
            }
            if ($p_idx < 0.85 && $stk > 100) { 
                $risks[] = "{$p['name']} (Dropping Demand, Overstocked)";
            }
        }

        if (!empty($risks)) {
            $status_color = "red"; $status_icon = "warning"; $status_title = "Overstock / Spoilage Risks";
            $item_string = implode(", ", array_slice($risks, 0, 3));
            $prescription = "<strong>Attention:</strong> The AI detected high inventory for items entering a slow season: <br><strong>$item_string</strong>.<br><strong>Action:</strong> Stop ordering these immediately and sell off current stock.";
        } elseif (!empty($opportunities)) {
            $status_color = "violet"; $status_icon = "shopping_cart_checkout"; $status_title = "Restock Opportunities";
            $item_string = implode(", ", array_slice($opportunities, 0, 3));
            $prescription = "Based on $selected_year trends, next month is busy for: <strong>$item_string</strong>, but stock is low.<br><strong>Action:</strong> Prepare inventory.";
        }
    }
}
?>

<?php include '../includes/sidebar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFlow - Seasonal Intelligence</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F8FAFC; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        
        .glass-panel { 
            background: rgba(255, 255, 255, 0.95); 
            backdrop-filter: blur(10px);
            border: 1px solid #E2E8F0; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03); 
            border-radius: 1rem; 
        }
        
        .stat-card-icon {
            background: linear-gradient(135deg, #1E3A1D 0%, #2f5c2d 100%);
            color: white;
        }

        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
    </style>
</head>
<body class="flex h-screen overflow-hidden text-slate-800">
    
    <main class="ml-20 flex-1 flex flex-col h-screen overflow-hidden relative">
        
        <div class="bg-white/80 backdrop-blur-md border-b border-gray-200 p-6 flex justify-between items-center z-10 sticky top-0">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-violet-100 text-violet-700 uppercase tracking-wide border border-violet-200">Prescriptive AI</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 uppercase tracking-wide border border-slate-200">Yearly Model</span>
                </div>
                <h1 class="text-2xl font-extrabold text-slate-900 tracking-tight">Seasonal Planner</h1>
            </div>
            
            <div class="flex items-center gap-6">
                <div class="flex bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-inner">
                    <?php foreach($available_years as $year): ?>
                        <a href="?year=<?= $year ?>&pid=<?= $selected_pid ?>" 
                           class="px-4 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 <?= $selected_year == $year ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600' ?>">
                            <?= $year ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <form action="" method="GET" class="flex items-center gap-3">
                    <input type="hidden" name="year" value="<?= $selected_year ?>">
                    <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Analyze:</span>
                    <div class="relative">
                        <select name="pid" onchange="this.form.submit()" class="appearance-none bg-white border border-gray-300 text-gray-700 text-sm rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 block w-64 p-2.5 shadow-sm font-medium">
                            <option value="">-- All Products Aggregate --</option>
                            <?php foreach($products as $p): ?>
                                <option value="<?= $p['product_id'] ?>" <?= $selected_pid == $p['product_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($p['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
                            <span class="material-icons text-sm">expand_more</span>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="flex-1 overflow-auto p-8 space-y-8 custom-scrollbar">
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="glass-panel p-5 flex items-center gap-4 transition hover:-translate-y-1 duration-300">
                    <div class="w-12 h-12 rounded-xl stat-card-icon shadow-lg flex items-center justify-center">
                        <span class="material-icons">event_available</span>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Peak Month (<?= $selected_year ?>)</p>
                        <p class="text-xl font-black text-slate-800"><?= $insights['peak_month'] ?></p>
                        <p class="text-xs text-green-600 font-bold flex items-center">
                            <span class="material-icons text-[12px] mr-1">arrow_upward</span>
                            <?= number_format($insights['peak_val']) ?> units
                        </p>
                    </div>
                </div>

                <div class="glass-panel p-5 flex items-center gap-4 transition hover:-translate-y-1 duration-300">
                    <div class="w-12 h-12 rounded-xl bg-white border border-slate-100 shadow-sm text-slate-600 flex items-center justify-center">
                        <span class="material-icons">inventory_2</span>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Yearly Volume</p>
                        <p class="text-xl font-black text-slate-800"><?= number_format($insights['total']) ?></p>
                        <p class="text-xs text-slate-400">Avg. <?= number_format($insights['avg'], 0) ?> / month</p>
                    </div>
                </div>

                <div class="glass-panel p-5 flex items-center gap-4 transition hover:-translate-y-1 duration-300 border-<?= $status_color ?>-200 bg-<?= $status_color ?>-50/50">
                    <div class="w-12 h-12 rounded-xl bg-<?= $status_color ?>-100 text-<?= $status_color ?>-600 flex items-center justify-center">
                        <span class="material-icons"><?= $status_icon ?></span>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-<?= $status_color ?>-600 uppercase tracking-wider">Next Month Outlook</p>
                        <p class="text-xl font-black text-slate-800"><?= $next_month_name ?></p>
                        <p class="text-xs font-bold text-<?= $status_color ?>-700">
                            Index Score: <?= number_format(isset($next_index) ? $next_index : 1.0, 2) ?>x
                        </p>
                    </div>
                </div>
            </div>

            <div class="glass-panel p-0 overflow-hidden shadow-md">
                <div class="p-6 bg-gradient-to-r from-<?= $status_color ?>-50 to-white border-b border-<?= $status_color ?>-100">
                    <div class="flex gap-5 items-start">
                        <div class="p-3 bg-white rounded-full shadow-md text-<?= $status_color ?>-600 ring-4 ring-<?= $status_color ?>-50">
                            <span class="material-icons text-3xl">psychology_alt</span>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-lg font-bold text-slate-800 mb-1 flex items-center gap-2">
                                AI Strategic Recommendation
                                <span class="bg-<?= $status_color ?>-100 text-<?= $status_color ?>-700 text-[10px] px-2 py-1 rounded-full uppercase tracking-wide">
                                    <?= $status_title ?>
                                </span>
                            </h3>
                            <p class="text-slate-600 text-sm leading-relaxed mt-2">
                                <?= $prescription ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="glass-panel p-6">
                <div class="flex justify-between items-end mb-6">
                    <div>
                        <h3 class="font-bold text-slate-800 text-lg">Historical Seasonal Curve: <?= $selected_year ?></h3>
                        <p class="text-xs text-slate-500">Visualizing demand velocity across the selected fiscal year.</p>
                    </div>
                    <div class="flex gap-2">
                         <span class="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Peak (>1.2x)</span>
                         <span class="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase"><span class="w-2 h-2 rounded-full bg-amber-500"></span> Low (<0.8x)</span>
                    </div>
                </div>
                <div class="h-80 w-full relative">
                    <canvas id="seasonalChart"></canvas>
                </div>
            </div>

            <div class="glass-panel overflow-hidden">
                <div class="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h3 class="font-bold text-slate-700 text-sm">Monthly Velocity Matrix (<?= $selected_year ?>)</h3>
                    <button class="text-xs text-blue-600 font-bold hover:underline">Download Report</button>
                </div>
                <table class="w-full text-left text-sm">
                    <thead class="bg-white text-slate-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-100">
                        <tr>
                            <th class="px-6 py-4">Month</th>
                            <th class="px-6 py-4 text-right">Volume</th>
                            <th class="px-6 py-4 text-center">Seasonal Index</th>
                            <th class="px-6 py-4">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                        <?php 
                        $months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        for($m=1; $m<=12; $m++): 
                            $idx = $insights['indices'][$m];
                            $vol = $insights['data'][$m-1];
                            $is_current = ($m == (int)date('n') && $selected_year == (int)date('Y'));
                            $row_bg = $is_current ? "bg-blue-50/50" : "hover:bg-slate-50/50";
                            
                            $badge = '<span class="px-2 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-bold">Normal</span>';
                            if($idx > 1.2) $badge = '<span class="px-2 py-1 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">High Demand</span>';
                            if($idx < 0.8 && $vol > 0) $badge = '<span class="px-2 py-1 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">Slow</span>';
                            if($vol == 0) $badge = '<span class="px-2 py-1 rounded-full bg-gray-100 text-gray-400 text-[10px] font-bold">No Data</span>';
                        ?>
                        <tr class="transition <?= $row_bg ?>">
                            <td class="px-6 py-4 font-bold text-slate-700 flex items-center gap-2">
                                <?= $months[$m-1] ?> 
                                <?php if($is_current) echo '<span class="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>'; ?>
                            </td>
                            <td class="px-6 py-4 text-right font-mono text-slate-600"><?= number_format($vol) ?></td>
                            <td class="px-6 py-4 text-center">
                                <span class="font-mono text-xs font-bold"><?= number_format($idx, 2) ?>x</span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-24 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                                        <div class="h-full rounded-full bg-slate-800" style="width: <?= min(100, $idx * 100) ?>%"></div>
                                    </div>
                                    <?= $badge ?>
                                </div>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

    <script>
        const ctx = document.getElementById('seasonalChart').getContext('2d');
        
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const data = <?= json_encode($insights['data']) ?>;
        const avg = <?= $insights['avg'] ?>;
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Sales Volume',
                    data: data,
                    backgroundColor: data.map(val => val > avg * 1.2 ? '#10B981' : (val < avg * 0.8 && val > 0 ? '#F59E0B' : (val === 0 ? '#E2E8F0' : '#6366F1'))),
                    borderRadius: 6,
                    borderSkipped: false,
                    barThickness: 24
                }, {
                    type: 'line',
                    label: 'Yearly Average',
                    data: Array(12).fill(avg),
                    borderColor: '#94A3B8',
                    borderWidth: 2,
                    borderDash: [6, 6],
                    pointRadius: 0,
                    order: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { 
                    legend: { display: false },
                    tooltip: { 
                        backgroundColor: '#1E293B',
                        padding: 12,
                        cornerRadius: 8,
                        titleFont: { size: 13 },
                        bodyFont: { size: 13 }
                    }
                },
                scales: { 
                    y: { 
                        beginAtZero: true, 
                        grid: { borderDash: [4, 4], color: '#E2E8F0' },
                        ticks: { font: { size: 11, family: "'Inter', sans-serif" } }
                    },
                    x: { 
                        grid: { display: false },
                        ticks: { font: { size: 11, family: "'Inter', sans-serif" } }
                    }
                }
            }
        });
    </script>
</body>
</html>