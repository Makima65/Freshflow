<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\inventory.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Error Handling
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include_once '../includes/db_connection.php';

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    if (isset($_GET['action'])) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Session expired']);
        exit;
    }
    header("location: ../admin_login.php");
    exit;
}

// =================================================================================
//                              HANDLE RESTOCK (NEW OPTIMIZATION FEATURE)
// =================================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restock') {
    $product_id = intval($_POST['product_id']);
    $qty_added = floatval($_POST['quantity_added']);
    
    if ($product_id > 0 && $qty_added > 0) {
        $stmt = $conn->prepare("UPDATE product_inventory SET quantity = quantity + ?, last_restock_date = NOW() WHERE product_id = ?");
        $stmt->bind_param("di", $qty_added, $product_id);
        if ($stmt->execute()) {
            header("Location: inventory.php?success=restocked");
            exit;
        }
    }
}

// =================================================================================
//                              AJAX HISTORY HANDLER
// =================================================================================
if (isset($_GET['action']) && $_GET['action'] === 'get_history' && isset($_GET['id'])) {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json');

    $product_id = intval($_GET['id']);
    
    // Get Product Name
    $p_stmt = $conn->prepare("SELECT name FROM products WHERE product_id = ?");
    $p_stmt->bind_param("i", $product_id);
    $p_stmt->execute();
    $p_name = $p_stmt->get_result()->fetch_assoc()['name'] ?? '';
    
    // Search Audit Trail
    $safe_name = $conn->real_escape_string($p_name);
    $sql = "SELECT username, action_type as action, details as description, log_time as date 
            FROM audit_trail 
            WHERE details LIKE '%$safe_name%' OR details LIKE '%ID: $product_id%'
            ORDER BY log_time DESC LIMIT 20";
            
    $history = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

    foreach ($history as &$row) {
        $row['date'] = date('M d, Y h:i A', strtotime($row['date']));
        $row['username'] = $row['username'] ?? 'System';
    }

    echo json_encode(['product_name' => $p_name, 'history' => $history]);
    exit;
}

// =================================================================================
//                              PAGE FILTERS & SEARCH
// =================================================================================

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$stock_filter = isset($_GET['stock']) ? $_GET['stock'] : 'all';
$brand_filter = isset($_GET['brand']) ? $_GET['brand'] : 'all';
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';

// Base WHERE
$where = ["p.status != 'Archived'"];
if ($search) $where[] = "(p.name LIKE '%$search%' OR p.product_brand LIKE '%$search%')";
if ($brand_filter !== 'all') $where[] = "p.product_brand = '" . $conn->real_escape_string($brand_filter) . "'";

// --- DYNAMIC STATUS LOGIC (OPTIMIZATION) ---
if ($stock_filter === 'in_stock') $where[] = "COALESCE(pi.quantity, 0) > COALESCE(pi.reorder_level, 10)";
elseif ($stock_filter === 'low_stock') $where[] = "COALESCE(pi.quantity, 0) <= COALESCE(pi.reorder_level, 10) AND COALESCE(pi.quantity, 0) > 0";
elseif ($stock_filter === 'out_of_stock') $where[] = "COALESCE(pi.quantity, 0) <= 0";

$where_sql = implode(' AND ', $where);

// Sorting Logic
$sort_sql = match($sort_by) {
    'stock_asc' => 'pi.quantity ASC',
    'stock_desc' => 'pi.quantity DESC',
    'name_desc' => 'p.name DESC',
    default => 'p.name ASC'
};

// --- MAIN QUERY ---
$sql = "SELECT 
            p.product_id, p.name, p.product_brand, c.category_name, p.image_url, 
            COALESCE(pi.quantity, 0) as quantity, 
            COALESCE(pi.reorder_level, 10) as reorder_level,
            pi.last_restock_date
        FROM products p 
        LEFT JOIN product_inventory pi ON p.product_id = pi.product_id 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE $where_sql 
        ORDER BY $sort_sql";

$inventory = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

$brands = $conn->query("SELECT DISTINCT product_brand FROM products WHERE product_brand != '' ORDER BY product_brand ASC")->fetch_all(MYSQLI_ASSOC);

$metrics = $conn->query("
    SELECT 
        SUM(COALESCE(pi.quantity, 0)) as total_stock,
        SUM(CASE WHEN pi.quantity <= pi.reorder_level AND pi.quantity > 0 THEN 1 ELSE 0 END) as low_stock,
        SUM(CASE WHEN pi.quantity <= 0 THEN 1 ELSE 0 END) as out_of_stock,
        SUM(p.price * COALESCE(pi.quantity, 0)) as total_value
    FROM products p 
    LEFT JOIN product_inventory pi ON p.product_id = pi.product_id 
    WHERE p.status != 'Archived'
")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FreshFlow - Inventory Report</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; }
        .modal { transition: opacity 0.2s ease-in-out; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        
        /* General Styles */
        .content-card { background-color: #ffffff; border: 1px solid #e5e7eb; border-radius: 0.75rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .form-input, .filter-select { background-color: #ffffff; border: 1px solid #d1d5db; color: #374151; font-size: 0.875rem; transition: all 0.2s; }
        .form-input:focus, .filter-select:focus { outline: none; border-color: #1E3A1D; box-shadow: 0 0 0 3px rgba(30, 58, 29, 0.1); }
        #filterOptions { transition: all 0.3s ease-out; overflow: hidden; }
        
        /* Badges */
        .status-badge { padding: 4px 12px; border-radius: 99px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; }
        .status-Good { background: #dcfce7; color: #166534; }
        .status-Low { background: #fef9c3; color: #854d0e; }
        .status-Critical { background: #fee2e2; color: #991b1b; }

        /* --- PRINT STYLES (THE FIX) --- */
        @media print {
            /* Hide Sidebar, Buttons, Search Bar, Filters */
            #sidebar, .no-print, #filterSortForm, button, .action-column { 
                display: none !important; 
            }
            
            /* Reset Layout for Paper */
            body { background-color: white; color: black; }
            .ml-20 { margin-left: 0 !important; padding: 0 !important; }
            .content-card { box-shadow: none; border: 1px solid #ccc; }
            
            /* Show Print Header */
            #printHeader { display: block !important; margin-bottom: 20px; text-align: center; }
            
            /* Table Formatting */
            table { width: 100%; border-collapse: collapse; font-size: 12px; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            thead { background-color: #f0f0f0 !important; color: black !important; }
            
            /* Ensure metrics are visible */
            .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; }
        }
    </style>
</head>
<body>

    <div class="no-print">
        <?php include '../includes/sidebar.php'; ?>
    </div>

    <div class="ml-20 p-8">
        
        <div id="printHeader" style="display: none;">
            <h1 class="text-2xl font-bold">FreshFlow Inventory Report</h1>
            <p>Generated on: <?= date('F d, Y h:i A') ?></p>
            <hr class="my-4 border-gray-400">
        </div>

        <header class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 no-print">
            <div>
                <h1 class="text-3xl font-bold text-[#1E3A1D]">Inventory Optimization</h1>
                <p class="text-gray-500">Real-time stock tracking with dynamic reorder levels.</p>
            </div>
            <button onclick="window.print()" class="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-bold hover:bg-gray-50 flex items-center gap-2 no-print">
                <span class="material-icons text-sm">print</span> Print Report
            </button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="content-card p-6 border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Stock</p>
                <p class="text-3xl font-bold text-[#1E3A1D] mt-1"><?= number_format($metrics['total_stock']) ?></p>
            </div>
            <div class="content-card p-6 border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Low Stock</p>
                <p class="text-3xl font-bold text-yellow-600 mt-1"><?= number_format($metrics['low_stock']) ?></p>
            </div>
            <div class="content-card p-6 border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Out of Stock</p>
                <p class="text-3xl font-bold text-[#B33333] mt-1"><?= number_format($metrics['out_of_stock']) ?></p>
            </div>
            <div class="content-card p-6 border border-gray-200">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">Stock Value</p>
                <p class="text-3xl font-bold text-[#3E6E41] mt-1">₱<?= number_format($metrics['total_value'], 2) ?></p>
            </div>
        </div>

        <div class="content-card p-4 mb-6 relative z-10 no-print">
            <div id="filterSortForm">
                <form action="" method="GET">
                    <div class="flex flex-col md:flex-row items-center gap-4">
                        <div class="relative w-full flex-grow">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400"><span class="material-icons">search</span></span>
                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search products..." class="w-full pl-10 p-2.5 rounded-lg form-input" autocomplete="off">
                        </div>
                        <button type="button" id="toggleFilterBtn" class="relative flex-shrink-0 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-2.5 px-4 rounded-lg flex items-center space-x-2 transition shadow-sm">
                            <span class="material-icons">filter_list</span>
                            <span>Filter</span>
                            <span id="filterCountBadge" class="hidden bg-red-600 text-white rounded-full w-5 h-5 flex justify-center items-center text-xs">0</span>
                        </button>
                    </div>
                    
                    <div id="filterOptions" style="max-height: 0px; opacity: 0;">
                        <div class="border-t border-gray-200 mt-4 pt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                            <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Stock Status</label>
                                <select name="stock" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all">All</option>
                                    <option value="in_stock" <?= $stock_filter=='in_stock'?'selected':'' ?>>In Stock</option>
                                    <option value="low_stock" <?= $stock_filter=='low_stock'?'selected':'' ?>>Low Stock (Optimization)</option>
                                    <option value="out_of_stock" <?= $stock_filter=='out_of_stock'?'selected':'' ?>>Out of Stock</option>
                                </select>
                            </div>
                            <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Brand</label>
                                <select name="brand" class="w-full p-2 rounded-lg filter-select">
                                    <option value="all">All Brands</option>
                                    <?php foreach ($brands as $b): ?>
                                    <option value="<?= htmlspecialchars($b['product_brand']) ?>" <?= $brand_filter==$b['product_brand']?'selected':'' ?>><?= htmlspecialchars($b['product_brand']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                             <div class="w-full">
                                <label class="block text-xs font-bold text-gray-500 mb-1 uppercase">Sort By</label>
                                <select name="sort" class="w-full p-2 rounded-lg filter-select">
                                     <option value="name_asc" <?= $sort_by=='name_asc'?'selected':'' ?>>Name (A-Z)</option>
                                     <option value="name_desc" <?= $sort_by=='name_desc'?'selected':'' ?>>Name (Z-A)</option>
                                     <option value="stock_asc" <?= $sort_by=='stock_asc'?'selected':'' ?>>Stock (Low-High)</option>
                                     <option value="stock_desc" <?= $sort_by=='stock_desc'?'selected':'' ?>>Stock (High-Low)</option>
                                </select>
                            </div>
                            <div class="w-full flex gap-2">
                                <button type="submit" class="w-full bg-[#1E3A1D] hover:bg-[#142913] text-white font-bold py-2 px-4 rounded-lg shadow-md transition">Apply</button>
                                <a href="inventory.php" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-2 px-4 rounded-lg text-center transition">Reset</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-[#1E3A1D] text-white text-xs uppercase font-bold">
                    <tr>
                        <th class="p-4">Product</th>
                        <th class="p-4">Category</th>
                        <th class="p-4 text-center">Stock Level</th>
                        <th class="p-4 text-center">Safety Stock</th>
                        <th class="p-4 text-center">Status</th>
                        <th class="p-4 text-right action-column">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 text-sm">
                    <?php if (empty($inventory)): ?>
                        <tr><td colspan="6" class="p-8 text-center text-gray-400">No products found.</td></tr>
                    <?php else: ?>
                        <?php foreach($inventory as $item): 
                            // DYNAMIC STATUS LOGIC
                            $status = 'Good';
                            $statusClass = 'status-Good';
                            if ($item['quantity'] <= 0) {
                                $status = 'Critical';
                                $statusClass = 'status-Critical';
                            } elseif ($item['quantity'] <= $item['reorder_level']) {
                                $status = 'Low';
                                $statusClass = 'status-Low';
                            }
                            // Image Path
                            $img = $item['image_url'] ? "../../" . $item['image_url'] : "../../assets/img/placeholder.png";
                        ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4">
                                <div class="flex items-center gap-3">
                                    <img src="<?= $img ?>" class="w-10 h-10 rounded object-cover border border-gray-200 no-print">
                                    <div>
                                        <div class="font-bold text-gray-800"><?= htmlspecialchars($item['name']) ?></div>
                                        <div class="text-xs font-normal text-gray-400"><?= htmlspecialchars($item['product_brand']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="p-4 text-gray-500"><?= htmlspecialchars($item['category_name']) ?></td>
                            
                            <td class="p-4 text-center font-mono font-bold text-lg">
                                <?= number_format($item['quantity']) ?>
                            </td>

                            <td class="p-4 text-center text-gray-400 text-xs">
                                Target: <?= $item['reorder_level'] ?>
                            </td>

                            <td class="p-4 text-center">
                                <span class="status-badge <?= $statusClass ?>"><?= $status ?></span>
                            </td>

                            <td class="p-4 text-right flex justify-end gap-2 action-column">
                                <button onclick="openRestockModal(<?= $item['product_id'] ?>, '<?= htmlspecialchars($item['name']) ?>')" class="text-blue-600 hover:text-blue-800 font-bold text-xs border border-blue-200 hover:border-blue-400 bg-blue-50 px-3 py-1 rounded transition flex items-center gap-1">
                                    <span class="material-icons text-sm">add_shopping_cart</span> Restock
                                </button>
                                <button onclick="viewHistory(<?= $item['product_id'] ?>)" class="text-gray-400 hover:text-[#1E3A1D] p-1 rounded hover:bg-gray-100 transition">
                                    <span class="material-icons">history</span>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="restockModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex justify-center items-center backdrop-blur-sm modal no-print">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6">
            <h2 class="text-xl font-bold text-[#1E3A1D] mb-1">Restock Inventory</h2>
            <p class="text-sm text-gray-500 mb-4">Add supplies for <span id="modalProductName" class="font-bold text-black"></span></p>
            <form method="POST">
                <input type="hidden" name="action" value="restock">
                <input type="hidden" id="modalProductId" name="product_id">
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Qty to Add</label>
                <input type="number" name="quantity_added" required class="w-full p-3 border border-gray-300 rounded-lg mb-4 text-lg font-mono">
                <div class="flex justify-end gap-3">
                    <button type="button" onclick="closeRestock()" class="px-4 py-2 text-gray-500 hover:text-gray-700">Cancel</button>
                    <button type="submit" class="bg-[#1E3A1D] hover:bg-[#2a4e29] text-white px-6 py-2 rounded-lg font-bold">Confirm</button>
                </div>
            </form>
        </div>
    </div>

    <div id="historyModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex justify-center items-center backdrop-blur-sm modal no-print">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg p-6 max-h-[80vh] flex flex-col">
            <div class="flex justify-between items-center mb-4 border-b pb-2">
                <h2 class="text-xl font-bold text-[#1E3A1D]">Audit Log</h2>
                <button onclick="closeHistory()" class="text-gray-400 hover:text-red-500"><span class="material-icons">close</span></button>
            </div>
            <div id="historyContent" class="overflow-y-auto flex-1 text-sm space-y-2"></div>
        </div>
    </div>

    <script>
        // --- FILTER TOGGLE LOGIC ---
        const toggleFilterBtn = document.getElementById('toggleFilterBtn');
        const filterOptions = document.getElementById('filterOptions');
        const filterBadge = document.getElementById('filterCountBadge');

        toggleFilterBtn.addEventListener('click', () => {
            const isOpen = filterOptions.style.maxHeight && filterOptions.style.maxHeight !== '0px';
            filterOptions.style.maxHeight = isOpen ? '0px' : filterOptions.scrollHeight + 'px';
            filterOptions.style.opacity = isOpen ? '0' : '1';
        });

        // Update Badge Count
        let count = 0;
        if ('<?= $stock_filter ?>' !== 'all') count++;
        if ('<?= $brand_filter ?>' !== 'all') count++;
        if (count > 0) {
            filterBadge.textContent = count;
            filterBadge.classList.remove('hidden');
            filterBadge.classList.add('flex');
        }

        // --- RESTOCK LOGIC ---
        const rModal = document.getElementById('restockModal');
        function openRestockModal(id, name) {
            document.getElementById('modalProductId').value = id;
            document.getElementById('modalProductName').textContent = name;
            rModal.classList.remove('hidden');
        }
        function closeRestock() { rModal.classList.add('hidden'); }

        // --- HISTORY LOGIC ---
        const hModal = document.getElementById('historyModal');
        const hContent = document.getElementById('historyContent');
        
        async function viewHistory(id) {
            hModal.classList.remove('hidden');
            hContent.innerHTML = '<div class="text-center py-4 text-gray-400">Loading logs...</div>';
            try {
                const res = await fetch(`?action=get_history&id=${id}`);
                const data = await res.json();
                
                if(!data.history || data.history.length === 0) {
                    hContent.innerHTML = '<div class="text-center py-4 text-gray-400 italic">No history found.</div>';
                    return;
                }

                hContent.innerHTML = data.history.map(log => `
                    <div class="bg-gray-50 p-3 rounded border border-gray-100">
                        <div class="font-bold text-gray-800">${log.description}</div>
                        <div class="text-xs text-gray-400 flex justify-between mt-1">
                            <span>${log.username}</span>
                            <span>${log.date}</span>
                        </div>
                    </div>
                `).join('');
            } catch(e) { hContent.innerHTML = '<div class="text-red-500 text-center">Error loading data.</div>'; }
        }
        function closeHistory() { hModal.classList.add('hidden'); }
    </script>
</body>
</html>