<?php
// C:\xampp\htdocs\RalphPHP\admin_components\includes\audit_helper.php

if (!function_exists('log_audit_action')) {
    function log_audit_action($action_type, $category, $details, $metadata = []) {
        global $conn;

        // Ensure session is started to get user info
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $user_id = $_SESSION['user_id'] ?? 0;
        $username = $_SESSION['username'] ?? 'System';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '::1';
        
        $meta_json = !empty($metadata) ? json_encode($metadata) : null;

        $stmt = $conn->prepare("INSERT INTO audit_trail (user_id, username, action_type, action_category, details, metadata, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("issssss", $user_id, $username, $action_type, $category, $details, $meta_json, $ip);
            $stmt->execute();
            $stmt->close();
        }
    }
}
?>