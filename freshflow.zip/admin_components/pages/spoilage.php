<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\spoilage.php
ob_start();
session_start();
include_once '../includes/db_connection.php';

// --- HANDLE SPOILAGE FORM ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'report_spoilage') {
    $product_id = intval($_POST['product_id']);
    $qty = floatval($_POST['quantity']);
    $reason = trim($_POST['reason']);
    $user_id = $_SESSION['user_id'] ?? 1;

    if ($product_id > 0 && $qty > 0) {
        $conn->begin_transaction();
        try {
            // 1. Save to Spoilage Table
            $stmt = $conn->prepare("INSERT INTO spoilage (product_id, quantity, reason, recorded_by) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("idsi", $product_id, $qty, $reason, $user_id);
            if (!$stmt->execute()) { throw new Exception($stmt->error); }

            // 2. Remove from Inventory
            $stmt_inv = $conn->prepare("UPDATE product_inventory SET quantity = quantity - ? WHERE product_id = ?");
            $stmt_inv->bind_param("di", $qty, $product_id);
            $stmt_inv->execute();

            $conn->commit();
            header("Location: spoilage.php?success=1");
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Fetch Data for Dropdowns
$products = $conn->query("SELECT * FROM products ORDER BY name ASC")->fetch_all(MYSQLI_ASSOC);

// --- FIX: USE LEFT JOIN SO ROWS ALWAYS SHOW ---
$history = $conn->query("
    SELECT s.*, p.name, p.product_brand, p.price 
    FROM spoilage s 
    LEFT JOIN products p ON s.product_id = p.product_id 
    ORDER BY s.spoilage_date DESC LIMIT 20
")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Waste & Spoilage</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; }</style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 p-8">
        <header class="mb-8">
            <h1 class="text-3xl font-bold text-[#1E3A1D]">Waste Tracking</h1>
            <p class="text-gray-500">Log damaged or expired goods here.</p>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
                <h2 class="text-xl font-bold text-[#1E3A1D] mb-4 flex items-center gap-2">
                    <span class="material-icons text-red-500">delete_forever</span> Report Loss
                </h2>

                <?php if (isset($_GET['success'])): ?>
                    <div class="bg-green-100 text-green-800 p-3 rounded mb-4 text-sm font-bold">Recorded successfully!</div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="bg-red-100 text-red-800 p-3 rounded mb-4 text-sm font-bold"><?= $error ?></div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="action" value="report_spoilage">
                    
                    <div class="mb-4">
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Product</label>
                        <select name="product_id" required class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50">
                            <option value="">-- Select Item --</option>
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['product_id'] ?>"><?= htmlspecialchars($p['name']) ?> (<?= $p['product_brand'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Quantity Lost</label>
                        <input type="number" name="quantity" step="0.01" required class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50" placeholder="0.00">
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Reason</label>
                        <select name="reason" class="w-full p-3 border border-gray-300 rounded-lg bg-gray-50">
                            <option value="Expired / Rotten">Expired / Rotten</option>
                            <option value="Damaged">Damaged in Delivery</option>
                            <option value="Theft">Lost / Theft</option>
                            <option value="Returned">Client Return</option>
                        </select>
                    </div>

                    <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg shadow transition">
                        Confirm & Deduct
                    </button>
                </form>
            </div>

            <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="p-4 border-b border-gray-200 bg-gray-50 font-bold text-gray-700">Recent Spoilage Logs</div>
                <table class="w-full text-left text-sm">
                    <thead class="text-xs uppercase text-gray-500 bg-white border-b border-gray-100">
                        <tr>
                            <th class="p-4">Date</th>
                            <th class="p-4">Product</th>
                            <th class="p-4">Reason</th>
                            <th class="p-4 text-right">Qty</th>
                            <th class="p-4 text-right">Value Lost</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($history)): ?>
                            <tr><td colspan="5" class="p-8 text-center text-gray-400 italic">No waste recorded yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($history as $h): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-4 text-gray-500">
                                    <?= isset($h['spoilage_date']) ? date('M d', strtotime($h['spoilage_date'])) : 'N/A' ?>
                                </td>
                                <td class="p-4 font-bold text-gray-800">
                                    <?= htmlspecialchars($h['name'] ?? 'Unknown Product #' . $h['product_id']) ?>
                                    <div class="text-xs text-gray-400"><?= htmlspecialchars($h['product_brand'] ?? '') ?></div>
                                </td>
                                <td class="p-4"><span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs font-bold"><?= htmlspecialchars($h['reason']) ?></span></td>
                                <td class="p-4 text-right font-mono text-red-600 font-bold">-<?= number_format($h['quantity'], 2) ?></td>
                                <td class="p-4 text-right text-gray-600">
                                    ₱<?= number_format($h['quantity'] * ($h['price'] ?? 0), 2) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>