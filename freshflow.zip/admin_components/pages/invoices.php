<?php
// C:\xampp\htdocs\RalphPHP\admin_components\pages\invoices.php

// 1. START BUFFERING
if (session_status() == PHP_SESSION_NONE) { session_start(); }
ob_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include_once '../includes/db_connection.php';

// --- AUDIT HELPER ---
$auditHelperPath = '../includes/audit_helper.php';
if (file_exists($auditHelperPath)) { include_once $auditHelperPath; } 
else { if (!function_exists('log_audit_action')) { function log_audit_action($a, $b, $c, $d = []) { return true; } } }

// --- SECURITY CHECK ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        ob_clean(); header('Content-Type: application/json'); echo json_encode(['success' => false, 'message' => 'Session expired']); exit;
    }
    header("location: ../admin_login.php"); exit;
}

// --- BACKEND HANDLER ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean(); header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    // 1. GET INVOICE DETAILS & HISTORY
    if ($action === 'get_invoice_details') {
        $sale_id = intval($_POST['sale_id']);
        
        // Get Sale Info
        $q = "SELECT s.*, c.client_name, c.address, c.contact_number
              FROM sales s 
              LEFT JOIN clients c ON s.client_id = c.client_id 
              WHERE s.sale_id = ?";
        $stmt = $conn->prepare($q);
        $stmt->bind_param("i", $sale_id);
        $stmt->execute();
        $sale = $stmt->get_result()->fetch_assoc();

        // Get Items
        $qi = "SELECT si.quantity, si.price_at_sale, p.name, p.unit 
               FROM sales_items si 
               JOIN products p ON si.product_id = p.product_id 
               WHERE si.sale_id = ?";
        $stmt_i = $conn->prepare($qi);
        $stmt_i->bind_param("i", $sale_id);
        $stmt_i->execute();
        $items = $stmt_i->get_result()->fetch_all(MYSQLI_ASSOC);

        // Get Payment History
        $qp = "SELECT * FROM payments WHERE sale_id = ? ORDER BY payment_date DESC";
        $stmt_p = $conn->prepare($qp);
        $stmt_p->bind_param("i", $sale_id);
        $stmt_p->execute();
        $payments = $stmt_p->get_result()->fetch_all(MYSQLI_ASSOC);

        echo json_encode(['success' => true, 'sale' => $sale, 'items' => $items, 'payments' => $payments]);
        exit;
    }

    // 2. RECORD PAYMENT (WITH VALIDATION)
    if ($action === 'record_payment') {
        $sale_id = intval($_POST['sale_id']);
        $amount = floatval($_POST['amount']);
        $method = $_POST['method'];
        $ref = $_POST['reference'];
        $user_id = $_SESSION['user_id'] ?? 0;

        if ($amount <= 0) { echo json_encode(['success' => false, 'message' => 'Invalid amount']); exit; }

        $conn->begin_transaction();
        try {
            // --- VALIDATION START ---
            // Lock row for update to prevent race conditions
            $check = $conn->query("SELECT total_amount, amount_paid FROM sales WHERE sale_id = $sale_id FOR UPDATE")->fetch_assoc();
            
            $current_paid = floatval($check['amount_paid']);
            $total = floatval($check['total_amount']);
            $remaining = $total - $current_paid;

            // Allow tiny tolerance (0.01) for float rounding errors
            if ($amount > $remaining + 0.01) {
                throw new Exception("Error: Payment amount (₱" . number_format($amount, 2) . ") exceeds the remaining balance of ₱" . number_format($remaining, 2));
            }
            // --- VALIDATION END ---

            // A. Insert into Payments
            $stmt = $conn->prepare("INSERT INTO payments (sale_id, amount, payment_method, reference_no, recorded_by) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("idssi", $sale_id, $amount, $method, $ref, $user_id);
            $stmt->execute();

            // B. Update Sales Table
            $new_paid = $current_paid + $amount;
            
            $status = 'Partial';
            if ($new_paid >= $total - 0.01) { $status = 'Paid'; } 
            if ($new_paid <= 0) { $status = 'Pending'; }

            $upd = $conn->prepare("UPDATE sales SET amount_paid = ?, payment_status = ? WHERE sale_id = ?");
            $upd->bind_param("dsi", $new_paid, $status, $sale_id);
            $upd->execute();

            $conn->commit();
            if (function_exists('log_audit_action')) log_audit_action('Payment', 'Finance', "Received P$amount for Order #$sale_id via $method");
            
            echo json_encode(['success' => true, 'message' => 'Payment recorded successfully!']);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
}
ob_end_flush();

// --- FETCH INVOICE LIST ---
// Logic: Show 'Completed' orders. 
// Sort: Pending first, then Partial, then Paid.
$query = "
    SELECT s.sale_id, s.total_amount, s.amount_paid, s.payment_status, s.delivered_at, 
           c.client_name 
    FROM sales s
    LEFT JOIN clients c ON s.client_id = c.client_id
    WHERE s.order_status = 'Completed'
    ORDER BY 
        CASE WHEN s.payment_status = 'Pending' THEN 1 
             WHEN s.payment_status = 'Partial' THEN 2 
             ELSE 3 END, 
        s.delivered_at DESC
";
$invoices = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// Stats
$total_receivables = 0;
foreach($invoices as $inv) {
    if($inv['payment_status'] != 'Paid') {
        $total_receivables += ($inv['total_amount'] - $inv['amount_paid']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreshFlow - Invoices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F8F5EE; color: #2B2B2B; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .status-badge { padding: 4px 12px; border-radius: 99px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; }
        .status-Pending { background: #fee2e2; color: #991b1b; } /* Replaces Unpaid */
        .status-Partial { background: #ffedd5; color: #9a3412; }
        .status-Paid { background: #dcfce7; color: #166534; }
        
        @media print {
            body * { visibility: hidden; }
            #printArea, #printArea * { visibility: visible; }
            #printArea { position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: white; padding: 40px; z-index: 9999; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <div class="ml-20 transition-all duration-300 p-6 md:p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="font-heading text-3xl font-bold text-[#1E3A1D] mb-1">Invoices & Finance</h1>
                <p class="text-sm text-gray-500">Track receivables and record client payments.</p>
            </div>
            <div class="bg-white px-6 py-3 rounded-xl border border-gray-200 shadow-sm text-right">
                <p class="text-xs font-bold text-gray-400 uppercase">Total Collectibles</p>
                <p class="text-2xl font-bold text-red-600">₱<?= number_format($total_receivables, 2) ?></p>
            </div>
        </header>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase font-bold border-b border-gray-200">
                    <tr>
                        <th class="p-4 w-24">Invoice #</th>
                        <th class="p-4">Client</th>
                        <th class="p-4">Date Completed</th>
                        <th class="p-4 text-right">Total</th>
                        <th class="p-4 text-right">Paid</th>
                        <th class="p-4 text-right">Balance</th>
                        <th class="p-4 text-center">Status</th>
                        <th class="p-4 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 text-sm text-gray-700">
                    <?php if(empty($invoices)): ?>
                        <tr><td colspan="8" class="p-8 text-center text-gray-400 italic">No completed orders found.</td></tr>
                    <?php else: ?>
                        <?php foreach($invoices as $inv): 
                            $bal = $inv['total_amount'] - $inv['amount_paid'];
                        ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4 font-mono font-bold text-[#1E3A1D]">#<?= str_pad($inv['sale_id'], 5, '0', STR_PAD_LEFT) ?></td>
                            <td class="p-4 font-bold"><?= htmlspecialchars($inv['client_name'] ?? 'Unknown Client') ?></td>
                            <td class="p-4 text-gray-500"><?= $inv['delivered_at'] ? date('M d, Y', strtotime($inv['delivered_at'])) : '-' ?></td>
                            <td class="p-4 text-right font-bold">₱<?= number_format($inv['total_amount'], 2) ?></td>
                            <td class="p-4 text-right text-green-600">₱<?= number_format($inv['amount_paid'], 2) ?></td>
                            <td class="p-4 text-right font-bold text-red-500">₱<?= number_format($bal, 2) ?></td>
                            <td class="p-4 text-center"><span class="status-badge status-<?= $inv['payment_status'] ?>"><?= $inv['payment_status'] ?></span></td>
                            <td class="p-4 text-right">
                                <button onclick="openPaymentModal(<?= $inv['sale_id'] ?>)" class="bg-[#1E3A1D] text-white px-3 py-1.5 rounded text-xs font-bold hover:bg-[#2a4e29] shadow">Manage</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="paymentModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh] overflow-hidden">
            <div class="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <div>
                    <h2 class="text-xl font-bold text-[#1E3A1D]">Invoice #<span id="modal-invoice-id"></span></h2>
                    <p class="text-sm text-gray-500" id="modal-client">Client Name</p>
                </div>
                <button type="button" onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><span class="material-icons">close</span></button>
            </div>

            <div class="p-6 overflow-y-auto flex-grow" id="printArea">
                <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-100 mb-6 flex justify-between items-center">
                    <div>
                        <p class="text-xs text-gray-500 uppercase font-bold">Remaining Balance</p>
                        <p class="text-2xl font-bold text-red-600" id="modal-balance">₱0.00</p>
                    </div>
                    <div class="text-right">
                        <p class="text-xs text-gray-500 uppercase font-bold">Total Amount</p>
                        <p class="text-lg font-bold text-gray-800" id="modal-total">₱0.00</p>
                    </div>
                </div>

                <div class="mb-8 no-print">
                    <h3 class="font-bold text-gray-800 mb-3 text-sm uppercase">Record New Payment</h3>
                    <form id="paymentForm" class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input type="hidden" name="action" value="record_payment">
                        <input type="hidden" name="sale_id" id="form-sale-id">
                        
                        <div class="md:col-span-1">
                            <input type="number" name="amount" id="pay-amount" step="0.01" placeholder="Amount (₱)" class="w-full p-2 border border-gray-300 rounded focus:border-green-800 outline-none" required>
                        </div>
                        <div class="md:col-span-1">
                            <select name="method" class="w-full p-2 border border-gray-300 rounded focus:border-green-800 outline-none">
                                <option value="Cash">Cash</option>
                                <option value="Gcash">Gcash</option>
                                <option value="Check">Check</option>
                                <option value="Bank Transfer">Bank Transfer</option>
                            </select>
                        </div>
                        <div class="md:col-span-1">
                            <input type="text" name="reference" placeholder="Ref/Check No. (Optional)" class="w-full p-2 border border-gray-300 rounded focus:border-green-800 outline-none">
                        </div>
                        <div class="md:col-span-3">
                            <button type="submit" class="w-full bg-[#1E3A1D] text-white py-2 rounded font-bold hover:bg-[#162e15] shadow-sm">Submit Payment</button>
                        </div>
                    </form>
                </div>

                <div>
                    <h3 class="font-bold text-gray-800 mb-2 text-sm uppercase border-b pb-1">Payment History</h3>
                    <table class="w-full text-sm text-left">
                        <thead><tr class="text-gray-400"><th class="py-2">Date</th><th>Method</th><th>Ref</th><th class="text-right">Amount</th></tr></thead>
                        <tbody id="history-body" class="text-gray-700 divide-y divide-gray-100"></tbody>
                    </table>
                </div>
            </div>
            
            <div class="p-4 bg-gray-50 border-t border-gray-200 flex justify-between">
                <button onclick="window.print()" class="text-gray-600 hover:text-gray-900 font-bold flex items-center gap-2"><span class="material-icons text-sm">print</span> Print Statement</button>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700 font-bold">Close</button>
            </div>
        </div>
    </div>

    <script>
        const modal = document.getElementById('paymentModal');
        const historyBody = document.getElementById('history-body');

        function closeModal() { modal.classList.add('hidden'); }

        async function openPaymentModal(saleId) {
            document.getElementById('modal-invoice-id').textContent = String(saleId).padStart(5, '0');
            document.getElementById('form-sale-id').value = saleId;
            modal.classList.remove('hidden');
            
            // Fetch Details
            try {
                const formData = new FormData();
                formData.append('action', 'get_invoice_details');
                formData.append('sale_id', saleId);
                const res = await fetch('', { method: 'POST', body: formData }).then(r => r.json());
                
                if(res.success) {
                    const s = res.sale;
                    document.getElementById('modal-client').textContent = s.client_name || 'Unknown Client';
                    
                    const total = parseFloat(s.total_amount);
                    const paid = parseFloat(s.amount_paid);
                    const balance = total - paid;

                    document.getElementById('modal-total').textContent = '₱' + total.toLocaleString('en-US', {minimumFractionDigits:2});
                    document.getElementById('modal-balance').textContent = '₱' + balance.toLocaleString('en-US', {minimumFractionDigits:2});
                    document.getElementById('pay-amount').value = balance > 0 ? balance.toFixed(2) : ''; 

                    // Render History
                    historyBody.innerHTML = '';
                    if(res.payments.length === 0) {
                        historyBody.innerHTML = '<tr><td colspan="4" class="py-4 text-center text-gray-400 italic">No payments recorded yet.</td></tr>';
                    } else {
                        res.payments.forEach(p => {
                            historyBody.innerHTML += `
                                <tr>
                                    <td class="py-2">${new Date(p.payment_date).toLocaleDateString()}</td>
                                    <td><span class="bg-gray-100 px-2 py-0.5 rounded text-xs border border-gray-200">${p.payment_method}</span></td>
                                    <td class="text-gray-500 text-xs">${p.reference_no || '-'}</td>
                                    <td class="text-right font-bold text-green-700">₱${parseFloat(p.amount).toLocaleString('en-US', {minimumFractionDigits:2})}</td>
                                </tr>
                            `;
                        });
                    }
                }
            } catch(e) { console.error(e); alert("Error fetching data"); }
        }

        document.getElementById('paymentForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Double check logic (in case UI is bypassed)
            const amt = parseFloat(document.getElementById('pay-amount').value);
            const balStr = document.getElementById('modal-balance').textContent.replace(/[₱,]/g, '');
            const bal = parseFloat(balStr);
            
            if(amt > bal + 0.01) {
                alert("Payment amount cannot exceed remaining balance.");
                return;
            }

            if(!confirm("Confirm this payment?")) return;
            
            try {
                const res = await fetch('', { method: 'POST', body: new FormData(e.target) }).then(r => r.json());
                if(res.success) {
                    alert("Payment Recorded");
                    location.reload();
                } else {
                    alert(res.message);
                }
            } catch(e) { alert("Error processing"); }
        });
    </script>
</body>
</html>