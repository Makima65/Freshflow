<?php
// PHP Configuration and Setup
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include_once '../../includes/db_connection.php'; 

// --- CONNECTION CHECK ---
// This check only covers the initial page load. The AJAX check is below.
if (!isset($conn) || $conn->connect_error) {
    // If connection fails, we can still load the page, but show an error.
    $db_error = "Database connection failed. Error: " . (isset($conn) ? $conn->connect_error : 'Connection object $conn not found.');
} else {
    $db_error = null;
}


// --- Security Check (Admin Role Required) ---
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || !isset($_SESSION["role_name"]) || $_SESSION["role_name"] !== 'admin') {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        http_response_code(403);
        echo json_encode(['error' => 'Authentication required.']);
        exit;
    }
    header("location: ../admin_login.php");
    exit;
}

// Define possible ticket statuses
$available_statuses = ['Unresolved', 'Resolved', 'Replied', 'Closed'];

// --- Helper: Send Reply via Brevo ---
function send_brevo_reply($to, $subject, $reply_message)
{
    // Brevo API credentials
    $apiKey = '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';
    $fromEmail = 'autoporma76@gmail.com';
    $fromName  = 'Autoporma Customer Support';

    // Compose a professional support-style email
    $htmlContent = '
    <div style="font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px;">
        <div style="max-width: 600px; margin: auto; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <div style="background-color: #dc2626; padding: 15px 20px; color: white; font-size: 20px; font-weight: bold;">
                Autoporma Support Team
            </div>
            <div style="padding: 20px; color: #333;">
                <p>Dear Customer,</p>
                <p>We’ve received your inquiry and here’s our reply:</p>
                <div style="background-color: #f3f4f6; border-left: 4px solid #dc2626; padding: 15px; margin: 15px 0; white-space: pre-line;">
                    ' . nl2br(htmlspecialchars($reply_message)) . '
                </div>
                <p>If you have more questions, simply reply to this email or open your support ticket again.</p>
                <p>Best regards,<br><strong>Autoporma Customer Support</strong></p>
            </div>
            <div style="background-color: #f9fafb; padding: 15px; text-align: center; color: #777; font-size: 12px;">
                This message was sent by Autoporma Support • Please do not share sensitive information.
            </div>
        </div>
    </div>';

    // Build the API payload
    $data = [
        'sender' => [
            'name'  => $fromName,
            'email' => $fromEmail
        ],
        'to' => [
            ['email' => $to]
        ],
        'subject' => $subject,
        'htmlContent' => $htmlContent,
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.brevo.com/v3/smtp/email');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'content-type: application/json',
        'api-key: ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    // Parse response
    if ($error) {
        return ['success' => false, 'message' => 'cURL Error: ' . $error];
    }

    $result = json_decode($response, true);

    if ($httpCode === 201 && isset($result['messageId'])) {
        return ['success' => true, 'message' => 'Email sent successfully via Brevo.'];
    } else {
        return ['success' => false, 'message' => $result['message'] ?? 'Failed to send email.'];
    }
}

// =========================================================
// HANDLER FOR AJAX REQUESTS (fetch_tickets, update_status, send_reply, fetch_stats)
// =========================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_type'])) {
    header('Content-Type: application/json');

    // CRITICAL CHECK FOR DATABASE CONNECTION BEFORE PROCESSING
    if ($db_error) {
        http_response_code(503);
        echo json_encode(['success' => false, 'error' => $db_error]);
        exit;
    }

    try {
        if ($_POST['action_type'] === 'fetch_tickets') {
            // --- 1. FETCH TICKETS (List View) ---
            $page = filter_var($_POST['page'] ?? 1, FILTER_VALIDATE_INT);
            $search = trim($_POST['search'] ?? '');
            $status_filter = trim($_POST['status_filter'] ?? '');
            $tickets_per_page = 10;
            $offset = ($page - 1) * $tickets_per_page;

            $where_clauses = [];
            $params = [];
            $types = '';

            // Search Filter
            if (!empty($search)) {
                $where_clauses[] = "(subject LIKE ? OR message LIKE ? OR email LIKE ?)";
                $search_param = "%{$search}%";
                $params = array_merge($params, [$search_param, $search_param, $search_param]);
                $types .= 'sss';
            }

            // Status Filter
            if (!empty($status_filter) && in_array($status_filter, $available_statuses)) {
                $where_clauses[] = "status = ?";
                $params[] = $status_filter;
                $types .= 's';
            }

            $where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

            // Count total tickets for pagination
            $stmt_count = $conn->prepare("SELECT COUNT(*) FROM support_tickets {$where_sql}");
            if ($types) {
                // Fix: Use the splat operator for binding
                $stmt_count->bind_param($types, ...$params); 
            }
            $stmt_count->execute();
            $result_count = $stmt_count->get_result();
            $total_tickets = $result_count->fetch_row()[0];
            $total_pages = ceil($total_tickets / $tickets_per_page);
            $stmt_count->close();

            // Fetch tickets
            $sql = "SELECT ticket_id, name, email, subject, message, status, created_at, last_updated
                    FROM support_tickets {$where_sql}
                    ORDER BY status = 'New' DESC
                    LIMIT ? OFFSET ?";

            $params[] = $tickets_per_page;
            $params[] = $offset;
            $types .= 'ii';

            $stmt = $conn->prepare($sql);
            if ($stmt && $types) {
                // Fix: Use the splat operator for binding
                $stmt->bind_param($types, ...$params); 
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $tickets = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            echo json_encode([
                'success' => true,
                'tickets' => $tickets,
                'current_page' => $page,
                'total_pages' => $total_pages,
                'total_tickets' => $total_tickets
            ]);

        } elseif ($_POST['action_type'] === 'update_status' || $_POST['action_type'] === 'bulk_action') {
            // --- 2. UPDATE STATUS (Single or Bulk) ---
            $ticket_ids = $_POST['ticket_id'] ?? ($_POST['ticket_ids'] ?? []);
            $new_status = $_POST['new_status'] ?? '';

            if (!is_array($ticket_ids)) {
                $ticket_ids = [$ticket_ids]; // Handle single update
            }

            if (empty($ticket_ids) || !in_array($new_status, $available_statuses)) {
                throw new Exception('Invalid ticket ID(s) or status.');
            }

            // Create a comma-separated list of placeholders for the IN clause
            $placeholders = implode(',', array_fill(0, count($ticket_ids), '?'));
            $types = str_repeat('i', count($ticket_ids));

            $sql = "UPDATE support_tickets SET status = ?, last_updated = NOW() WHERE ticket_id IN ({$placeholders})";
            $stmt = $conn->prepare($sql);

            $params = array_merge([$new_status], $ticket_ids);
            $types = 's' . $types;
            
            // Fix: Use the splat operator for binding
            if ($stmt && $types) {
                $stmt->bind_param($types, ...$params);
            }
            
            $stmt->execute();
            $rows_affected = $stmt->affected_rows;
            $stmt->close();

            echo json_encode([
                'success' => true,
                'message' => "Successfully updated status for {$rows_affected} ticket(s) to '{$new_status}'.",
                'action' => $_POST['action_type']
            ]);

} elseif ($_POST['action_type'] === 'send_reply') {
    try {
        // --- 3. SEND REPLY AND UPDATE STATUS ---
        $ticket_id = filter_var($_POST['ticket_id'] ?? 0, FILTER_VALIDATE_INT);
        $recipient_email = trim($_POST['recipient_email'] ?? '');
        $reply_message = trim($_POST['reply_message'] ?? '');
        $new_status = $_POST['new_status'] ?? 'Replied';

        if (!$ticket_id || empty($recipient_email) || empty($reply_message) || !in_array($new_status, $available_statuses)) {
            throw new Exception('Missing required reply data.');
        }

        // A) Send Email via Brevo
        $subject = "Re: Your Support Ticket #{$ticket_id}";
        $brevo_result = send_brevo_reply($recipient_email, $subject, $reply_message);

        if ($brevo_result['success']) {
            // B) Update Ticket Status
            $sql = "UPDATE support_tickets SET status = ?, last_updated = NOW() WHERE ticket_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('si', $new_status, $ticket_id);
            $stmt->execute();
            $stmt->close();

            echo json_encode([
                'success' => true,
                'message' => 'Reply sent successfully and ticket status updated.',
                'brevo_message' => $brevo_result['message']
            ]);
        } else {
            throw new Exception("Reply failed: {$brevo_result['message']}");
        }
    } catch (Exception $e) {
        // Handle all reply-related errors
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }

        } elseif ($_POST['action_type'] === 'fetch_stats') {
            // --- 4. FETCH STATISTICS (NEW) ---
            
            // Total Tickets
            $stmt_total = $conn->prepare("SELECT COUNT(*) FROM support_tickets");
            $stmt_total->execute();
            $result_total = $stmt_total->get_result();
            $total = $result_total->fetch_row()[0];
            $stmt_total->close();

            // Total Unresolved (New + Open)
            $stmt_unresolved = $conn->prepare("SELECT COUNT(*) FROM support_tickets WHERE status IN ('Unresolved')");
            $stmt_unresolved->execute();
            $result_unresolved = $stmt_unresolved->get_result();
            $unresolved = $result_unresolved->fetch_row()[0];
            $stmt_unresolved->close();

            // Total Pending (Replied - Waiting for user)
            $stmt_pending = $conn->prepare("SELECT COUNT(*) FROM support_tickets WHERE status = 'Replied'");
            $stmt_pending->execute();
            $result_pending = $stmt_pending->get_result();
            $pending = $result_pending->fetch_row()[0];
            $stmt_pending->close();

            // Total (Closed)
            $stmt_closed = $conn->prepare("SELECT COUNT(*) FROM support_tickets WHERE status = 'Closed'");
            $stmt_closed->execute();
            $result_closed = $stmt_closed->get_result();
            $closed = $result_closed->fetch_row()[0];
            $stmt_closed->close();

            echo json_encode([
                'success' => true,
                'stats' => [
                    'total' => $total,
                    'unresolved' => $unresolved,
                    'pending' => $pending, 
                    'closed' => $closed,
                ]
            ]);

        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action type.']);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Support Tickets</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script type="module">
        import { createIcons, Search, X, MessageSquare, CheckCircle, Clock, Trash2, Edit, ListChecks } from 'https://unpkg.com/lucide@latest';
        createIcons({ icons: { Search, X, MessageSquare, CheckCircle, Clock, Trash2, Edit, ListChecks } });
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Roboto+Mono:wght@400;700&display=swap');

        /* NEW BASE STYLES */
        body { font-family: 'Inter', sans-serif; background-color: #000000; color: #f1f5f9; }
        .font-heading { font-family: 'Roboto Mono', monospace; }
        .dot-texture-background { background-color: #000000; background-image: radial-gradient(circle, rgba(255, 255, 255, 0.07) 1px, transparent 1px); background-size: 12px 12px; }
        .content-card { background-color: rgba(15, 23, 42, 0.5); border: 1px solid rgba(51, 65, 85, 0.5); backdrop-filter: blur(8px); }
        .modal-card { background-color: rgba(15, 23, 42, 0.8); border: 1px solid rgba(51, 65, 85, 0.7); backdrop-filter: blur(12px); }

        /* INPUTS/SELECTS */
        .form-input, .form-select, .form-textarea, .filter-select { 
            background-color: #1f2937; 
            border: 1px solid #4b5563; 
            color: #d1d5db; 
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out; 
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus, .filter-select:focus { 
            outline: none; 
            border-color: #ef4444; 
            box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.5); 
        }
        .form-input.is-invalid { border-color: #ef4444; }

        /* STATUS BADGES */
        .status-badge { padding: 2px 8px; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; }
        .status-new { background-color: rgba(239, 68, 68, 0.1); color: #ef4444; } /* Red (New/Urgent) */
        .status-open { background-color: rgba(249, 115, 22, 0.1); color: #f97316; } /* Orange (Open/In Progress) */
        .status-replied { background-color: rgba(60, 150, 200, 0.1); color: #3c96c8; } /* Light Blue (Pending/Replied) */
        .status-closed { background-color: rgba(34, 197, 94, 0.1); color: #22c55e; } /* Green (Closed/Resolved) */
        
        /* TABLE & SCROLLBAR */
        .table-header-bg { background-color: #334155; } /* slate-700 */
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background-color: #475569; border-radius: 10px; } /* slate-600 */
        
        /* MODAL */
        #replyModal { background-color: rgba(0, 0, 0, 0.7); } /* Keep the dark backdrop */
        .modal { transition: opacity 0.3s ease; }
        .modal-content { transition: opacity 0.3s ease, transform 0.3s ease; max-height: 90vh; }
        .modal.hidden { opacity: 0; pointer-events: none; }
        .modal.hidden .modal-content { opacity: 0; transform: translateY(-20px) scale(0.95); }
        
        /* MISC */
        .error-message { color: #fca5a5; font-size: 0.875rem; margin-top: 0.25rem; min-height: 1.25rem; }
        label.required::after { content: '*'; color: #ef4444; margin-left: 0.25rem; }
    </style>
</head>
<body class="flex flex-col h-screen overflow-hidden dot-texture-background">
    
    <?php include '../includes/sidebar.php'; ?>
    
    <div id="messageBox" class="fixed z-[100] p-4 rounded-lg shadow-xl text-white transition-opacity duration-300 opacity-0 hidden"></div>
    <div class="flex flex-col flex-1 overflow-y-auto lg:pl-20 transition-all duration-300">
        <main class="flex-1 p-4 sm:p-6"> <div class="max-w-8xl mx-auto">
                <header class="pb-6 mb-6">
                    <div class="flex justify-between items-center border-b border-slate-700 pb-2">
                        <h1 class="text-3xl font-extrabold text-white flex items-center">
                            <i data-lucide="message-square" class="inline w-7 h-7 mr-2 text-red-600"></i>Support Ticket Management
                        </h1>
                        <?php include_once '../includes/low_stock_notif.php'; ?>
                    </div>
                </header>
                <?php if ($db_error): ?>
                    <div class="bg-red-900 border-l-4 border-red-500 text-white p-4 mb-6 rounded-xl shadow-md" role="alert">
                        <p class="font-bold">Initialization Error</p>
                        <p class="text-sm">Cannot connect to the database. Tickets cannot be loaded. Please check your <code>db_connection.php</code> file. Details: <?= htmlspecialchars($db_error) ?></p>
                    </div>
                <?php endif; ?>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6" id="statsContainer">
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                </div>

                <div class="content-card p-4 sm:p-6 rounded-xl shadow-lg">
                    <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-4">
                        <div class="relative flex-1 max-w-sm">
                            <input type="text" id="searchInput" placeholder="Search by email, subject..." class="form-input w-full pl-10 pr-4 py-2 rounded-lg">
                            <i data-lucide="search" class="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400"></i>
                        </div>
                        <select id="statusFilter" class="form-select filter-select rounded-lg w-full sm:w-auto">
                            <option value="">All Statuses</option>
                            <?php foreach ($available_statuses as $status): ?>
                                <option value="<?= htmlspecialchars($status) ?>"><?= htmlspecialchars($status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div id="bulkActionContainer" class="hidden mb-4 p-4 bg-slate-800 rounded-lg flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                        <span id="selectionCount" class="text-white font-medium">0 selected</span>
                        <div class="flex gap-4">
                            <select id="bulkActionSelect" class="form-select filter-select rounded-lg">
                                <option value="">Bulk Action</option>
                                <?php foreach ($available_statuses as $status): ?>
                                    <option value="<?= htmlspecialchars($status) ?>">Mark as <?= htmlspecialchars($status) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button id="applyBulkAction" class="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150">Apply</button>
                        </div>
                    </div>

                    <div class="overflow-x-auto custom-scrollbar">
                        <table class="min-w-full divide-y divide-slate-800">
                            <thead class="table-header-bg">
                                <tr>
                                    <th class="px-6 py-3 text-left w-12">
                                        <input type="checkbox" id="selectAllCheckbox" class="rounded bg-slate-700 border-slate-600 focus:ring-red-500 text-red-600">
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider w-20">ID</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider w-64">Subject</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Requester</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider w-32">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider w-40">Created</th>
                                    <th class="px-6 py-3 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider w-40">Updated</th>
                                    <th class="px-6 py-3 text-right text-xs font-semibold text-slate-300 uppercase tracking-wider w-24">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="ticketsTableBody" class="divide-y divide-slate-700">
                                <tr><td colspan="8" class="text-center py-8 text-red-500 font-semibold"><i data-lucide="clock" class="inline w-5 h-5 mr-2 animate-spin"></i>Loading tickets...</td></tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div id="paginationControls" class="mt-6 flex justify-between items-center content-card p-4 rounded-xl shadow-md">
                    </div>
                </div>
            </main>
    </div>
    
    <div id="replyModal" class="modal fixed inset-0 bg-gray-900 bg-opacity-70 flex justify-center items-center z-50 overflow-y-auto hidden" onclick="closeReplyModal(event)">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="modal-card rounded-xl shadow-2xl w-full max-w-4xl transform transition-all duration-300 scale-95 modal-content" onclick="event.stopPropagation()">
                <div class="p-6 border-b border-slate-700 flex justify-between items-center">
                    <h3 class="text-xl font-bold text-white flex items-center">
                        <i data-lucide="message-square" class="w-5 h-5 mr-2 text-red-600"></i>Reply to Ticket #<span id="modalTicketId"></span>
                    </h3>
                    <button class="text-slate-400 hover:text-white" onclick="closeReplyModal(event)">
                        <i data-lucide="x" class="w-6 h-6"></i>
                    </button>
                </div>
                
                <form id="replyForm">
                    <input type="hidden" id="modalTicketIdInput" name="ticket_id">
                    <input type="hidden" id="modalRecipientEmail" name="recipient_email">
                    
                    <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto custom-scrollbar max-h-[70vh]">
                        <div class="md:col-span-2 space-y-4">
                            <div>
                                <label for="replyMessage" class="block text-sm font-semibold text-slate-300 mb-2 required">Your Reply</label>
                                <textarea id="replyMessage" name="reply_message" rows="12" class="form-textarea w-full rounded-lg" required></textarea>
                                <p id="replyMessageError" class="error-message"></p>
                            </div>
                            
                            <div>
                                <label for="newStatus" class="block text-sm font-semibold text-slate-300 mb-2 required">Set Status After Reply</label>
                                <select id="newStatus" name="new_status" class="form-select w-full rounded-lg">
                                    <?php foreach ($available_statuses as $status): ?>
                                        <option value="<?= htmlspecialchars($status) ?>" <?= $status === 'Replied' ? 'selected' : '' ?>><?= htmlspecialchars($status) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="bg-slate-800 p-4 rounded-lg border border-slate-700">
                                <h4 class="font-semibold text-white mb-2">Original Message</h4>
                                <p class="text-sm text-slate-400 mb-1"><strong>From:</strong> <span id="modalEmail"></span></p>
                                <p class="text-sm text-slate-400 mb-2"><strong>Subject:</strong> <span id="modalSubject"></span></p>
                                <div class="bg-slate-900 p-3 rounded-md max-h-60 overflow-y-auto custom-scrollbar">
                                    <p id="modalMessage" class="text-sm text-slate-300 whitespace-pre-wrap"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-6 border-t border-slate-700 bg-slate-800/50 rounded-b-xl flex justify-end items-center gap-4">
                        <div id="replyFeedback" class="text-sm flex-1"></div>
                        <button type="button" class="py-2 px-4 rounded-lg text-slate-300 hover:bg-slate-700 transition" onclick="closeReplyModal(event)">Cancel</button>
                        <button id="replySubmitBtn" type="submit" class="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition duration-150 flex items-center justify-center min-w-[120px]">
                            <span id="replyBtnText">Send Reply</span>
                            <span id="replyBtnLoading" class="hidden">
                                <i data-lucide="clock" class="w-4 h-4 animate-spin"></i>
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // --- Globals ---
        const API_ENDPOINT = 'support_ticket.php'; 
        const ticketsTableBody = document.getElementById('ticketsTableBody');
        const paginationControls = document.getElementById('paginationControls');
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        const bulkActionContainer = document.getElementById('bulkActionContainer');
        const selectionCountSpan = document.getElementById('selectionCount');
        const bulkActionSelect = document.getElementById('bulkActionSelect');
        const replyModal = document.getElementById('replyModal');
        const replyForm = document.getElementById('replyForm');
        const replySubmitBtn = document.getElementById('replySubmitBtn');
        const statsContainer = document.getElementById('statsContainer'); // NEW
        const dbError = <?= json_encode((bool)$db_error) ?>;
        
        let currentPage = 1;
        let totalTickets = { value: 0 }; // Use object to pass by reference for renderPagination
        
        // Utility to replace alert()
        function showMessage(message, type = 'success') {
            const box = document.getElementById('messageBox');
            box.textContent = message;
            box.className = 'fixed top-4 right-4 z-[100] p-4 rounded-lg shadow-xl text-white transition-opacity duration-300 opacity-0 hidden';
            
            // Updated colors for dark theme consistency (red for error, green for success)
            if (type === 'success') {
                box.classList.add('bg-green-600');
            } else if (type === 'error') {
                box.classList.add('bg-red-600');
            } else {
                box.classList.add('bg-red-600'); // Use primary accent for general info
            }
            
            box.classList.remove('hidden', 'opacity-0');
            box.classList.add('opacity-100');
            
            setTimeout(() => {
                box.classList.remove('opacity-100');
                box.classList.add('opacity-0');
                setTimeout(() => box.classList.add('hidden'), 300);
            }, 5000);
        }

        // --- Status Badge Helpers ---
        const getStatusClass = (status) => {
            // Note: The new CSS uses .status-[status_name] classes
            switch (status) {
                case 'Unresolved': return 'status-new';
                case 'Resolved': return 'status-closed';
                case 'Replied': return 'status-replied';
                case 'Closed': return 'status-closed';
                default: return 'status-open'; // Fallback for 'Open' or others
            }
        };
        
        // --- Core Data Fetching ---
        const loadTickets = async (page = 1) => {
            if (dbError) {
                ticketsTableBody.innerHTML = '<tr><td colspan="8" class="text-center py-8 text-red-500 font-semibold">Cannot load tickets due to Database Connection Error.</td></tr>';
                return;
            }
            
            ticketsTableBody.innerHTML = '<tr><td colspan="8" class="text-center py-8 text-slate-400"><i data-lucide="clock" class="inline w-5 h-5 mr-2 animate-spin"></i>Loading tickets...</td></tr>';
            if (window.lucide) lucide.createIcons();
            
            const formData = new FormData();
            formData.append('action_type', 'fetch_tickets');
            formData.append('page', page);
            formData.append('search', searchInput.value);
            formData.append('status_filter', statusFilter.value);
            
            try {
                const response = await fetch(API_ENDPOINT, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                
                if (!response.ok) {
                    throw new Error(`Server responded with HTTP ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.success) {
                    currentPage = data.current_page;
                    totalTickets.value = data.total_tickets;
                    renderTableBody(data.tickets);
                    renderPagination(data.current_page, data.total_pages);
                } else {
                    throw new Error(data.error || 'Failed to fetch tickets.');
                }
                
            } catch (error) {
                console.error('Error loading tickets:', error);
                ticketsTableBody.innerHTML = `<tr><td colspan="8" class="text-center py-8 text-red-500 font-semibold">Failed to load data. Details: ${error.message}</td></tr>`;
            }
        };
        
        // --- New Function to Load Stats ---
        const loadStats = async () => {
             if (dbError) {
                statsContainer.innerHTML = '<p class="text-red-500 col-span-4">Cannot load statistics due to Database Connection Error.</p>';
                return;
            }
            
            // Keep loading pulse if already running
            if (statsContainer.querySelector('.animate-pulse')) {
                // Do nothing, let the existing pulse animation run
            } else {
                // Initial load: create a temporary pulse
                statsContainer.innerHTML = `
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                    <div class="content-card p-5 rounded-xl shadow-lg border-slate-700 animate-pulse h-28"></div>
                `;
            }

            const formData = new FormData();
            formData.append('action_type', 'fetch_stats');

            try {
                const response = await fetch(API_ENDPOINT, { 
                    method: 'POST', 
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' } 
                });
                
                if (!response.ok) {
                    throw new Error(`Server responded with HTTP ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.success) {
                    renderStats(data.stats);
                } else {
                    throw new Error(data.error || 'Failed to fetch statistics.');
                }
            } catch (error) {
                console.error('Error loading stats:', error);
                statsContainer.innerHTML = `<p class="text-red-500 col-span-4">Failed to load statistics: ${error.message}</p>`;
            }
        };

        const renderStats = (stats) => {
            const statData = [
                // Icon: list-checks for Total, message-square for unresolved, clock for pending, check-circle for closed
                { title: 'Total Tickets', value: stats.total, icon: 'list-checks', color: 'text-slate-300' },
                { title: 'Unresolved', value: stats.unresolved, icon: 'message-square', color: 'text-red-500' },
                { title: 'Pending Reply', value: stats.pending, icon: 'clock', color: 'text-blue-400' },
                { title: 'Closed / Resolved', value: stats.closed, icon: 'check-circle', color: 'text-green-500' }
            ];

            statsContainer.innerHTML = statData.map(stat => `
                <div class="content-card p-5 rounded-xl shadow-lg border-slate-700">
                    <div class="flex items-center justify-between">
                        <span class="text-sm font-medium text-slate-400">${stat.title}</span>
                        <i data-lucide="${stat.icon}" class="w-5 h-5 ${stat.color}"></i>
                    </div>
                    <p class="text-3xl font-extrabold ${stat.color} mt-2">${stat.value}</p>
                </div>
            `).join('');
            
            if (window.lucide) lucide.createIcons();
        };

        // --- Rendering Functions ---
        const renderTicketRow = (ticket) => {
            const statusClass = getStatusClass(ticket.status);
            
            return `
                <tr class="hover:bg-slate-800/50 transition duration-150">
                    <td class="px-6 py-4">
                        <input type="checkbox" value="${ticket.ticket_id}" class="row-checkbox rounded bg-slate-700 border-slate-600 focus:ring-red-500 text-red-600">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">${ticket.ticket_id}</td>
                    <td class="px-6 py-4 truncate max-w-xs text-white" title="${ticket.subject}">${ticket.subject}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-400">${ticket.email}</td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="status-badge ${statusClass}">
                            ${ticket.status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-400">${new Date(ticket.created_at).toLocaleString()}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-400">${ticket.last_updated ? new Date(ticket.last_updated).toLocaleString() : 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onclick="openReplyModal(${ticket.ticket_id}, '${ticket.email}', \`${ticket.subject.replace(/`/g, "\\`")}\`, \`${ticket.message.replace(/\n/g, "\\n").replace(/`/g, "\\`")}\`, '${ticket.status}')" class="bg-red-600 hover:bg-red-700 text-white font-medium py-1.5 px-3 rounded-lg inline-flex items-center transition duration-150 text-xs">
                            <i data-lucide="message-square" class="w-4 h-4 mr-1"></i>Reply
                        </button>
                    </td>
                </tr>
            `;
        };

        const renderTableBody = (tickets) => {
            if (tickets.length === 0) {
                ticketsTableBody.innerHTML = '<tr><td colspan="8" class="text-center py-8 text-slate-400">No tickets found matching your criteria.</td></tr>';
                bulkActionContainer.classList.add('hidden');
                selectAllCheckbox.checked = false;
                return;
            }
            
            ticketsTableBody.innerHTML = tickets.map(renderTicketRow).join('');
            
            // Recreate icons after injecting new HTML
            if (window.lucide) lucide.createIcons();
            
            // Re-attach event listeners for checkboxes
            document.querySelectorAll('.row-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', updateBulkActionVisibility);
            });
            
            // Reset bulk actions
            updateBulkActionVisibility();
        };

        const renderPagination = (currentPage, totalPages) => {
            // New dark theme pagination styles
            const btnClass = "relative inline-flex items-center px-4 py-2 border border-slate-700 bg-slate-800 text-sm font-medium text-slate-300 hover:bg-slate-700 transition";
            
            if (totalPages <= 1) {
                paginationControls.innerHTML = `<p class="text-sm text-slate-400">Showing ${totalTickets.value} results.</p>`;
                return;
            }
            
            let html = `<p class="text-sm text-slate-400 hidden sm:block">Page ${currentPage} of ${totalPages} (Total: ${totalTickets.value} tickets)</p>`;
            html += `<nav class="relative z-0 inline-flex rounded-lg shadow-sm -space-x-px" aria-label="Pagination">`;
            
            html += `<button onclick="loadTickets(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''} class="${btnClass} rounded-l-lg ${currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''}">Previous</button>`;
            
            // Simple pagination (Prev/Next only for mobile, full for desktop)
            // This example keeps it simple, but you could add page numbers here.
            
            html += `<button onclick="loadTickets(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''} class="${btnClass} rounded-r-lg ${currentPage === totalPages ? 'opacity-50 cursor-not-allowed' : ''}">Next</button>`;
            html += `</nav>`;
            
            paginationControls.innerHTML = html;
        };
        
        // --- Bulk Actions Logic ---
        const toggleSelectAll = () => {
            const isChecked = selectAllCheckbox.checked;
            document.querySelectorAll('.row-checkbox').forEach(checkbox => {
                checkbox.checked = isChecked;
            });
            updateBulkActionVisibility();
        };

        const updateBulkActionVisibility = () => {
            const selectedCount = document.querySelectorAll('.row-checkbox:checked').length;
            selectionCountSpan.textContent = `${selectedCount} selected`;
            
            if (selectedCount > 0) {
                bulkActionContainer.classList.remove('hidden');
            } else {
                bulkActionContainer.classList.add('hidden');
                selectAllCheckbox.checked = false; // Uncheck select all if nothing is selected
            }
        };

        const applyBulkAction = async () => {
            const actionType = bulkActionSelect.value;
            const ticketIds = Array.from(document.querySelectorAll('.row-checkbox:checked')).map(cb => cb.value);
            
            if (!actionType) {
                showMessage('Please select a bulk action.', 'error');
                return;
            }
            
            if (ticketIds.length === 0) {
                showMessage('Please select at least one ticket.', 'error');
                return;
            }
            
            if (!confirm(`Are you sure you want to mark ${ticketIds.length} ticket(s) as ${actionType}?`)) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action_type', 'bulk_action');
            formData.append('new_status', actionType);
            ticketIds.forEach(id => formData.append('ticket_ids[]', id));
            
            try {
                const response = await fetch(API_ENDPOINT, { 
                    method: 'POST', 
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' } 
                });
                const data = await response.json();
                
                if (data.success) {
                    showMessage(data.message, 'success');
                    loadTickets(currentPage); // Reload current page
                    loadStats(); // NEW: Refresh stats
                } else {
                    throw new Error(data.error || 'Bulk action failed.');
                }
            } catch (error) {
                showMessage(error.message, 'error');
            }
        };

        // --- Modal Logic ---
        window.openReplyModal = (ticket_id, email, subject, message, status) => {
            document.getElementById('modalTicketId').textContent = ticket_id;
            document.getElementById('modalTicketIdInput').value = ticket_id;
            document.getElementById('modalRecipientEmail').value = email;
            document.getElementById('modalEmail').textContent = email;
            document.getElementById('modalSubject').textContent = subject;
            document.getElementById('modalMessage').textContent = message;
            document.getElementById('replyMessage').value = '';
            document.getElementById('newStatus').value = 'Replied';
            
            // Clear feedback
            document.getElementById('replyFeedback').textContent = '';
            document.getElementById('replyMessageError').textContent = '';
            document.getElementById('replyMessage').classList.remove('is-invalid');
            
            // Show modal
            replyModal.classList.remove('hidden');
            setTimeout(() => {
                replyModal.classList.add('opacity-100');
                document.querySelector('.modal-content').classList.remove('scale-95');
                document.querySelector('.modal-content').classList.remove('translate-y-[-20px]');
            }, 10);
        };

        window.closeReplyModal = (event) => {
            // Only close if the click is on the backdrop
            if (event.target.id === 'replyModal' || event.target.closest('button').textContent === 'Cancel' || event.target.closest('button').querySelector('i[data-lucide="x"]')) {
                // Add classes for closing transition
                document.querySelector('.modal-content').classList.add('scale-95');
                document.querySelector('.modal-content').classList.add('translate-y-[-20px]');
                replyModal.classList.remove('opacity-100');
                
                // Hide completely after transition
                setTimeout(() => {
                    replyModal.classList.add('hidden');
                }, 300);
            }
        };

        const submitReplyForm = async (e) => {
            e.preventDefault();
            
            replySubmitBtn.disabled = true;
            document.getElementById('replyBtnText').classList.add('hidden');
            document.getElementById('replyBtnLoading').classList.remove('hidden');
            
            const formData = new FormData(replyForm);
            formData.append('action_type', 'send_reply');
            
            const replyFeedback = document.getElementById('replyFeedback');
            const replyMessageError = document.getElementById('replyMessageError');
            const replyMessageInput = document.getElementById('replyMessage');
            
            // Clear previous errors
            replyFeedback.textContent = '';
            replyMessageError.textContent = '';
            replyMessageInput.classList.remove('is-invalid');
            
            // Basic validation
            if (!formData.get('reply_message').trim()) {
                replyMessageError.textContent = 'Reply message cannot be empty.';
                replyMessageInput.classList.add('is-invalid');
                replySubmitBtn.disabled = false;
                document.getElementById('replyBtnText').classList.remove('hidden');
                document.getElementById('replyBtnLoading').classList.add('hidden');
                return;
            }

            try {
                const response = await fetch(API_ENDPOINT, { 
                    method: 'POST', 
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' } 
                });
                const data = await response.json();
                
                if (data.success) {
                    replyFeedback.textContent = 'Reply sent successfully!';
                    replyFeedback.className = 'text-green-400 text-sm';
                    
                    setTimeout(() => {
                        closeReplyModal({ target: { id: 'replyModal' } });
                        loadTickets(currentPage); // Reload tickets
                        loadStats(); // NEW: Refresh stats
                    }, 2000);
                    
                } else {
                    throw new Error(data.error || 'Failed to send reply.');
                }
            } catch (error) {
                console.error('Reply Error:', error);
                replyFeedback.textContent = error.message;
                replyFeedback.className = 'text-red-400 text-sm';
                // showMessage('Network error during reply submission.', 'error');
            } finally {
                replySubmitBtn.disabled = false;
                document.getElementById('replyBtnText').classList.remove('hidden');
                document.getElementById('replyBtnLoading').classList.add('hidden');
            }
        };
        
        // --- Initial Load and Event Attachments ---
        document.addEventListener('DOMContentLoaded', () => {
            loadStats(); // NEW: Load statistics first
            loadTickets();

            // Debounced search for better performance
            let searchTimeout;
            searchInput.addEventListener('input', () => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => loadTickets(1), 500);
            });
            
            // Attach form submission handler
            replyForm.addEventListener('submit', submitReplyForm);
            
            // Attach bulk action handler
            document.getElementById('applyBulkAction').addEventListener('click', applyBulkAction);
            
            // Attach select all handler (already handled in renderTableBody, but here for safety)
            selectAllCheckbox.addEventListener('change', toggleSelectAll);
            
            // Attach event listener on filter change
            statusFilter.addEventListener('change', () => loadTickets(1));
            
        });
    </script>
</body>
</html>