<?php
// C:\xampp\htdocs\RalphPHP\admin_components\includes\sidebar.php

// 1. Get current page name to highlight the active link
$currentPage = basename($_SERVER['PHP_SELF']);

// 2. PATH CORRECTION LOGIC
if (strpos($_SERVER['PHP_SELF'], '/pages/') !== false) {
    $path_to_pages = '';           
    $path_to_admin_root = '../';   
    $path_to_components = '../';   
} else {
    $path_to_pages = 'pages/';
    $path_to_admin_root = '';
    $path_to_components = '';
}
?>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&display=swap" rel="stylesheet">

<style>
    :root {
        --brand-green: #1E3A1D;
        --brand-cream: #F8F5EE;
        --brand-gold: #D4AF37;
    }

    #sidebar {
        font-family: 'Roboto Mono', monospace;
        background-color: var(--brand-green);
        transition: width 0.3s ease-in-out;
        box-shadow: 4px 0 15px rgba(0,0,0,0.2);
        overflow-x: hidden;
        white-space: nowrap;
        display: flex;
        flex-direction: column;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 50;
    }

    #sidebar-nav::-webkit-scrollbar { display: none; }
    #sidebar-nav { -ms-overflow-style: none; scrollbar-width: none; overflow-y: auto; }

    .sidebar-collapsed { width: 5rem; } 
    .sidebar-expanded { width: 17rem; } 

    #burgerBtn svg { transition: transform 0.3s ease; }
    .sidebar-expanded #burgerBtn svg { transform: rotate(180deg); }

    .sidebar-link {
        color: #aebfab;
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        margin-bottom: 0.25rem;
        border-radius: 0.5rem;
        transition: all 0.2s ease;
        text-decoration: none;
        height: 3rem;
        flex-shrink: 0;
    }

    .sidebar-link:hover {
        background-color: rgba(255, 255, 255, 0.08);
        color: #ffffff;
        padding-left: 1.25rem;
    }

    .sidebar-link.active {
        background-color: var(--brand-cream);
        color: var(--brand-green);
        font-weight: 700;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    
    .sidebar-link.active::before {
        content: '';
        position: absolute;
        left: 0;
        height: 2rem;
        width: 4px;
        background-color: var(--brand-gold);
        border-radius: 0 4px 4px 0;
    }

    .material-icons {
        font-size: 24px;
        min-width: 24px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .nav-text {
        margin-left: 1rem;
        opacity: 0;
        transition: opacity 0.2s ease;
        visibility: hidden;
    }

    .sidebar-expanded .nav-text { opacity: 1; visibility: visible; }

    .brand-title, .section-label {
        opacity: 0;
        transition: opacity 0.2s;
        visibility: hidden;
    }
    .sidebar-expanded .brand-title, 
    .sidebar-expanded .section-label { opacity: 1; visibility: visible; }

    .section-label {
        font-size: 0.7rem;
        text-transform: uppercase;
        color: #6b8c6a;
        margin: 1rem 0 0.5rem 1.25rem;
        font-weight: bold;
        flex-shrink: 0;
    }
    
    .nav-separator {
        border-top: 1px solid rgba(255,255,255,0.1);
        margin: 0.5rem 0.5rem;
        flex-shrink: 0;
    }
</style>

<aside id="sidebar" class="sidebar-collapsed text-slate-400">
    
    <div class="flex items-center p-4 mb-2 flex-shrink-0">
        <button id="burgerBtn" class="text-gray-300 hover:text-white focus:outline-none p-1 rounded-md hover:bg-white/10">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
        </button>
        <h1 class="brand-title text-xl font-bold ml-3 text-white tracking-tighter overflow-hidden">FRESHFLOW</h1>
    </div>

    <nav id="sidebar-nav" class="flex flex-col flex-grow px-2 space-y-1">
        <?php
        if (!function_exists('create_nav_link')) {
            function create_nav_link($page, $title, $icon_name) {
                global $path_to_pages, $currentPage;
                $isActive = ($currentPage == $page);
                $activeClass = $isActive ? 'active' : '';
                $href = "{$path_to_pages}{$page}";
                echo "
                <a href='{$href}' class='sidebar-link relative {$activeClass}'>
                    <span class='material-icons'>{$icon_name}</span>
                    <span class='nav-text'>{$title}</span>
                </a>";
            }
        }

        // 1. DASHBOARD
        create_nav_link('dashboard.php', 'Dashboard', 'dashboard');
        
        echo '<div class="nav-separator"></div>'; 
        
        // 2. ORDER FULFILLMENT
        echo '<div class="section-label">Order Fulfillment</div>';
        create_nav_link('order_create.php', 'Create Order', 'add_shopping_cart'); 
        create_nav_link('order_queue.php', 'Order Queue', 'checklist_rtl'); 
        create_nav_link('dispatch.php', 'Dispatch / Delivery', 'local_shipping'); 
        create_nav_link('returns.php', 'Returns & Rejects', 'assignment_return');
        
        echo '<div class="nav-separator"></div>'; 

        // 3. CLIENTS
        echo '<div class="section-label">Clients</div>';
        create_nav_link('clients.php', 'Client Directory', 'business');
        create_nav_link('pricing_agreements.php', 'Pricing Agreements', 'handshake'); 

        echo '<div class="nav-separator"></div>'; 

        // 4. INVENTORY & SUPPLY
        echo '<div class="section-label">Inventory & Supply</div>';
        create_nav_link('products.php', 'Product List', 'inventory_2');
        create_nav_link('inventory.php', 'Stock Management', 'warehouse');
        create_nav_link('purchase_orders.php', 'Purchase Orders', 'shopping_bag'); 
        create_nav_link('suppliers.php', 'Supplier List', 'local_shipping'); 
        
        echo '<div class="nav-separator"></div>'; 

        // 5. FINANCE
        echo '<div class="section-label">Finance</div>';
        create_nav_link('invoices.php', 'Invoices', 'receipt_long'); 
        create_nav_link('expenses.php', 'Expenses', 'money_off'); 
        create_nav_link('cash_flow.php', 'Cash Flow', 'account_balance_wallet'); 

        echo '<div class="nav-separator"></div>'; 

        // 6. REPORTS & ANALYTICS
        echo '<div class="section-label">Reports & Analytics</div>';
        // --- EXISTING FORECAST (Short Term) ---
        create_nav_link('forecast.php', 'Sales Forecast (AI)', 'trending_up'); 
        
        // --- NEW SEASONAL PLANNER (Long Term) ---
        // I added this right here to satisfy the "Yearly Plan" requirement
        create_nav_link('analytics_seasonal.php', 'Seasonal Planner', 'calendar_month'); 
        
        create_nav_link('reports_bestsellers.php', 'Best Selling Items', 'star'); 
        create_nav_link('spoilage.php', 'Spoilage Report', 'delete_forever'); 

        echo '<div class="nav-separator"></div>'; 
        
        // 7. SYSTEM
        if (isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'admin') {
            echo '<div class="section-label">System</div>';
            create_nav_link('users.php', 'User Management', 'group');
            create_nav_link('audit_logs.php', 'Audit Logs', 'history');
        }
        ?>
    </nav>
    
    <div class="p-2 border-t border-white/10 mt-auto mb-4 flex-shrink-0">
        <?php create_nav_link('settings.php', 'Settings', 'settings'); ?>
        <a href="<?php echo $path_to_components; ?>logout.php" class="sidebar-link relative hover:bg-red-900/30 hover:text-red-300">
            <span class="material-icons">logout</span>
            <span class="nav-text">Logout</span>
        </a>
    </div>
</aside>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const burgerBtn = document.getElementById('burgerBtn');
        const sidebar = document.getElementById('sidebar');

        if(burgerBtn && sidebar) {
            burgerBtn.addEventListener('click', () => {
                if (sidebar.classList.contains('sidebar-collapsed')) {
                    sidebar.classList.replace('sidebar-collapsed', 'sidebar-expanded');
                } else {
                    sidebar.classList.replace('sidebar-expanded', 'sidebar-collapsed');
                }
            });
        }
    });
</script>