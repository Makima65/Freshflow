<?php


if (!function_exists('log_audit_action')) {

    function log_audit_action(string $action_type, string $action_category, string $details, array $metadata = []): bool {
        global $conn;

        // Security check for session variables
        $user_id = $_SESSION['user_id'] ?? 0;
        $username = $_SESSION['username'] ?? 'SYSTEM';
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        
        // Ensure connection is available
        if (!$conn || $conn->connect_error) {
            error_log("Audit log failed: Database connection not available.");
            return false;
        }

        // Check if the audit_trail table has the 'metadata' column
        $has_metadata = false;
        $colCheck = $conn->query("SHOW COLUMNS FROM audit_trail LIKE 'metadata'");
        if ($colCheck !== false && $colCheck->num_rows > 0) {
            $has_metadata = true;
        }
        if ($colCheck) $colCheck->close();

        // Prepare metadata JSON string
        $metadata_json = $has_metadata ? json_encode($metadata) : null;
        if ($metadata_json === false) {
             $metadata_json = json_encode(['error' => 'Metadata encoding failed']);
        }

        if ($has_metadata) {
            $sql = "INSERT INTO audit_trail (user_id, username, action_type, action_category, details, ip_address, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                error_log("Audit log failed to prepare statement (with metadata): " . $conn->error);
                return false;
            }
            $stmt->bind_param("issssss", $user_id, $username, $action_type, $action_category, $details, $ip_address, $metadata_json);
        } else {
            // Fallback for tables without the metadata column
            $sql = "INSERT INTO audit_trail (user_id, username, action_type, action_category, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                error_log("Audit log failed to prepare statement (no metadata): " . $conn->error);
                return false;
            }
            $stmt->bind_param("isssss", $user_id, $username, $action_type, $action_category, $details, $ip_address);
        }

        $success = $stmt->execute();
        if (!$success) {
            error_log("Audit log failed to execute: " . $stmt->error);
        }
        $stmt->close();
        
        return $success;
    }
}
?>
