<?php
// C:\xampp\htdocs\RalphPHP\admin_components\process_admin_login.php

session_start();
include_once 'includes/db_connection.php';
include_once 'includes/audit_helper.php'; // <--- Import the Logger

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($username) || empty($password)) {
    header("Location: admin_login.php?error=empty");
    exit;
}

$stmt = $conn->prepare("SELECT user_id, username, password, role, status FROM users WHERE username = ? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        
        if (strcasecmp($user['status'], 'Active') !== 0) {
            header("Location: admin_login.php?error=banned");
            exit;
        }

        // Set Session
        $_SESSION["loggedin"] = true;
        $_SESSION["user_id"] = $user['user_id'];
        $_SESSION["username"] = $user['username'];
        $_SESSION["role_name"] = $user['role'];

        // Update Last Login Time
        $conn->query("UPDATE users SET last_login = NOW() WHERE user_id = {$user['user_id']}");

        // --- NEW: LOG THE LOGIN EVENT ---
        if(function_exists('log_audit_action')) {
            log_audit_action('Login', 'Authentication', "User logged in successfully.");
        }

        header("Location: pages/dashboard.php");
        exit;

    } else {
        // Log Failed Attempt (Optional but good for security)
        // log_audit_action('Login Failed', 'Authentication', "Failed login attempt for username: $username");
        header("Location: admin_login.php?error=invalid");
        exit;
    }
} else {
    header("Location: admin_login.php?error=invalid");
    exit;
}

$stmt->close();
$conn->close();
?>